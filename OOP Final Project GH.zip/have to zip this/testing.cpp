/*#include <iostream>
#include <fstream>
#include <string>

using namespace std;

int main()
{
    string mr_number;
    cout << "Enter patient MR number: ";
    cin >> mr_number;

    ofstream outfile;
    outfile.open("prescription2191.dat", ios::out | ios::binary | ios::app);

    if (!outfile)
    {
        cerr << "Error opening file." << endl;
        return 1;
    }

    string medicine;
    char choice;
    do
    {
        cout << "Enter medicine for patient: ";
        cin >> medicine;
        
        // Write the length of the medicine string
        size_t len = medicine.length();
        outfile.write(reinterpret_cast<const char*>(&len), sizeof(len));
        
        // Write the medicine string data
        outfile.write(medicine.c_str(), len);

        cout << "Do you want to enter more medicines? (y/n): ";
        cin >> choice;
    } while (choice == 'y');

    outfile.close();
    cout << "Prescription written to file." << endl;
    
    // Read and display the contents of the file
    ifstream infile("prescription2191.dat", ios::in | ios::binary);
    if (!infile)
    {
        cerr << "Error opening file." << endl;
        return 1;
    }
    
    size_t med_len;
    while (infile.read(reinterpret_cast<char*>(&med_len), sizeof(med_len)))
    {
        char* med_buf = new char[med_len + 1];
        infile.read(med_buf, med_len);
        med_buf[med_len] = '\0';
        //cout << "MR Number: " << mr_number << endl;
        cout << "Medicine: " << med_buf << endl;
        delete[] med_buf;
    }

    infile.close();
    return 0;
}


*/
/*
#include <iostream>
#include <fstream>
#include <string>

using namespace std;

int main() {
    string mr_num, doc_id;
    cout << "Enter MR number: ";
    cin >> mr_num;
    cout << "Enter doctor ID: ";
    cin >> doc_id;
    
    ifstream inputFile("doctorappointmentforaccess.dat");
    if (!inputFile) {
        cout << "Failed to open file." << endl;
        return 1;
    }
    
    string line;
    while (getline(inputFile, line)) {
        if (line.find(doc_id) == 0 && line.find(mr_num) != string::npos) {
            cout << "Data found: " << line << endl;
            inputFile.close();
            return 0;
        }
    }
    
    cout << "Data not found." << endl;
    inputFile.close();
    return 0;
}
*/


/*#include <iostream>
#include <fstream>

int main() {
    int doctor_id = 1234;
    int number = 42;

    std::ofstream file("appointmentrequests.dat", std::ios::binary);

    if (file.is_open()) {
        file.write(reinterpret_cast<const char*>(&doctor_id), sizeof(doctor_id));
        file.write(reinterpret_cast<const char*>(&number), sizeof(number));
        file.close();
        std::cout << "File written successfully" << std::endl;
    } else {
        std::cout << "Failed to open file" << std::endl;
    }

    return 0;
}
*/





































/*


#include <iostream>
#include <fstream>

int main() {
    int doctor_id;
    int number;

    std::ifstream file("appointmentrequests.dat", std::ios::binary);

    if (file.is_open()) {
        file.read(reinterpret_cast<char*>(&doctor_id), sizeof(doctor_id));
        file.read(reinterpret_cast<char*>(&number), sizeof(number));
        file.close();
        std::cout << "Doctor ID: " << doctor_id << std::endl;
        std::cout << "Number: " << number << std::endl;
    } else {
        std::cout << "Failed to open file" << std::endl;
    }

    return 0;
}

*/









#include <iostream>
#include <fstream>
#include <string>

using namespace std;

int main() 
{
    // Open file in binary mode for appending
    int search_doctor_id = 1234; // the doctor id entered by the user
    int doctor_id, time,mr;
    ifstream file("appointmentrequests.dat", ios::binary);
    bool found = false;
    if (file.is_open()) 
    {
        
        
        while (file.read(reinterpret_cast<char*>(&doctor_id), sizeof(doctor_id))) 
        {
            file.read(reinterpret_cast<char*>(&time), sizeof(time));
            file.read(reinterpret_cast<char*>(&mr), sizeof(mr));
            if (doctor_id == search_doctor_id) 
            {
                found = true;
                cout << "Appointment request found for Doctor ID " << doctor_id << " with appointment time " << time << " MR_number "<<mr<< endl;
            }
        }
        if (!found) 
        {
            cout << "No appointment requests found for Doctor ID " << search_doctor_id << endl;
        }
        file.close();
    } 
    else 
    {
        cout << "Failed to open file" << endl;
    }

    return 0;
}



