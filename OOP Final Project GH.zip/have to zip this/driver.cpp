#include<iostream>
#include"patient.h"
#include"doctor.h"
#include"patient.cpp"
#include"doctor.cpp"

using namespace std;


int main()
{
    PatientData p("Arham Ahmed",18,2191,60,120,80,70,98.6);
    /*PatientData p2("John Smith",50,9012,70,159,60,90,100.1);
    PatientData p3("Sarah Williams", 35, 1010, 80, 120, 80, 96, 98.5);
    PatientData p4("James Lee", 42, 2145, 85, 125, 80, 97, 99.2);
    PatientData p5("Jacob Rodriguez", 44, 1002, 87, 128, 82, 96, 100.6);
    PatientData p6("Noman Ali", 38, 5742, 85, 135, 80, 93, 99.8);
    PatientData p7("Farhan Ahmed", 41, 7123, 78, 140, 75, 94, 99.4);
    PatientData p8("Muhammad Ali", 35, 4213, 80, 120, 70, 95, 98.5);
    PatientData p9("Sher Khan", 45, 6321, 70, 130, 75, 97, 99.2);
    PatientData p10("Bandook Khan", 28, 2789, 75, 125, 70, 91, 98.8);
   
    p.create(p);
    p2.create(p2);
    p3.create(p3);
    p4.create(p4);
    p5.create(p5);
    p6.create(p6);
    p7.create(p7);
    p8.create(p8);
    p9.create(p9);
    p10.create(p10);

    return 0;*/

    //Doctor d1("John Will",1234,"Kidney");
    /*Doctor d2("Sara Lee", 2345, "Endocronologist");
    Doctor d3("David Wong", 3456, "GeneralSurgery");
    Doctor d4("Emily Chen", 4567, "Dentist");
    Doctor d5("Gulab Khan", 5678, "Skin");*/


    //d5.doc_create(d5);
    //d1.doc_read();


    cout<<endl;
    cout<<"Are u a DOCTOR or a PATIENT ? "<<endl;
    cout<<"Press 1 for Doctor"<<endl;
    cout<<"Press 2 for Patient"<<endl;
    int choice;
    cin>>choice;

    system("cls");

    if(choice == 1)
    {
        Doctor d;
        int value = d.DoctorLogin();
        if(value > 2)
        {
            cout<<"Good-Bye"<<endl;
        }
        else
        {
            if(d.getdocid() >= 1000 && d.getdocid() <= 1999)
            {
                cout<<"Welcome Kidney Doctor"<<endl;
                cout<<"Press 1 to see patient data"<<endl;//done
                cout<<"Press 2 to see appointment requests and accept them"<<endl;
                cout<<"Press 3 to see and edit patient prescription"<<endl;//done
                //cout<<"Press 4 to view past 3 months average data of vitals"<<endl;
                cout<<"Press 0 to close this menue"<<endl;
                KidneyDoctor k;
                int choice=9999;
                cin>>choice;
                while(choice!=0)
                {
                    if(choice==1)
                    {   
                        k.show_patient_data_kidney();   
                    }
                    else if(choice==2)
                    {
                        k.setAppointment_kidney();
                        //appoitment requests and acceptance calls a function
                    }
                    else if(choice==3)
                    {
                        // output prescription and edit it
                        k.create_prescription();
                    }
                    cout<<endl;
                    cout<<"Press 1 to see patient data"<<endl;
                    cout<<"Press 2 to see appointment requests and accept them"<<endl;
                    cout<<"Press 3 to see and edit patient prescription"<<endl;
                    
                    cout<<"Press 0 to close this menue"<<endl;
                    cout<<"Enter your choice = ";
                    cin>>choice;
                }
                
                
            }
            else if((d.getdocid() >= 2000) && (d.getdocid() <= 2999))
            {
                Endocronologist e;
                cout<<"Welcome Endocronologist"<<endl;
                cout<<"Press 1 to see patient data"<<endl;
                cout<<"Press 2 to see appointment requests and accept them"<<endl;
                cout<<"Press 3 to see and edit patient prescription"<<endl;
                cout<<"Press 4 to close this menue"<<endl;

                int choice;
                cin>>choice;

                while(choice!=0)
                {
                    if(choice==1)
                    {   
                        e.show_patient_data_endo();   
                    }
                    else if(choice==2)
                    {
                        e.setAppointment_endo();
                        //appoitment requests and acceptance calls a function
                    }
                    else if(choice==3)
                    {
                        // output prescription and edit it
                        e.create_prescription();
                    }
                    cout<<endl;
                    cout<<"Press 1 to see patient data"<<endl;
                    cout<<"Press 2 to see appointment requests and accept them"<<endl;
                    cout<<"Press 3 to see and edit patient prescription"<<endl;
                    
                    cout<<"Press 0 to close this menue"<<endl;
                    cout<<"Enter your choice = ";
                    cin>>choice;
                }
            }
            else if((d.getdocid() >= 3000) && (d.getdocid() <= 3999))
            {
                cout<<"Welcome General Surgeoun"<<endl;
                cout<<"Press 1 to see patient data"<<endl;
                cout<<"Press 2 to see appointment requests and accept them"<<endl;
                cout<<"Press 3 to see and edit patient prescription"<<endl;
                cout<<"Press 4 to close this menue"<<endl;
                GeneralSurgeoun g;
                int choice;
                cin>>choice;

                while(choice!=0)
                {
                    if(choice==1)
                    {   
                        g.show_patient_data_generalsurgeoun();   
                    }
                    else if(choice==2)
                    {
                        g.setAppointment_generalsurgeoun();
                        //appoitment requests and acceptance calls a function
                    }
                    else if(choice==3)
                    {
                        // output prescription and edit it
                        g.create_prescription();
                    }
                    cout<<endl;
                    cout<<"Press 1 to see patient data"<<endl;
                    cout<<"Press 2 to see appointment requests and accept them"<<endl;
                    cout<<"Press 3 to see and edit patient prescription"<<endl;
                    
                    cout<<"Press 0 to close this menue"<<endl;
                    cout<<"Enter your choice = ";
                    cin>>choice;
                }
            }
            else if((d.getdocid() >= 4000) && (d.getdocid() <= 4999))
            {
                cout<<"Welcome Dentist"<<endl;
                cout<<"Press 1 to see patient data"<<endl;
                cout<<"Press 2 to see appointment requests and accept them"<<endl;
                cout<<"Press 3 to see and edit patient prescription"<<endl;
                cout<<"Press 4 to close this menue"<<endl;
                Dentist d;
                int choice;
                cin>>choice;

                while(choice!=0)
                {
                    if(choice==1)
                    {   
                        d.show_patient_data_dentist();   
                    }
                    else if(choice==2)
                    {
                        d.setAppointment_dentist();
                        //appoitment requests and acceptance calls a function
                    }
                    else if(choice==3)
                    {
                        // output prescription and edit it
                        d.create_prescription();
                    }
                    cout<<endl;
                    cout<<"Press 1 to see patient data"<<endl;
                    cout<<"Press 2 to see appointment requests and accept them"<<endl;
                    cout<<"Press 3 to see and edit patient prescription"<<endl;
                    
                    cout<<"Press 0 to close this menue"<<endl;
                    cout<<"Enter your choice = ";
                    cin>>choice;
                }
            }
            else if((d.getdocid() >= 5000) && (d.getdocid() <= 5999))
            {
                cout<<"Welcome Skin Doctor"<<endl;
                cout<<"Press 1 to see patient data"<<endl;// done
                cout<<"Press 2 to see appointment requests and accept them"<<endl; // why
                cout<<"Press 3 to see and edit patient prescription"<<endl; // done
                cout<<"Press 4 to close this menue"<<endl; // done
                SkinDoctor s;
                int choice;
                cin>>choice;

                while(choice!=0)
                {
                    if(choice==1)
                    {   
                        s.show_patient_data_skin();   
                    }
                    else if(choice==2)
                    {
                        s.setAppointment_skin();
                        //appoitment requests and acceptance calls a function
                    }
                    else if(choice==3)
                    {
                        // output prescription and edit it
                        s.create_prescription();
                    }
                    cout<<endl;
                    cout<<"Press 1 to see patient data"<<endl;
                    cout<<"Press 2 to see appointment requests and accept them"<<endl;
                    cout<<"Press 3 to see and edit patient prescription"<<endl;
                    
                    cout<<"Press 0 to close this menue"<<endl;
                    cout<<"Enter your choice = ";
                    cin>>choice;
                }
            }
        }
    }
    else if(choice == 2)
    {
        int login_result = p.login();
        cout<<"Welcome Patient"<<endl;
        cout<<"Press 1 to call doctor"<<endl;
        cout<<"Press 2 to see your data "<<endl;
        cout<<"Press 3 to request appoitnment"<<endl;
        cout<<"Press 0 to exit "<<endl;
        int choice;

        cin>>choice;
        

        if(login_result > 2)
        {
            cout<<"Good-Bye"<<endl;
        }
        else
        {
            while(choice!=0)
            {
                if(choice==1)
                {
                    p.call_doctor();
                }
                else if(choice==2)
                {
                    int mr=p.getMR();
                    p.read(mr);
                }
                else if(choice==3)
                {
                    p.request_appointment();
                }
            
                cout<<endl;
                cout<<endl;
                cout<<"Press 1 to call doctor"<<endl;
                cout<<"Press 2 to see your data "<<endl;
                cout<<"Press 3 to request appoitnment"<<endl;
                cout<<"Press 0 to exit "<<endl;
                cin>>choice;
            }
            



            

            //system("cls");
            //p.read();
        }
    }
    else
    {
        cout<<"Terminating Program as in-valid choice entered"<<endl;
    }

    
    
    



    //read();
    //p.login();
    //p.call_doctor();
    //p.display_patient_data();
    return 0;
}