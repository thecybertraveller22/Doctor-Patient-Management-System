#ifndef DOCTOR_H
#define DOCTOR_H
#include<string>
//#include"allfiles.h"
#include"patient.h"



using namespace std;

class Doctor
{
    public:
        //string doc_name;
        char doc_name[30];
        int doc_id;
        char department[30];

        Doctor();
        Doctor(string n,int id,string d);
        void doc_create(Doctor obj);
        void doc_read();
        int getdocid();
        void infodoc();
        int DoctorLogin();
        const char* getdocname() const;
        int create_prescription();
};

class SkinDoctor : public Doctor
{
    public:
        SkinDoctor();
        SkinDoctor(string n);
        void show_patient_data_skin();// Doctor(n, "Dentistry")// doctor can access patient data now and see it 
        void setAppointment_skin();
};

class GeneralSurgeoun : public Doctor
{
    public:
        GeneralSurgeoun();
        GeneralSurgeoun(string n);
        void show_patient_data_generalsurgeoun();// Doctor(n, "Dentistry")// doctor can access patient data now and see it 
        void setAppointment_generalsurgeoun();

};

class Dentist : public Doctor
{
    public:
        Dentist();
        Dentist(string n);
        void show_patient_data_dentist();// Doctor(n, "Dentistry")// doctor can access patient data now and see it 
        void setAppointment_dentist();
};

class Endocronologist : public Doctor
{
    public:
        Endocronologist();
        Endocronologist(string n);
        void show_patient_data_endo(); // doctor can access patient data now and see it 
        void setAppointment_endo();
};

class KidneyDoctor : public Doctor
{
    public:
        KidneyDoctor();
        KidneyDoctor(string n);
        void show_patient_data_kidney(); // doctor can access patient data now and see it 
        void setAppointment_kidney();
};


#endif