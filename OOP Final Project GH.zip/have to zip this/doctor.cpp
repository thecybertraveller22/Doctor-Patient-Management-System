#include<iostream>
#include"doctor.h"
#include"patient.h"
#include <cstdlib>
#include <ctime>
#include<fstream>
#include<sstream>
#include <chrono>
#include<cstring>
#include <cstdlib>
using namespace std;




Doctor::Doctor()
{

}

Doctor::Doctor(string n,int id,string d)
{
    strcpy(doc_name, n.c_str());
    strcpy(department, d.c_str());
    doc_id = id;
}
KidneyDoctor::KidneyDoctor()
{

}
KidneyDoctor::KidneyDoctor(string n)
{
    strcpy(doc_name, n.c_str());
}
Endocronologist::Endocronologist()
{

}
Endocronologist::Endocronologist(string n)
{
    strcpy(doc_name, n.c_str());
}

Dentist::Dentist()
{
    
}

Dentist::Dentist(string n) 
{
    strcpy(doc_name, n.c_str());
}

GeneralSurgeoun::GeneralSurgeoun()
{

}

GeneralSurgeoun::GeneralSurgeoun(string n)
{
    strcpy(doc_name, n.c_str());
}

SkinDoctor::SkinDoctor()
{

}

SkinDoctor::SkinDoctor(string n)
{
    strcpy(doc_name, n.c_str());
}

void SkinDoctor::show_patient_data_skin()
{
    PatientData patient;
    string appointment_find;
    ifstream inFile("doctorappointmentforaccess.dat");
    cout << "Enter your id and the patient mr in the format (e.g. 1234,2191) = ";
    cin>>appointment_find;
    string numAfterComma;
    string line;
    bool found = false;
    while (getline(inFile, line)) 
    {
        if (line == appointment_find) 
        {
            found = true;
            numAfterComma = line.substr(line.find(",")+1);
            break;
        }
    }
    if(found)
    {
        int number = stoi(numAfterComma);
        patient.skinread(number);
    }
    else
    {
        cout<<"Access denied You dont have appointment with this patient "<<endl;
    }
    
}

void Dentist::show_patient_data_dentist()
{
    PatientData patient;
    string appointment_find;
    ifstream inFile("doctorappointmentforaccess.dat");
    cout << "Enter your id and the patient mr in the format (e.g. 1234,2191) = ";
    cin>>appointment_find;
    string numAfterComma;
    string line;
    bool found = false;
    while (getline(inFile, line)) 
    {
        if (line == appointment_find) 
        {
            found = true;
            numAfterComma = line.substr(line.find(",")+1);
            break;
        }
    }
    if(found)
    {
        int number = stoi(numAfterComma);
        patient.dentistread(number);
    }
    else
    {
        cout<<"Access denied You dont have appointment with this patient "<<endl;
    }
}

void GeneralSurgeoun::show_patient_data_generalsurgeoun()
{
    PatientData patient;
    string appointment_find;
    ifstream inFile("doctorappointmentforaccess.dat");
    cout << "Enter your id and the patient mr in the format (e.g. 1234,2191) = ";
    cin>>appointment_find;
    string numAfterComma;
    string line;
    bool found = false;
    while (getline(inFile, line)) 
    {
        if (line == appointment_find) 
        {
            found = true;
            numAfterComma = line.substr(line.find(",")+1);
            break;
        }
    }
    if(found)
    {
        int number = stoi(numAfterComma);
        patient.generalread(number);
    }
    else
    {
        cout<<"Access denied You dont have appointment with this patient "<<endl;
    }
    
}

void Endocronologist::show_patient_data_endo()
{
    PatientData patient;
    string appointment_find;
    ifstream inFile("doctorappointmentforaccess.dat");
    cout << "Enter your id and the patient mr in the format (e.g. 1234,2191) = ";
    cin>>appointment_find;
    string numAfterComma;
    string line;
    bool found = false;
    while (getline(inFile, line)) 
    {
        if (line == appointment_find) 
        {
            found = true;
            numAfterComma = line.substr(line.find(",")+1);
            break;
        }
    }
    if(found)
    {
        int number = stoi(numAfterComma);
        patient.endoread(number);
    }
    else
    {
        cout<<"Access denied You dont have appointment with this patient "<<endl;
    }
    
}

void KidneyDoctor::show_patient_data_kidney()
{
    PatientData patient;
    string appointment_find;
    ifstream inFile("doctorappointmentforaccess.dat");
    cout << "Enter your id and the patient mr in the format (e.g. 1234,2191) = ";
    cin>>appointment_find;
    string numAfterComma;
    string line;
    bool found = false;
    while (getline(inFile, line)) 
    {
        if (line == appointment_find) 
        {
            found = true;
            numAfterComma = line.substr(line.find(",")+1);
            break;
        }
    }
    if(found)
    {
        int number = stoi(numAfterComma);
        patient.kidneyread(number);
    }
    else
    {
        cout<<"Access denied You dont have appointment with this patient "<<endl;
    }
    
}

int Doctor::DoctorLogin()
{
    /*cout<<endl;
    cout<<"------------------------------------------------------------------------------------------------"<<endl;
    cout<<"Welcome to the SLOW Doctor portal"<<endl;
    cout<<"------------------------------------------------------------------------------------------------"<<endl;
    cout<<"Enter your login details to continue"<<endl;
    cout<<"------------------------------------------------------------------------------------------------"<<endl;
    cout<<endl;

    cout<<"Enter Doctor ID = ";
    int id,doctor_id,pass;
    cin>>id;
    cout<<"Enter Pin = ";
    int pin;
    cin>>pin;


    ifstream file("doctorlogin.dat");
    string line;
    string doctor_id_str, pin_str;
    bool found = false;

    while (getline(file, line)) 
    {
        stringstream ss(line);
        

        getline(ss, doctor_id_str, ',');
        getline(ss, pin_str);

        doctor_id = stoi(doctor_id_str);
        pass = stoi(pin_str);

        if (doctor_id == id && pass == pin) 
        {
            found = true;
            break;
        }
    }
    cout<<endl;

    file.close();
    int count = 0;
    if (found) 
    {
        cout << "Login successful!" << endl;
        doc_id = id;
        system("cls");
    }
    else 
    {
        cout << "Invalid MR-number or password." << endl;
        ifstream file("doctorlogin.dat");
        /*while(count<3 & found == false)
        {
            system("cls");
            cout<<endl;
            cout<<"------------------------------------------------------------------------------------------------"<<endl;
            cout<<"Welcome to the SLOW Patient portal"<<endl;
            cout<<"------------------------------------------------------------------------------------------------"<<endl;
            cout<<"Enter your login details to continue"<<endl;
            cout<<"------------------------------------------------------------------------------------------------"<<endl;
            cout<<endl;
            cout<<"Enter Doctor ID = ";
           
            cin>>id;
            cout<<"Enter Pin = ";
            
            cin>>pin;
            file.clear();
            file.seekg(0, ios::beg);

            while (getline(file, line)) 
            {
                stringstream ss(line);

                getline(ss, doctor_id_str, ',');
                getline(ss, pin_str);

                doctor_id = stoi(doctor_id_str);
                pass = stoi(pin_str);

                if (doctor_id == id && pass == pin) 
                {
                    found = true;
                    break;
                }
            }
            //login();
            count++;
            if(found)
            {
                file.close();
                //break;
            }
        }
        while(count<3 & found == false)
        {
            system("cls");
            cout<<endl;
            cout<<"------------------------------------------------------------------------------------------------"<<endl;
            cout<<"Welcome to the SLOW Patient portal"<<endl;
            cout<<"------------------------------------------------------------------------------------------------"<<endl;
            cout<<"Enter your login details to continue"<<endl;
            cout<<"------------------------------------------------------------------------------------------------"<<endl;
            cout<<endl;
            cout<<"Enter Doctor ID = ";
        
            cin>>id;
            cout<<"Enter Pin = ";
            
            cin>>pin;
            file.clear();
            file.seekg(0, ios::beg);

            while (getline(file, line)) 
            {
                stringstream ss(line);

                getline(ss, doctor_id_str, ',');
                getline(ss, pin_str);

                doctor_id = stoi(doctor_id_str);
                pass = stoi(pin_str);

                if (doctor_id == id && pass == pin) 
                {
                    found = true;
                    break;
                }
            }
            //login();
            count++;
            if(found)
            {
                file.close();
                break; // add this line
            }
        }

        if(count>2)
        {
            cout<<"Account Locked , login after 2 minutes"<<endl;
            return count;
        }
    }
    cout<<endl;
    return 0;*/
    //**********************------------------------------****************************************-----------------------*************


    


    cout<<endl;
    cout<<"------------------------------------------------------------------------------------------------"<<endl;
    cout<<"Welcome to the SLOW Doctor portal"<<endl;
    cout<<"------------------------------------------------------------------------------------------------"<<endl;
    cout<<"Enter your login details to continue"<<endl;
    cout<<"------------------------------------------------------------------------------------------------"<<endl;
    cout<<endl;

    ifstream file("doctorlogin.dat");

    string line;

    bool found = false;

    int pin,id,pass;

    string id_str, pin_str;

    cout << "Enter doctor id: ";

    cin >> doc_id;

    cout << "Enter pin: ";

    cin >> pin;

    while (getline(file, line)) 
    {
        stringstream ss(line);
        

        getline(ss, id_str, ',');
        getline(ss, pin_str);

        id = stoi(id_str);
        pass = stoi(pin_str);

        if (id == doc_id && pass == pin) 
        {
            found = true;
            break;
        }
    }
    cout<<endl;

    file.close();
    int count = 0;
    if (found) 
    {
        cout << "Login successful!" << endl;
        system("cls");
    }
    else 
    {
        ifstream file("doctorlogin.dat");
        cout << "Invalid doctor id or pin." << endl;

        while(count<3 & found==false)
        {
            system("cls");
            cout<<endl;
            cout<<"------------------------------------------------------------------------------------------------"<<endl;
            cout<<"Welcome to the SLOW Doctor portal"<<endl;
            cout<<"------------------------------------------------------------------------------------------------"<<endl;
            cout<<"Enter your login details to continue"<<endl;
            cout<<"------------------------------------------------------------------------------------------------"<<endl;
            cout<<endl;
            cout << "Enter doctor id: ";
            cin >> doc_id;
            cout << "Enter pin: ";
            cin >> pin;
            
            file.clear();
            file.seekg(0, ios::beg);

            while (getline(file, line)) 
            {
                stringstream ss(line);

                getline(ss, id_str, ',');
                getline(ss, pin_str);

                id = stoi(id_str);
                pass = stoi(pin_str);

                if (id == doc_id && pass == pin) 
                {
                    found = true;
                    break;
                }
            }

            count++;

            if (found) 
            {
                file.close();
                break;
            }
        }
        if(count>2)
        {
            cout<<"Account Locked , login after 2 minutes"<<endl;
            return count;
        }
    }
    cout<<endl;
    return 0;


}

int Doctor::getdocid()
{
    return doc_id;
}

void Doctor::doc_create(Doctor obj)
{
    ofstream f("doctordata.dat",ios::binary | ios::app);
    f.write((char*)&obj, sizeof(obj));
    f.close();
}

void Doctor::doc_read()
{
    ifstream f("doctordata.dat",ios::binary);

    if(!f) 
    {
        cout << "Error opening file" << endl;
        return;
    }
    Doctor obj;
    int id;

    cout<<"Enter ID to view doctor details = ";
    cin>>id;

    bool found=false;

    while(f.read((char*)&obj, sizeof(obj))) 
    {
        if (obj.doc_id == id) 
        {
            //cout<<"I am here "<<endl;
            obj.infodoc();
            found = true;
        }
    }
    f.close();
}

void Doctor::infodoc()
{
    cout<<"Name       = "<<doc_name<<endl;
    cout<<"ID         = "<<doc_id<<endl;
    cout<<"Department = "<<department<<endl;
}


const char* Doctor::getdocname() const 
{
    return doc_name;
}

int Doctor::create_prescription()
{
    string mr_num, doc_id;
    bool found=false;

    cout << "Enter MR number: ";
    cin >> mr_num;
    cout << "Enter doctor ID: ";
    cin >> doc_id;
    
    ifstream inputFile("doctorappointmentforaccess.dat");
    if (!inputFile) 
    {
        cout << "Failed to open file." << endl;
        return 1;
    }
    
    string line;
    while (getline(inputFile, line)) 
    {
        if (line.find(doc_id) == 0 && line.find(mr_num) != string::npos) 
        {
            found=true;
            cout << "Data found: " << line << endl;
            inputFile.close();
            //return 0;
        }
    }
    inputFile.close();
    //return 0;    
    

    //-----
    if(found)
    {
        ///int number = stoi(numAfterComma);
        ////patient.skinread(number);

        if(mr_num=="2191")
        {
            cout<<"Do u want to edit prescription or veiw prescription"<<endl;
            cout<<"Press 1 for edit"<<endl;
            cout<<"Press 2 for view"<<endl;
            int choice=0;
            cin>>choice;

            if(choice==1)
            {
                ofstream outfile;
                outfile.open("prescription2191.dat", ios::out | ios::binary | ios::app);

                if (!outfile)
                {
                    cout << "Error opening file." << endl;
                    return 1;
                }

                string medicine;
                char choice;
                do
                {
                    cout << "Enter medicine for patient: ";
                    cin >> medicine;
                    
                    // Write the length of the medicine string
                    size_t len = medicine.length();
                    outfile.write(reinterpret_cast<const char*>(&len), sizeof(len));
                    
                    // Write the medicine string data
                    outfile.write(medicine.c_str(), len);

                    cout << "Do you want to enter more medicines? (y/n): ";
                    cin >> choice;
                } while (choice == 'y');

                outfile.close();
                cout << "Prescription written to file." << endl;
            }
            else if(choice==2)
            {
                ifstream infile("prescription2191.dat", ios::in | ios::binary);
                if (!infile)
                {
                    cout << "Error opening file." << endl;
                    return 1;
                }
                
                size_t med_len;
                while (infile.read(reinterpret_cast<char*>(&med_len), sizeof(med_len)))
                {
                    char* med_buf = new char[med_len + 1];
                    infile.read(med_buf, med_len);
                    med_buf[med_len] = '\0';
                    //cout << "MR Number: " << mr_number << endl;
                    cout << "Medicine: " << med_buf << endl;
                    delete[] med_buf;
                }

                infile.close();
            }
        }
        else if(mr_num=="9012")
        {
           cout<<"Do u want to edit prescription or veiw prescription"<<endl;
            cout<<"Press 1 for edit"<<endl;
            cout<<"Press 2 for view"<<endl;
            int choice=0;
            cin>>choice;

            if(choice==1)
            {
                ofstream outfile;
                outfile.open("prescription9012.dat", ios::out | ios::binary | ios::app);

                if (!outfile)
                {
                    cout << "Error opening file." << endl;
                    return 1;
                }

                string medicine;
                char choice;
                do
                {
                    cout << "Enter medicine for patient: ";
                    cin >> medicine;
                    
                    // Write the length of the medicine string
                    size_t len = medicine.length();
                    outfile.write(reinterpret_cast<const char*>(&len), sizeof(len));
                    
                    // Write the medicine string data
                    outfile.write(medicine.c_str(), len);

                    cout << "Do you want to enter more medicines? (y/n): ";
                    cin >> choice;
                } while (choice == 'y');

                outfile.close();
                cout << "Prescription written to file." << endl;
            }
            else if(choice==2)
            {
                ifstream infile("prescription9012.dat", ios::in | ios::binary);
                if (!infile)
                {
                    cout << "Error opening file." << endl;
                    return 1;
                }
                
                size_t med_len;
                while (infile.read(reinterpret_cast<char*>(&med_len), sizeof(med_len)))
                {
                    char* med_buf = new char[med_len + 1];
                    infile.read(med_buf, med_len);
                    med_buf[med_len] = '\0';
                    //cout << "MR Number: " << mr_number << endl;
                    cout << "Medicine: " << med_buf << endl;
                    delete[] med_buf;
                }

                infile.close();
            }
        }
        else if(mr_num=="1010")
        {
            cout<<"Do u want to edit prescription or veiw prescription"<<endl;
            cout<<"Press 1 for edit"<<endl;
            cout<<"Press 2 for view"<<endl;
            int choice=0;
            cin>>choice;

            if(choice==1)
            {
                ofstream outfile;
                outfile.open("prescription1010.dat", ios::out | ios::binary | ios::app);

                if (!outfile)
                {
                    cout << "Error opening file." << endl;
                    return 1;
                }

                string medicine;
                char choice;
                do
                {
                    cout << "Enter medicine for patient: ";
                    cin >> medicine;
                    
                    // Write the length of the medicine string
                    size_t len = medicine.length();
                    outfile.write(reinterpret_cast<const char*>(&len), sizeof(len));
                    
                    // Write the medicine string data
                    outfile.write(medicine.c_str(), len);

                    cout << "Do you want to enter more medicines? (y/n): ";
                    cin >> choice;
                } while (choice == 'y');

                outfile.close();
                cout << "Prescription written to file." << endl;
            }
            else if(choice==2)
            {
                ifstream infile("prescription1010.dat", ios::in | ios::binary);
                if (!infile)
                {
                    cout << "Error opening file." << endl;
                    return 1;
                }
                
                size_t med_len;
                while (infile.read(reinterpret_cast<char*>(&med_len), sizeof(med_len)))
                {
                    char* med_buf = new char[med_len + 1];
                    infile.read(med_buf, med_len);
                    med_buf[med_len] = '\0';
                    //cout << "MR Number: " << mr_number << endl;
                    cout << "Medicine: " << med_buf << endl;
                    delete[] med_buf;
                }

                infile.close();
            }
        }
        else if(mr_num=="2145")
        {
            cout<<"Do u want to edit prescription or veiw prescription"<<endl;
            cout<<"Press 1 for edit"<<endl;
            cout<<"Press 2 for view"<<endl;
            int choice=0;
            cin>>choice;

            if(choice==1)
            {
                ofstream outfile;
                outfile.open("prescription2145.dat", ios::out | ios::binary | ios::app);

                if (!outfile)
                {
                    cout << "Error opening file." << endl;
                    return 1;
                }

                string medicine;
                char choice;
                do
                {
                    cout << "Enter medicine for patient: ";
                    cin >> medicine;
                    
                    // Write the length of the medicine string
                    size_t len = medicine.length();
                    outfile.write(reinterpret_cast<const char*>(&len), sizeof(len));
                    
                    // Write the medicine string data
                    outfile.write(medicine.c_str(), len);

                    cout << "Do you want to enter more medicines? (y/n): ";
                    cin >> choice;
                } while (choice == 'y');

                outfile.close();
                cout << "Prescription written to file." << endl;
            }
            else if(choice==2)
            {
                ifstream infile("prescription2145.dat", ios::in | ios::binary);
                if (!infile)
                {
                    cout << "Error opening file." << endl;
                    return 1;
                }
                
                size_t med_len;
                while (infile.read(reinterpret_cast<char*>(&med_len), sizeof(med_len)))
                {
                    char* med_buf = new char[med_len + 1];
                    infile.read(med_buf, med_len);
                    med_buf[med_len] = '\0';
                    //cout << "MR Number: " << mr_number << endl;
                    cout << "Medicine: " << med_buf << endl;
                    delete[] med_buf;
                }

                infile.close();
            }
        }
        else if(mr_num=="1002")
        {
            cout<<"Do u want to edit prescription or veiw prescription"<<endl;
            cout<<"Press 1 for edit"<<endl;
            cout<<"Press 2 for view"<<endl;
            int choice=0;
            cin>>choice;

            if(choice==1)
            {
                ofstream outfile;
                outfile.open("prescription1002.dat", ios::out | ios::binary | ios::app);

                if (!outfile)
                {
                    cout << "Error opening file." << endl;
                    return 1;
                }

                string medicine;
                char choice;
                do
                {
                    cout << "Enter medicine for patient: ";
                    cin >> medicine;
                    
                    // Write the length of the medicine string
                    size_t len = medicine.length();
                    outfile.write(reinterpret_cast<const char*>(&len), sizeof(len));
                    
                    // Write the medicine string data
                    outfile.write(medicine.c_str(), len);

                    cout << "Do you want to enter more medicines? (y/n): ";
                    cin >> choice;
                } while (choice == 'y');

                outfile.close();
                cout << "Prescription written to file." << endl;
            }
            else if(choice==2)
            {
                ifstream infile("prescription1002.dat", ios::in | ios::binary);
                if (!infile)
                {
                    cout << "Error opening file." << endl;
                    return 1;
                }
                
                size_t med_len;
                while (infile.read(reinterpret_cast<char*>(&med_len), sizeof(med_len)))
                {
                    char* med_buf = new char[med_len + 1];
                    infile.read(med_buf, med_len);
                    med_buf[med_len] = '\0';
                    //cout << "MR Number: " << mr_number << endl;
                    cout << "Medicine: " << med_buf << endl;
                    delete[] med_buf;
                }

                infile.close();
            }
        }
        else if(mr_num=="5742")
        {
            cout<<"Do u want to edit prescription or veiw prescription"<<endl;
            cout<<"Press 1 for edit"<<endl;
            cout<<"Press 2 for view"<<endl;
            int choice=0;
            cin>>choice;

            if(choice==1)
            {
                ofstream outfile;
                outfile.open("prescription5742.dat", ios::out | ios::binary | ios::app);

                if (!outfile)
                {
                    cout << "Error opening file." << endl;
                    return 1;
                }

                string medicine;
                char choice;
                do
                {
                    cout << "Enter medicine for patient: ";
                    cin >> medicine;
                    
                    // Write the length of the medicine string
                    size_t len = medicine.length();
                    outfile.write(reinterpret_cast<const char*>(&len), sizeof(len));
                    
                    // Write the medicine string data
                    outfile.write(medicine.c_str(), len);

                    cout << "Do you want to enter more medicines? (y/n): ";
                    cin >> choice;
                } while (choice == 'y');

                outfile.close();
                cout << "Prescription written to file." << endl;
            }
            else if(choice==2)
            {
                ifstream infile("prescription5742.dat", ios::in | ios::binary);
                if (!infile)
                {
                    cout << "Error opening file." << endl;
                    return 1;
                }
                
                size_t med_len;
                while (infile.read(reinterpret_cast<char*>(&med_len), sizeof(med_len)))
                {
                    char* med_buf = new char[med_len + 1];
                    infile.read(med_buf, med_len);
                    med_buf[med_len] = '\0';
                    //cout << "MR Number: " << mr_number << endl;
                    cout << "Medicine: " << med_buf << endl;
                    delete[] med_buf;
                }

                infile.close();
            }
        }
        else if(mr_num=="7123")
        {
            cout<<"Do u want to edit prescription or veiw prescription"<<endl;
            cout<<"Press 1 for edit"<<endl;
            cout<<"Press 2 for view"<<endl;
            int choice=0;
            cin>>choice;

            if(choice==1)
            {
                ofstream outfile;
                outfile.open("prescription7123.dat", ios::out | ios::binary | ios::app);

                if (!outfile)
                {
                    cout << "Error opening file." << endl;
                    return 1;
                }

                string medicine;
                char choice;
                do
                {
                    cout << "Enter medicine for patient: ";
                    cin >> medicine;
                    
                    // Write the length of the medicine string
                    size_t len = medicine.length();
                    outfile.write(reinterpret_cast<const char*>(&len), sizeof(len));
                    
                    // Write the medicine string data
                    outfile.write(medicine.c_str(), len);

                    cout << "Do you want to enter more medicines? (y/n): ";
                    cin >> choice;
                } while (choice == 'y');

                outfile.close();
                cout << "Prescription written to file." << endl;
            }
            else if(choice==2)
            {
                ifstream infile("prescription7123.dat", ios::in | ios::binary);
                if (!infile)
                {
                    cout << "Error opening file." << endl;
                    return 1;
                }
                
                size_t med_len;
                while (infile.read(reinterpret_cast<char*>(&med_len), sizeof(med_len)))
                {
                    char* med_buf = new char[med_len + 1];
                    infile.read(med_buf, med_len);
                    med_buf[med_len] = '\0';
                    //cout << "MR Number: " << mr_number << endl;
                    cout << "Medicine: " << med_buf << endl;
                    delete[] med_buf;
                }

                infile.close();
            }
        }
        else if(mr_num=="4213")
        {
            cout<<"Do u want to edit prescription or veiw prescription"<<endl;
            cout<<"Press 1 for edit"<<endl;
            cout<<"Press 2 for view"<<endl;
            int choice=0;
            cin>>choice;

            if(choice==1)
            {
                ofstream outfile;
                outfile.open("prescription4213.dat", ios::out | ios::binary | ios::app);

                if (!outfile)
                {
                    cout << "Error opening file." << endl;
                    return 1;
                }

                string medicine;
                char choice;
                do
                {
                    cout << "Enter medicine for patient: ";
                    cin >> medicine;
                    
                    // Write the length of the medicine string
                    size_t len = medicine.length();
                    outfile.write(reinterpret_cast<const char*>(&len), sizeof(len));
                    
                    // Write the medicine string data
                    outfile.write(medicine.c_str(), len);

                    cout << "Do you want to enter more medicines? (y/n): ";
                    cin >> choice;
                } while (choice == 'y');

                outfile.close();
                cout << "Prescription written to file." << endl;
            }
            else if(choice==2)
            {
                ifstream infile("prescription4213.dat", ios::in | ios::binary);
                if (!infile)
                {
                    cout << "Error opening file." << endl;
                    return 1;
                }
                
                size_t med_len;
                while (infile.read(reinterpret_cast<char*>(&med_len), sizeof(med_len)))
                {
                    char* med_buf = new char[med_len + 1];
                    infile.read(med_buf, med_len);
                    med_buf[med_len] = '\0';
                    //cout << "MR Number: " << mr_number << endl;
                    cout << "Medicine: " << med_buf << endl;
                    delete[] med_buf;
                }

                infile.close();
            }
        }
        else if(mr_num=="6321")
        {
           cout<<"Do u want to edit prescription or veiw prescription"<<endl;
            cout<<"Press 1 for edit"<<endl;
            cout<<"Press 2 for view"<<endl;
            int choice=0;
            cin>>choice;

            if(choice==1)
            {
                ofstream outfile;
                outfile.open("prescription6321.dat", ios::out | ios::binary | ios::app);

                if (!outfile)
                {
                    cout << "Error opening file." << endl;
                    return 1;
                }

                string medicine;
                char choice;
                do
                {
                    cout << "Enter medicine for patient: ";
                    cin >> medicine;
                    
                    // Write the length of the medicine string
                    size_t len = medicine.length();
                    outfile.write(reinterpret_cast<const char*>(&len), sizeof(len));
                    
                    // Write the medicine string data
                    outfile.write(medicine.c_str(), len);

                    cout << "Do you want to enter more medicines? (y/n): ";
                    cin >> choice;
                } while (choice == 'y');

                outfile.close();
                cout << "Prescription written to file." << endl;
            }
            else if(choice==2)
            {
                ifstream infile("prescription6321.dat", ios::in | ios::binary);
                if (!infile)
                {
                    cout << "Error opening file." << endl;
                    return 1;
                }
                
                size_t med_len;
                while (infile.read(reinterpret_cast<char*>(&med_len), sizeof(med_len)))
                {
                    char* med_buf = new char[med_len + 1];
                    infile.read(med_buf, med_len);
                    med_buf[med_len] = '\0';
                    //cout << "MR Number: " << mr_number << endl;
                    cout << "Medicine: " << med_buf << endl;
                    delete[] med_buf;
                }

                infile.close();
            }
        }
        else if(mr_num=="2789")
        {
            cout<<"Do u want to edit prescription or veiw prescription"<<endl;
            cout<<"Press 1 for edit"<<endl;
            cout<<"Press 2 for view"<<endl;
            int choice=0;
            cin>>choice;

            if(choice==1)
            {
                ofstream outfile;
                outfile.open("prescription2789.dat", ios::out | ios::binary | ios::app);

                if (!outfile)
                {
                    cout << "Error opening file." << endl;
                    return 1;
                }

                string medicine;
                char choice;
                do
                {
                    cout << "Enter medicine for patient: ";
                    cin >> medicine;
                    
                    // Write the length of the medicine string
                    size_t len = medicine.length();
                    outfile.write(reinterpret_cast<const char*>(&len), sizeof(len));
                    
                    // Write the medicine string data
                    outfile.write(medicine.c_str(), len);

                    cout << "Do you want to enter more medicines? (y/n): ";
                    cin >> choice;
                } while (choice == 'y');

                outfile.close();
                cout << "Prescription written to file." << endl;
            }
            else if(choice==2)
            {
                ifstream infile("prescription2789.dat", ios::in | ios::binary);
                if (!infile)
                {
                    cout << "Error opening file." << endl;
                    return 1;
                }
                
                size_t med_len;
                while (infile.read(reinterpret_cast<char*>(&med_len), sizeof(med_len)))
                {
                    char* med_buf = new char[med_len + 1];
                    infile.read(med_buf, med_len);
                    med_buf[med_len] = '\0';
                    //cout << "MR Number: " << mr_number << endl;
                    cout << "Medicine: " << med_buf << endl;
                    delete[] med_buf;
                }

                infile.close();
            }
        }
    }
    else
    {
        cout<<"Access denied You dont have appointment with this patient "<<endl;
    }
    return 0;
}
//******************************************************************************
//******************************************************************************

void KidneyDoctor::setAppointment_kidney()
{
    int search_doctor_id = 1234; // the doctor id entered by the user
    int doctor_id, time,mr;
    ifstream file("appointmentrequests.dat", ios::binary);
    bool found = false;
    if (file.is_open()) 
    {
        
        
        while (file.read(reinterpret_cast<char*>(&doctor_id), sizeof(doctor_id))) 
        {
            file.read(reinterpret_cast<char*>(&time), sizeof(time));
            file.read(reinterpret_cast<char*>(&mr), sizeof(mr));
            if (doctor_id == search_doctor_id) 
            {
                found = true;
                cout << "Appointment request found for Doctor ID " << doctor_id << " with appointment time " << time << " MR_number "<<mr<< endl;
            }
        }
        if (!found) 
        {
            cout << "No appointment requests found for Doctor ID " << search_doctor_id << endl;
        }
        file.close();
    } 
    else 
    {
        cout << "Failed to open file" << endl;
    }

    if(found)
    {
        int choice=0;
        cout<<"Do u want to accept this appointment request"<<endl;
        cout<<"Press 1 to accept"<<endl;
        cout<<"Press 2 to reject"<<endl;
        cin>>choice;
        if(choice==1)
        {
            ofstream file("appointment.dat", ios::binary|ios::app);

            // Check if the file is opened successfully
            if (file.is_open()) 
            {
                // Write data to the file
                int id = mr;
                string specialization = "kidney";
                int availability = 12;

                // Format the data string with a newline character
                string data = to_string(id) + "," + specialization + "," + to_string(availability) + "\n";

                // Write the data string to the file
                file.write(data.c_str(), data.size());
                file.close();

                ofstream file("doctorappointmentforaccess.dat", ios::binary|ios::app);

                data = to_string(search_doctor_id) + "," + to_string(id) + "\n";
                file.write(data.c_str(), data.size());

                file.close();


                cout << "Data written to file successfully!" << endl;
            } 
            else 
            {
                cout << "Failed to open file." << endl;
            }
        }
        else if (choice ==2)
        {
            cout<<"Thank-You for rejecting the request"<<endl;
        }
        
    }
}

void Endocronologist::setAppointment_endo()
{
    int search_doctor_id = 2345; // the doctor id entered by the user
    int doctor_id, time,mr;
    ifstream file("appointmentrequests.dat", ios::binary);
    bool found = false;
    if (file.is_open()) 
    {
        
        
        while (file.read(reinterpret_cast<char*>(&doctor_id), sizeof(doctor_id))) 
        {
            file.read(reinterpret_cast<char*>(&time), sizeof(time));
            file.read(reinterpret_cast<char*>(&mr), sizeof(mr));
            if (doctor_id == search_doctor_id) 
            {
                found = true;
                cout << "Appointment request found for Doctor ID " << doctor_id << " with appointment time " << time << " MR_number "<<mr<< endl;
            }
        }
        if (!found) 
        {
            cout << "No appointment requests found for Doctor ID " << search_doctor_id << endl;
        }
        file.close();
    } 
    else 
    {
        cout << "Failed to open file" << endl;
    }

    if(found)
    {
        int choice=0;
        cout<<"Do u want to accept this appointment request"<<endl;
        cout<<"Press 1 to accept"<<endl;
        cout<<"Press 2 to reject"<<endl;
        cin>>choice;
        if(choice==1)
        {
            ofstream file("appointment.dat", ios::binary|ios::app);

            // Check if the file is opened successfully
            if (file.is_open()) 
            {
                // Write data to the file
                int id = mr;
                string specialization = "endocronologist";
                int availability = 12;

                // Format the data string with a newline character
                string data = to_string(id) + "," + specialization + "," + to_string(availability) + "\n";

                // Write the data string to the file
                file.write(data.c_str(), data.size());
                file.close();

                ofstream file("doctorappointmentforaccess.dat", ios::binary|ios::app);

                data = to_string(search_doctor_id) + "," + to_string(id) + "\n";
                file.write(data.c_str(), data.size());

                file.close();

                cout << "Data written to file successfully!" << endl;
            } 
            else 
            {
                cout << "Failed to open file." << endl;
            }
        }
        else if (choice ==2)
        {
            cout<<"Thank-You for rejecting the request"<<endl;
        }
        
    }
}

void GeneralSurgeoun::setAppointment_generalsurgeoun()
{
    int search_doctor_id = 3456; // the doctor id entered by the user
    int doctor_id, time,mr;
    ifstream file("appointmentrequests.dat", ios::binary);
    bool found = false;
    if (file.is_open()) 
    {
        
        
        while (file.read(reinterpret_cast<char*>(&doctor_id), sizeof(doctor_id))) 
        {
            file.read(reinterpret_cast<char*>(&time), sizeof(time));
            file.read(reinterpret_cast<char*>(&mr), sizeof(mr));
            if (doctor_id == search_doctor_id) 
            {
                found = true;
                cout << "Appointment request found for Doctor ID " << doctor_id << " with appointment time " << time << " MR_number "<<mr<< endl;
            }
        }
        if (!found) 
        {
            cout << "No appointment requests found for Doctor ID " << search_doctor_id << endl;
        }
        file.close();
    } 
    else 
    {
        cout << "Failed to open file" << endl;
    }

    if(found)
    {
        int choice=0;
        cout<<"Do u want to accept this appointment request"<<endl;
        cout<<"Press 1 to accept"<<endl;
        cout<<"Press 2 to reject"<<endl;
        cin>>choice;
        if(choice==1)
        {
            ofstream file("appointment.dat", ios::binary|ios::app);

            // Check if the file is opened successfully
            if (file.is_open()) 
            {
                // Write data to the file
                int id = mr;
                string specialization = "generalsurgeoun";
                int availability = 12;

                // Format the data string with a newline character
                string data = to_string(id) + "," + specialization + "," + to_string(availability) + "\n";

                // Write the data string to the file
                file.write(data.c_str(), data.size());
                file.close();

                ofstream file("doctorappointmentforaccess.dat", ios::binary|ios::app);

                data = to_string(search_doctor_id) + "," + to_string(id) + "\n";
                file.write(data.c_str(), data.size());

                file.close();

                cout << "Data written to file successfully!" << endl;
            } 
            else 
            {
                cout << "Failed to open file." << endl;
            }
        }
        else if (choice ==2)
        {
            cout<<"Thank-You for rejecting the request"<<endl;
        }
        
    }
}

void Dentist::setAppointment_dentist()
{
    int search_doctor_id = 4567; // the doctor id entered by the user
    int doctor_id, time,mr;
    ifstream file("appointmentrequests.dat", ios::binary);
    bool found = false;
    if (file.is_open()) 
    {
        
        
        while (file.read(reinterpret_cast<char*>(&doctor_id), sizeof(doctor_id))) 
        {
            file.read(reinterpret_cast<char*>(&time), sizeof(time));
            file.read(reinterpret_cast<char*>(&mr), sizeof(mr));
            if (doctor_id == search_doctor_id) 
            {
                found = true;
                cout << "Appointment request found for Doctor ID " << doctor_id << " with appointment time " << time << " MR_number "<<mr<< endl;
            }
        }
        if (!found) 
        {
            cout << "No appointment requests found for Doctor ID " << search_doctor_id << endl;
        }
        file.close();
    } 
    else 
    {
        cout << "Failed to open file" << endl;
    }

    if(found)
    {
        int choice=0;
        cout<<"Do u want to accept this appointment request"<<endl;
        cout<<"Press 1 to accept"<<endl;
        cout<<"Press 2 to reject"<<endl;
        cin>>choice;
        if(choice==1)
        {
            ofstream file("appointment.dat", ios::binary|ios::app);

            // Check if the file is opened successfully
            if (file.is_open()) 
            {
                // Write data to the file
                int id = mr;
                string specialization = "dentist";
                int availability = 12;

                // Format the data string with a newline character
                string data = to_string(id) + "," + specialization + "," + to_string(availability) + "\n";

                // Write the data string to the file
                file.write(data.c_str(), data.size());
                file.close();

                ofstream file("doctorappointmentforaccess.dat", ios::binary|ios::app);

                data = to_string(search_doctor_id) + "," + to_string(id) + "\n";
                file.write(data.c_str(), data.size());

                file.close();

                cout << "Data written to file successfully!" << endl;
            } 
            else 
            {
                cout << "Failed to open file." << endl;
            }
        }
        else if (choice ==2)
        {
            cout<<"Thank-You for rejecting the request"<<endl;
        }
        
    }
}

void SkinDoctor::setAppointment_skin()
{
    int search_doctor_id = 5678; // the doctor id entered by the user
    int doctor_id, time,mr;
    ifstream file("appointmentrequests.dat", ios::binary);
    bool found = false;
    if (file.is_open()) 
    {
        
        
        while (file.read(reinterpret_cast<char*>(&doctor_id), sizeof(doctor_id))) 
        {
            file.read(reinterpret_cast<char*>(&time), sizeof(time));
            file.read(reinterpret_cast<char*>(&mr), sizeof(mr));
            if (doctor_id == search_doctor_id) 
            {
                found = true;
                cout << "Appointment request found for Doctor ID " << doctor_id << " with appointment time " << time << " MR_number "<<mr<< endl;
            }
        }
        if (!found) 
        {
            cout << "No appointment requests found for Doctor ID " << search_doctor_id << endl;
        }
        file.close();
    } 
    else 
    {
        cout << "Failed to open file" << endl;
    }

    if(found)
    {
        int choice=0;
        cout<<"Do u want to accept this appointment request"<<endl;
        cout<<"Press 1 to accept"<<endl;
        cout<<"Press 2 to reject"<<endl;
        cin>>choice;
        if(choice==1)
        {
            ofstream file("appointment.dat", ios::binary|ios::app);

            // Check if the file is opened successfully
            if (file.is_open()) 
            {
                // Write data to the file
                int id = mr;
                string specialization = "skin";
                int availability = 12;

                // Format the data string with a newline character
                string data = to_string(id) + "," + specialization + "," + to_string(availability) + "\n";

                // Write the data string to the file
                file.write(data.c_str(), data.size());
                file.close();

                ofstream file("doctorappointmentforaccess.dat", ios::binary|ios::app);

                data = to_string(search_doctor_id) + "," + to_string(id) + "\n";
                file.write(data.c_str(), data.size());

                file.close();

                cout << "Data written to file successfully!" << endl;
            } 
            else 
            {
                cout << "Failed to open file." << endl;
            }
        }
        else if (choice ==2)
        {
            cout<<"Thank-You for rejecting the request"<<endl;
        }
        
    }
}