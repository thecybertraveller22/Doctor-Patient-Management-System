#include<iostream>
#include"patient.h"
#include"doctor.h"
//#include"allfiles.h"
#include <cstdlib>
#include <ctime>
#include<fstream>
#include<sstream>
#include <chrono>
#include<cstring>
#include <cstdlib>

using namespace std;

PatientData::PatientData()
{

}

PatientData::PatientData(string n,int ag,int MR,int h_rate,int high,int low,int oxy,float temp)
{
    strcpy(name, n.c_str());
    //name=n;
    age=ag;
    MR_number=MR;
    heart_rate=h_rate;
    bp_high=high;
    bp_low=low;
    oxygen=oxy;
    temperature=temp;
}

void PatientData::setage()
{
    cout<<"Enter tha age for the new patient = ";
    cin>>age;

    // now write this age to file of age
}

int PatientData::getage()
{
    return age;
}

void PatientData::setMR()
{
    srand(time(NULL));
    MR_number = rand() % 4001 + 1000;
}

int PatientData::getMR()
{
    return MR_number;
}

void PatientData::set_heart_rate()
{
    srand(time(NULL));
    heart_rate = rand() % 81 + 40;
    //cout<<"Heart rate set for patient"<<endl;
}

int PatientData::get_heart_rate()
{
    return heart_rate;
}

void PatientData::setname()
{
    cout<<"Enter the new patient name = ";
    cin>>name;
}

string PatientData::getname()
{
    return name;
}

void PatientData::setbp_high()
{
    srand(time(NULL));
    bp_high = rand() % 81 + 90;
    //cout<<"BP HIGH set for patient"<<endl;
}

int PatientData::getbp_high()
{
    return bp_high;
}

void PatientData::setbp_low()
{
    srand(time(NULL));
    bp_low = rand() % 31 + 60;
    //cout<<"BP LOW set for patient<<endl;"
}

int PatientData::getbp_low()
{
    return bp_low;
}

void PatientData::set_oxygen()
{
    srand(time(NULL));
    oxygen = rand() % 21 + 80;
}

int PatientData::get_oxygen()
{
    return oxygen;
}

void PatientData::set_temperature()
{
    srand(time(NULL));
    temperature = (rand() % 60 + 970) / 10.0;
}

float PatientData::get_temperature()
{
    return temperature;
}


int PatientData::login()
{
    cout<<endl;
    cout<<"------------------------------------------------------------------------------------------------"<<endl;
    cout<<"Welcome to the SLOW Patient portal"<<endl;
    cout<<"------------------------------------------------------------------------------------------------"<<endl;
    cout<<"Enter your login details to continue"<<endl;
    cout<<"------------------------------------------------------------------------------------------------"<<endl;
    cout<<endl;

    ifstream file("login.dat");
    string line;
    bool found = false;
    int password,mr_num,pass;
    string mr_number_str, password_str;
    cout << "Enter MR-number: ";
    cin >> MR_number;
    cout << "Enter password: ";
    cin >> password;

    while (getline(file, line)) 
    {
        stringstream ss(line);
        

        getline(ss, mr_number_str, ',');
        getline(ss, password_str);

        mr_num = stoi(mr_number_str);
        pass = stoi(password_str);

        if (mr_num == MR_number && pass == password) 
        {
            found = true;
            break;
        }
    }
    cout<<endl;

    file.close();
    int count = 0;
    if (found) 
    {
        cout << "Login successful!" << endl;
        system("cls");
    }
    else 
    {
        ifstream file("login.dat");
        cout << "Invalid MR-number or password." << endl;

        while(count<3 & found==false)
        {
            system("cls");
            cout<<endl;
            cout<<"------------------------------------------------------------------------------------------------"<<endl;
            cout<<"Welcome to the SLOW Patient portal"<<endl;
            cout<<"------------------------------------------------------------------------------------------------"<<endl;
            cout<<"Enter your login details to continue"<<endl;
            cout<<"------------------------------------------------------------------------------------------------"<<endl;
            cout<<endl;
            cout << "Enter MR-number: ";
            cin >> MR_number;
            cout << "Enter password: ";
            cin >> password;
            
            file.clear();
            file.seekg(0, ios::beg);

            while (getline(file, line)) 
            {
                stringstream ss(line);

                getline(ss, mr_number_str, ',');
                getline(ss, password_str);

                mr_num = stoi(mr_number_str);
                pass = stoi(password_str);

                if (mr_num == MR_number && pass == password) 
                {
                    found = true;
                    break;
                }
            }

            count++;

            if (found) 
            {
                file.close();
                break;
            }
        }
        if(count>2)
        {
            cout<<"Account Locked , login after 2 minutes"<<endl;
            return count;
        }
    }
    cout<<endl;
    return 0;
}
       
void PatientData::call_doctor()
{
    cout<<"Which doctor u wish to call"<<endl;
    cout<<"Press 1 for endocronologist"<<endl;
    cout<<"Press 2 for kidney"<<endl;
    cout<<"Press 3 for general surgeoun"<<endl;
    cout<<"Press 4 for dentist"<<endl;
    cout<<"Press 5 for skin"<<endl;
    int choice;
    cin>>choice;

    if(choice == 1)
    {
        ifstream file("appointment.dat");
        string line;
        int time_app=2;

        while (getline(file, line)) 
        {
            string current_mr_number, doctor_type, time;
            stringstream ss(line);

            getline(ss, current_mr_number, ',');
            getline(ss, doctor_type, ',');
            getline(ss, time, ',');

            if (stoi(current_mr_number) == MR_number) 
            {
                if(time_app == stoi(time))
                {
                    cout << "Appointment found"<<endl;
                    cout<<endl;
                    cout<<"Calling the endocronologist"<<endl;
                    cout<<endl;
                    cout<<"Press 0 to end the call at any moment"<<endl;
                    bool stop = false;
                
                    auto start = chrono::steady_clock::now();
                    while (!stop) 
                    {
                        char input;
                        if (cin.get(input)) 
                        {
                            if (input == '0') 
                            {
                                stop = true;
                            }
                        }
                        auto end = chrono::steady_clock::now();
                        auto elapsed_seconds = chrono::duration_cast<chrono::seconds>(end - start).count();
                        cout << elapsed_seconds << " seconds" << endl;
                    }
                }
                else
                {
                    cout<<"You dont have an appointment with the doctor at this time so u cant call right now"<<endl;
                }
            }
        }
        file.close();
    }
    else if(choice == 2)
    {
        ifstream file("appointment.dat");
        string line;
        int time_app=12;
    
        while (getline(file, line)) 
        {
            string current_mr_number, doctor_type, time;
            stringstream ss(line);

            getline(ss, current_mr_number, ',');
            getline(ss, doctor_type, ',');
            getline(ss, time, ',');

            if (stoi(current_mr_number) == MR_number) 
            {
                if(time_app == stoi(time))
                {
                    cout << "Appointment found"<<endl;
                    cout<<endl;
                    cout<<"Calling the kidney doctor"<<endl;
                    cout<<endl;
                    cout<<"Press 0 to end the call at any moment"<<endl;
                    bool stop = false;
                
                    auto start = chrono::steady_clock::now();
                    while (!stop) 
                    {
                        char input;
                        if (cin.get(input)) 
                        {
                            if (input == '0') 
                            {
                                stop = true;
                            }
                        }
                        auto end = chrono::steady_clock::now();
                        auto elapsed_seconds = chrono::duration_cast<chrono::seconds>(end - start).count();
                        cout << elapsed_seconds << " seconds" << endl;
                    }
                    
                }
                else
                {
                    cout<<"You dont have an appointment with the doctor at this time so u cant call right now"<<endl;
                }
            }
        }
        file.close();

    }
    else if(choice == 3)
    {
        ifstream file("appointment.dat");
        string line;
        int time_app=2;
       

        while (getline(file, line)) 
        {
            string current_mr_number, doctor_type, time;
            stringstream ss(line);

            getline(ss, current_mr_number, ',');
            getline(ss, doctor_type, ',');
            getline(ss, time, ',');

            if (stoi(current_mr_number) == MR_number) 
            {
                if(time_app == stoi(time))
                {
                    cout << "Appointment found"<<endl;
                    cout<<endl;
                    cout<<"Calling the general surgeuon"<<endl;
                    cout<<endl;
                    cout<<"Press 0 to end the call at any moment"<<endl;
                    bool stop = false;
                
                    auto start = chrono::steady_clock::now();
                    while (!stop) 
                    {
                        char input;
                        if (cin.get(input)) 
                        {
                            if (input == '0') 
                            {
                                stop = true;
                            }
                        }
                        auto end = chrono::steady_clock::now();
                        auto elapsed_seconds = chrono::duration_cast<chrono::seconds>(end - start).count();
                        cout << elapsed_seconds << " seconds" << endl;
                    }
                }
                else
                {
                    cout<<"You dont have an appointment with the doctor at this time so u cant call right now"<<endl;
                }
            }
        }
        file.close();

    }
    else if(choice == 4)
    {
        ifstream file("appointment.dat");
        string line;
        int time_app=1;

        while (getline(file, line)) 
        {
            string current_mr_number, doctor_type, time;
            stringstream ss(line);

            getline(ss, current_mr_number, ',');
            getline(ss, doctor_type, ',');
            getline(ss, time, ',');

            if (stoi(current_mr_number) == MR_number) 
            {
                if(time_app == stoi(time))
                {
                    cout << "Appointment found"<<endl;
                    cout<<endl;
                    cout<<"Calling the dentist"<<endl;
                    cout<<endl;
                    cout<<"Press 0 to end the call at any moment"<<endl;
                    bool stop = false;
                
                    auto start = chrono::steady_clock::now();
                    while (!stop) 
                    {
                        char input;
                        if (cin.get(input)) 
                        {
                            if (input == '0') 
                            {
                                stop = true;
                            }
                        }
                        auto end = chrono::steady_clock::now();
                        auto elapsed_seconds = chrono::duration_cast<chrono::seconds>(end - start).count();
                        cout << elapsed_seconds << " seconds" << endl;
                    }
                }
                else
                {
                    cout<<"You dont have an appointment with the doctor at this time so u cant call right now"<<endl;
                }
            }
        }
        file.close();
    }
    else if(choice == 5)
    {
        ifstream file("appointment.dat");
        string line;
        int time_app=1;

        while (getline(file, line)) 
        {
            string current_mr_number, doctor_type, time;
            stringstream ss(line);

            getline(ss, current_mr_number, ',');
            getline(ss, doctor_type, ',');
            getline(ss, time, ',');

            if (stoi(current_mr_number) == MR_number) 
            {
                if(time_app == stoi(time))
                {
                    cout << "Appointment found"<<endl;
                    cout<<endl;
                    cout<<"Calling the skin doc"<<endl;
                    cout<<endl;
                    cout<<"Press 0 to end the call at any moment"<<endl;
                    bool stop = false;
                
                    auto start = chrono::steady_clock::now();
                    while (!stop) 
                    {
                        char input;
                        if (cin.get(input)) 
                        {
                            if (input == '0') 
                            {
                                stop = true;
                            }
                        }
                        auto end = chrono::steady_clock::now();
                        auto elapsed_seconds = chrono::duration_cast<chrono::seconds>(end - start).count();
                        cout << elapsed_seconds << " seconds" << endl;
                    }
                }
                else
                {
                    cout<<"You dont have an appointment with the doctor at this time so u cant call right now"<<endl;
                }
            }
        }
        file.close();
    }
    //system("cls");
}


void PatientData::create(PatientData obj)
{
    ofstream f("patientdata.dat",ios::binary | ios::app);
    f.write((char*)&obj, sizeof(obj));
    f.close();
}

void PatientData::read(int mr)
{
    ifstream f("patientdata.dat",ios::binary);

    if(!f) 
    {
        cout << "Error opening file" << endl;
        return;
    }
    PatientData obj;
    //int mr_number;

    /*cout<<"Enter MR number to view patient details = ";
    cin>>mr_number;*/

    //bool found=false;

    while(f.read((char*)&obj, sizeof(obj))) 
    {
        if (obj.MR_number == mr) 
        {
        //cout<<"I am here "<<endl;
            obj.info();
        //found = true;
        }
    }
    f.close();
}

void PatientData::kidneyread(int number)
{
    ifstream f("patientdata.dat",ios::binary);

    if(!f) 
    {
        cout << "Error opening file" << endl;
        return;
    }
    PatientData obj;
    //int mr_number;

    //cout<<"Enter MR number to view patient details = ";
    //cin>>mr_number;

    bool found=false;

    while(f.read((char*)&obj, sizeof(obj))) 
    {
        if (obj.MR_number == number) 
        {
            //cout<<"I am here "<<endl;
            obj.infokidney();
            found = true;
        }
    }
    f.close();
    /*cout<<"Name           = "<<name<<endl;
    cout<<"Age            = "<<age<<endl;
    cout<<"MR number      = "<<MR_number<<endl;
    cout<<"Heart Rate     = "<<heart_rate<<endl;
    cout<<"Blood pressure = "<<bp_high<<"/"<<bp_low<<endl;
    cout<<"Oxygen Rate    = "<<oxygen<<endl;*/
    //cout<<"Temperature    = "<<temperature<<endl;
}
void PatientData::generalread(int number)
{
    ifstream f("patientdata.dat",ios::binary);

    if(!f) 
    {
        cout << "Error opening file" << endl;
        return;
    }
    PatientData obj;
    //int mr_number;

    //cout<<"Enter MR number to view patient details = ";
    //cin>>mr_number;

    bool found=false;

    while(f.read((char*)&obj, sizeof(obj))) 
    {
        if (obj.MR_number == number) 
        {
            //cout<<"I am here "<<endl;
            obj.infogeneral();
            found = true;
        }
    }
    f.close();
    /*cout<<"Name           = "<<name<<endl;
    cout<<"Age            = "<<age<<endl;
    cout<<"MR number      = "<<MR_number<<endl;
    cout<<"Heart Rate     = "<<heart_rate<<endl;
    cout<<"Blood pressure = "<<bp_high<<"/"<<bp_low<<endl;
    cout<<"Oxygen Rate    = "<<oxygen<<endl;
    cout<<"Temperature    = "<<temperature<<endl;*/
}
void PatientData::endoread(int number)
{
    ifstream f("patientdata.dat",ios::binary);

    if(!f) 
    {
        cout << "Error opening file" << endl;
        return;
    }
    PatientData obj;
    //int mr_number;

    //cout<<"Enter MR number to view patient details = ";
    //cin>>mr_number;

    bool found=false;

    while(f.read((char*)&obj, sizeof(obj))) 
    {
        if (obj.MR_number == number) 
        {
            //cout<<"I am here "<<endl;
            obj.infoendo();
            found = true;
        }
    }
    f.close();
    /*cout<<"Name           = "<<name<<endl;
    cout<<"Age            = "<<age<<endl;
    cout<<"MR number      = "<<MR_number<<endl;
    cout<<"Heart Rate     = "<<heart_rate<<endl;
    cout<<"Blood pressure = "<<bp_high<<"/"<<bp_low<<endl;*/
    //cout<<"Oxygen Rate    = "<<oxygen<<endl;
    //cout<<"Temperature    = "<<temperature<<endl;
}
void PatientData::dentistread(int number)
{
    ifstream f("patientdata.dat",ios::binary);

    if(!f) 
    {
        cout << "Error opening file" << endl;
        return;
    }
    PatientData obj;
    //int mr_number;

    //cout<<"Enter MR number to view patient details = ";
   // cin>>mr_number;

    bool found=false;

    while(f.read((char*)&obj, sizeof(obj))) 
    {
        if (obj.MR_number == number) 
        {
            //cout<<"I am here "<<endl;
            obj.infodentist();
            found = true;
        }
    }
    f.close();
    /*cout<<"Name           = "<<name<<endl;
    cout<<"Age            = "<<age<<endl;
    cout<<"MR number      = "<<MR_number<<endl;
    cout<<"Heart Rate     = "<<heart_rate<<endl;
    cout<<"Blood pressure = "<<bp_high<<"/"<<bp_low<<endl;*/
    //cout<<"Oxygen Rate    = "<<oxygen<<endl;
    //cout<<"Temperature    = "<<temperature<<endl;
}

void PatientData::skinread(int number)
{
    ifstream f("patientdata.dat",ios::binary);

    if(!f) 
    {
        cout << "Error opening file" << endl;
        return;
    }
    PatientData obj;
    //int mr_number;

    //cout<<"Enter MR number to view patient details = ";
    //cin>>mr_number;

    bool found=false;

    while(f.read((char*)&obj, sizeof(obj))) 
    {
        if (obj.MR_number == number) 
        {
            //cout<<"I am here "<<endl;
            obj.skininfo();
            found = true;
        }
    }
    f.close();
}

void PatientData::infodentist()
{
    cout<<"Name           = "<<name<<endl;
    cout<<"Age            = "<<age<<endl;
    cout<<"MR number      = "<<MR_number<<endl;
    cout<<"Heart Rate     = "<<heart_rate<<endl;
    cout<<"Blood pressure = "<<bp_high<<"/"<<bp_low<<endl;

    set_heart_rate();
    heart_rate = get_heart_rate();
    //cout<<"New heart rate = "<<heart_rate<<endl;
    setbp_low();
    bp_low = getbp_low();
    setbp_high();
    bp_high = getbp_high();
    set_oxygen();
    oxygen = get_oxygen();
    set_temperature();
    temperature = get_temperature();

    if(MR_number==2191)
    {
        PatientData p("Arham Ahmed",18,2191,heart_rate,bp_high,bp_low,oxygen,temperature);
        PatientData p2("John Smith",50,9012,70,159,60,90,100.1);
        PatientData p3("Sarah Williams", 35, 1010, 80, 120, 80, 96, 98.5);
        PatientData p4("James Lee", 42, 2145, 85, 125, 80, 97, 99.2);
        PatientData p5("Jacob Rodriguez", 44, 1002, 87, 128, 82, 96, 100.6);
        PatientData p6("Noman Ali", 38, 5742, 85, 135, 80, 93, 99.8);
        PatientData p7("Farhan Ahmed", 41, 7123, 78, 140, 75, 94, 99.4);
        PatientData p8("Muhammad Ali", 35, 4213, 80, 120, 70, 95, 98.5);
        PatientData p9("Sher Khan", 45, 6321, 70, 130, 75, 97, 99.2);
        PatientData p10("Bandook Khan", 28, 2789, 75, 125, 70, 91, 98.8);

        ofstream file("patientdata.dat", ios::out | ios::binary);
    
        // close the file
        file.close();
        cout << "File emptied successfully." << endl;
        cout<<endl;

        p.randomdata(p);
        p2.randomdata(p2);
        p3.randomdata(p3);
        p4.randomdata(p4);
        p5.randomdata(p5);
        p6.randomdata(p6);
        p7.randomdata(p7);
        p8.randomdata(p8);
        p9.randomdata(p9);
        p10.randomdata(p10);
    }
    else if(MR_number==9012)
    {

        PatientData p("Arham Ahmed",18,2191,60+rand() % 3 + 1,120+rand() % 3 + 1,80+rand() % 3 + 1,70+rand() % 3 + 1,98.6+rand() % 3 + 1);
        PatientData p2("John Smith",50,9012,heart_rate,bp_high,bp_low,oxygen,temperature);
        PatientData p3("Sarah Williams", 35, 1010, 80+rand() % 3 + 1, 120+rand() % 3 + 1, 80+rand() % 3 + 1, 96+rand() % 3 + 1, 98.5+rand() % 2 + 1);
        PatientData p4("James Lee", 42, 2145, 85+rand() % 3 + 1, 125+rand() % 3 + 1, 80+rand() % 3 + 1, 97+rand() % 3 + 1, 99.2+rand() % 3 + 1);
        PatientData p5("Jacob Rodriguez", 44, 1002, 87+rand() % 3 + 1, 128+rand() % 3 + 1, 82+rand() % 3 + 1, 96+rand() % 3 + 1, 99.6+rand() % 3 + 1);
        PatientData p6("Noman Ali", 38, 5742, 85+rand() % 3 + 1, 135+rand() % 3 + 1, 80+rand() % 3 + 1, 93+rand() % 3 + 1, 99.8+rand() % 3 + 1);
        PatientData p7("Farhan Ahmed", 41, 7123, 78+rand() % 3 + 1, 140+rand() % 3 + 1, 75+rand() % 3 + 1, 94+rand() % 3 + 1, 99.4+rand() % 3 + 1);
        PatientData p8("Muhammad Ali", 35, 4213, 80+rand() % 3 + 1, 120+rand() % 3 + 1, 70+rand() % 3 + 1, 95+rand() % 3 + 1, 98.5+rand() % 3 + 1);
        PatientData p9("Sher Khan", 45, 6321, 70+rand() % 3 + 1, 130+rand() % 3 + 1, 75+rand() % 3 + 1, 97+rand() % 3 + 1, 99.2+rand() % 3 + 1);
        PatientData p10("Bandook Khan", 28, 2789, 75+rand() % 3 + 1, 125+rand() % 3 + 1, 70+rand() % 3 + 1, 91+rand() % 3 + 1, 98.8+rand() % 3 + 1);

        ofstream file("patientdata.dat", ios::out | ios::binary);
    
        // close the file
        file.close();
        cout << "File emptied successfully." << endl;
        cout<<endl;

        p.randomdata(p);
        p2.randomdata(p2);
        p3.randomdata(p3);
        p4.randomdata(p4);
        p5.randomdata(p5);
        p6.randomdata(p6);
        p7.randomdata(p7);
        p8.randomdata(p8);
        p9.randomdata(p9);
        p10.randomdata(p10);
    }
    else if(MR_number==1010)
    {
        PatientData p("Arham Ahmed",18,2191,60+rand() % 3 + 1,120+rand() % 3 + 1,80+rand() % 3 + 1,70+rand() % 3 + 1,98.6+rand() % 3 + 1);
        PatientData p2("John Smith",50,9012,80+rand() % 3 + 1, 120+rand() % 3 + 1, 80+rand() % 3 + 1, 96+rand() % 3 + 1, 98.5+rand() % 2 + 1);
        PatientData p3("Sarah Williams", 35, 1010, heart_rate,bp_high,bp_low,oxygen,temperature);
        PatientData p4("James Lee", 42, 2145, 85+rand() % 3 + 1, 125+rand() % 3 + 1, 80+rand() % 3 + 1, 97+rand() % 3 + 1, 99.2+rand() % 3 + 1);
        PatientData p5("Jacob Rodriguez", 44, 1002, 87+rand() % 3 + 1, 128+rand() % 3 + 1, 82+rand() % 3 + 1, 96+rand() % 3 + 1, 99.6+rand() % 3 + 1);
        PatientData p6("Noman Ali", 38, 5742, 85+rand() % 3 + 1, 135+rand() % 3 + 1, 80+rand() % 3 + 1, 93+rand() % 3 + 1, 99.8+rand() % 3 + 1);
        PatientData p7("Farhan Ahmed", 41, 7123, 78+rand() % 3 + 1, 140+rand() % 3 + 1, 75+rand() % 3 + 1, 94+rand() % 3 + 1, 99.4+rand() % 3 + 1);
        PatientData p8("Muhammad Ali", 35, 4213, 80+rand() % 3 + 1, 120+rand() % 3 + 1, 70+rand() % 3 + 1, 95+rand() % 3 + 1, 98.5+rand() % 3 + 1);
        PatientData p9("Sher Khan", 45, 6321, 70+rand() % 3 + 1, 130+rand() % 3 + 1, 75+rand() % 3 + 1, 97+rand() % 3 + 1, 99.2+rand() % 3 + 1);
        PatientData p10("Bandook Khan", 28, 2789, 75+rand() % 3 + 1, 125+rand() % 3 + 1, 70+rand() % 3 + 1, 91+rand() % 3 + 1, 98.8+rand() % 3 + 1);

        ofstream file("patientdata.dat", ios::out | ios::binary);
    
        // close the file
        file.close();
        cout << "File emptied successfully." << endl;
        cout<<endl;

        p.randomdata(p);
        p2.randomdata(p2);
        p3.randomdata(p3);
        p4.randomdata(p4);
        p5.randomdata(p5);
        p6.randomdata(p6);
        p7.randomdata(p7);
        p8.randomdata(p8);
        p9.randomdata(p9);
        p10.randomdata(p10);
    }
    else if(MR_number==2145)
    {
        PatientData p("Arham Ahmed",18,2191,60-rand() % 3 + 1,120-rand() % 3 + 1,80-rand() % 3 + 1,70-rand() % 3 + 1,98.6-rand() % 3 + 1);
        PatientData p2("John Smith",50,9012,85-rand() % 3 + 1, 125-rand() % 3 + 1, 80-rand() % 3 + 1, 97-rand() % 3 + 1, 99.2-rand() % 3 + 1);
        PatientData p3("Sarah Williams", 35, 1010, 80-rand() % 3 + 1, 120-rand() % 3 + 1, 80-rand() % 3 + 1, 96-rand() % 3 + 1, 98.5-rand() % 2 + 1);
        PatientData p4("James Lee", 42, 2145, heart_rate,bp_high,bp_low,oxygen,temperature);
        PatientData p5("Jacob Rodriguez", 44, 1002, 87-rand() % 3 + 1, 128-rand() % 3 + 1, 82-rand() % 3 + 1, 96-rand() % 3 + 1, 100.6-rand() % 3 + 1);
        PatientData p6("Noman Ali", 38, 5742, 85-rand() % 3 + 1, 135-rand() % 3 + 1, 80-rand() % 3 + 1, 93-rand() % 3 + 1, 99.8-rand() % 3 + 1);
        PatientData p7("Farhan Ahmed", 41, 7123, 78-rand() % 3 + 1, 140-rand() % 3 + 1, 75-rand() % 3 + 1, 94-rand() % 3 + 1, 99.4-rand() % 3 + 1);
        PatientData p8("Muhammad Ali", 35, 4213, 80-rand() % 3 + 1, 120-rand() % 3 + 1, 70-rand() % 3 + 1, 95-rand() % 3 + 1, 98.5-rand() % 3 + 1);
        PatientData p9("Sher Khan", 45, 6321, 70-rand() % 3 + 1, 130-rand() % 3 + 1, 75-rand() % 3 + 1, 97-rand() % 3 + 1, 99.2-rand() % 3 + 1);
        PatientData p10("Bandook Khan", 28, 2789, 75-rand() % 3 + 1, 125-rand() % 3 + 1, 70-rand() % 3 + 1, 91-rand() % 3 + 1, 98.8-rand() % 3 + 1);

        ofstream file("patientdata.dat", ios::out | ios::binary);
    
        // close the file
        file.close();
        cout << "File emptied successfully." << endl;
        cout<<endl;

        p.randomdata(p);
        p2.randomdata(p2);
        p3.randomdata(p3);
        p4.randomdata(p4);
        p5.randomdata(p5);
        p6.randomdata(p6);
        p7.randomdata(p7);
        p8.randomdata(p8);
        p9.randomdata(p9);
        p10.randomdata(p10);
    }
    else if(MR_number==1002)
    {
        PatientData p("Arham Ahmed",18,2191,60-rand() % 3 + 1,120-rand() % 3 + 1,80-rand() % 3 + 1,70-rand() % 3 + 1,98.6-rand() % 3 + 1);
        PatientData p2("John Smith",50,9012,85-rand() % 3 + 1, 125-rand() % 3 + 1, 80-rand() % 3 + 1, 97-rand() % 3 + 1, 99.2-rand() % 3 + 1);
        PatientData p3("Sarah Williams", 35, 1010, 80-rand() % 3 + 1, 120-rand() % 3 + 1, 80-rand() % 3 + 1, 96-rand() % 3 + 1, 98.5-rand() % 2 + 1);
        PatientData p4("James Lee", 42, 2145, 85-rand() % 3 + 1, 125-rand() % 3 + 1, 80-rand() % 3 + 1, 97-rand() % 3 + 1, 99.2-rand() % 3 + 1);
        PatientData p5("Jacob Rodriguez", 44, 1002, heart_rate,bp_high,bp_low,oxygen,temperature);
        PatientData p6("Noman Ali", 38, 5742, 85-rand() % 3 + 1, 135-rand() % 3 + 1, 80-rand() % 3 + 1, 93-rand() % 3 + 1, 99.8-rand() % 3 + 1);
        PatientData p7("Farhan Ahmed", 41, 7123, 78-rand() % 3 + 1, 140-rand() % 3 + 1, 75-rand() % 3 + 1, 94-rand() % 3 + 1, 99.4-rand() % 3 + 1);
        PatientData p8("Muhammad Ali", 35, 4213, 80-rand() % 3 + 1, 120-rand() % 3 + 1, 70-rand() % 3 + 1, 95-rand() % 3 + 1, 98.5-rand() % 3 + 1);
        PatientData p9("Sher Khan", 45, 6321, 70-rand() % 3 + 1, 130-rand() % 3 + 1, 75-rand() % 3 + 1, 97-rand() % 3 + 1, 99.2-rand() % 3 + 1);
        PatientData p10("Bandook Khan", 28, 2789, 75-rand() % 3 + 1, 125-rand() % 3 + 1, 70-rand() % 3 + 1, 91-rand() % 3 + 1, 98.8-rand() % 3 + 1);

        ofstream file("patientdata.dat", ios::out | ios::binary);
    
        // close the file
        file.close();
        cout << "File emptied successfully." << endl;
        cout<<endl;

        p.randomdata(p);
        p2.randomdata(p2);
        p3.randomdata(p3);
        p4.randomdata(p4);
        p5.randomdata(p5);
        p6.randomdata(p6);
        p7.randomdata(p7);
        p8.randomdata(p8);
        p9.randomdata(p9);
        p10.randomdata(p10);
    }
    else if(MR_number==5742)
    {
        PatientData p("Arham Ahmed",18,2191,60-rand() % 3 + 1,120-rand() % 3 + 1,80-rand() % 3 + 1,70-rand() % 3 + 1,98.6-rand() % 3 + 1);
        PatientData p2("John Smith",50,9012,85-rand() % 3 + 1, 125-rand() % 3 + 1, 80-rand() % 3 + 1, 97-rand() % 3 + 1, 99.2-rand() % 3 + 1);
        PatientData p3("Sarah Williams", 35, 1010, 80-rand() % 3 + 1, 120-rand() % 3 + 1, 80-rand() % 3 + 1, 96-rand() % 3 + 1, 98.5-rand() % 2 + 1);
        PatientData p4("James Lee", 42, 2145, 85-rand() % 3 + 1, 125-rand() % 3 + 1, 80-rand() % 3 + 1, 97-rand() % 3 + 1, 99.2-rand() % 3 + 1);
        PatientData p5("Jacob Rodriguez", 44, 1002, 87-rand() % 3 + 1, 128-rand() % 3 + 1, 82-rand() % 3 + 1, 96-rand() % 3 + 1, 100.6-rand() % 3 + 1);
        PatientData p6("Noman Ali", 38, 5742, heart_rate,bp_high,bp_low,oxygen,temperature);
        PatientData p7("Farhan Ahmed", 41, 7123, 78-rand() % 3 + 1, 140-rand() % 3 + 1, 75-rand() % 3 + 1, 94-rand() % 3 + 1, 99.4-rand() % 3 + 1);
        PatientData p8("Muhammad Ali", 35, 4213, 80-rand() % 3 + 1, 120-rand() % 3 + 1, 70-rand() % 3 + 1, 95-rand() % 3 + 1, 98.5-rand() % 3 + 1);
        PatientData p9("Sher Khan", 45, 6321, 70-rand() % 3 + 1, 130-rand() % 3 + 1, 75-rand() % 3 + 1, 97-rand() % 3 + 1, 99.2-rand() % 3 + 1);
        PatientData p10("Bandook Khan", 28, 2789, 75-rand() % 3 + 1, 125-rand() % 3 + 1, 70-rand() % 3 + 1, 91-rand() % 3 + 1, 98.8-rand() % 3 + 1);

        ofstream file("patientdata.dat", ios::out | ios::binary);
    
        // close the file
        file.close();
        cout << "File emptied successfully." << endl;
        cout<<endl;

        p.randomdata(p);
        p2.randomdata(p2);
        p3.randomdata(p3);
        p4.randomdata(p4);
        p5.randomdata(p5);
        p6.randomdata(p6);
        p7.randomdata(p7);
        p8.randomdata(p8);
        p9.randomdata(p9);
        p10.randomdata(p10);
    }
    else if(MR_number==7123)
    {
        PatientData p("Arham Ahmed",18,2191,60+rand() % 3 + 1,120+rand() % 3 + 1,80+rand() % 3 + 1,70+rand() % 3 + 1,98.6+rand() % 3 + 1);
        PatientData p2("John Smith",50,9012,78+rand() % 3 + 1, 140+rand() % 3 + 1, 75+rand() % 3 + 1, 94+rand() % 3 + 1, 99.4+rand() % 3 + 1);
        PatientData p3("Sarah Williams", 35, 1010, 80+rand() % 3 + 1, 120+rand() % 3 + 1, 80+rand() % 3 + 1, 96+rand() % 3 + 1, 98.5+rand() % 2 + 1);
        PatientData p4("James Lee", 42, 2145, 85+rand() % 3 + 1, 125+rand() % 3 + 1, 80+rand() % 3 + 1, 97+rand() % 3 + 1, 99.2+rand() % 3 + 1);
        PatientData p5("Jacob Rodriguez", 44, 1002, 87+rand() % 3 + 1, 128+rand() % 3 + 1, 82+rand() % 3 + 1, 96+rand() % 3 + 1, 99.6+rand() % 3 + 1);
        PatientData p6("Noman Ali", 38, 5742, 85+rand() % 3 + 1, 135+rand() % 3 + 1, 80+rand() % 3 + 1, 93+rand() % 3 + 1, 99.8+rand() % 3 + 1);
        PatientData p7("Farhan Ahmed", 41, 7123, heart_rate,bp_high,bp_low,oxygen,temperature);
        PatientData p8("Muhammad Ali", 35, 4213, 80+rand() % 3 + 1, 120+rand() % 3 + 1, 70+rand() % 3 + 1, 95+rand() % 3 + 1, 98.5+rand() % 3 + 1);
        PatientData p9("Sher Khan", 45, 6321, 70+rand() % 3 + 1, 130+rand() % 3 + 1, 75+rand() % 3 + 1, 97+rand() % 3 + 1, 99.2+rand() % 3 + 1);
        PatientData p10("Bandook Khan", 28, 2789, 75+rand() % 3 + 1, 125+rand() % 3 + 1, 70+rand() % 3 + 1, 91+rand() % 3 + 1, 98.8+rand() % 3 + 1);

        ofstream file("patientdata.dat", ios::out | ios::binary);
    
        // close the file
        file.close();
        cout << "File emptied successfully." << endl;
        cout<<endl;

        p.randomdata(p);
        p2.randomdata(p2);
        p3.randomdata(p3);
        p4.randomdata(p4);
        p5.randomdata(p5);
        p6.randomdata(p6);
        p7.randomdata(p7);
        p8.randomdata(p8);
        p9.randomdata(p9);
        p10.randomdata(p10);
    }
    else if(MR_number==4213)
    {
        PatientData p("Arham Ahmed",18,2191,60+rand() % 3 + 1,120+rand() % 3 + 1,80+rand() % 3 + 1,70+rand() % 3 + 1,98.6+rand() % 3 + 1);
        PatientData p2("John Smith",50,9012,78+rand() % 3 + 1, 140+rand() % 3 + 1, 75+rand() % 3 + 1, 94+rand() % 3 + 1, 99.4+rand() % 3 + 1);
        PatientData p3("Sarah Williams", 35, 1010, 80+rand() % 3 + 1, 120+rand() % 3 + 1, 80+rand() % 3 + 1, 96+rand() % 3 + 1, 98.5+rand() % 2 + 1);
        PatientData p4("James Lee", 42, 2145, 85+rand() % 3 + 1, 125+rand() % 3 + 1, 80+rand() % 3 + 1, 97+rand() % 3 + 1, 99.2+rand() % 3 + 1);
        PatientData p5("Jacob Rodriguez", 44, 1002, 87+rand() % 3 + 1, 128+rand() % 3 + 1, 82+rand() % 3 + 1, 96+rand() % 3 + 1, 99.6+rand() % 3 + 1);
        PatientData p6("Noman Ali", 38, 5742, 85+rand() % 3 + 1, 135+rand() % 3 + 1, 80+rand() % 3 + 1, 93+rand() % 3 + 1, 99.8+rand() % 3 + 1);
        PatientData p7("Farhan Ahmed", 41, 7123,80+rand() % 3 + 1, 120+rand() % 3 + 1, 70+rand() % 3 + 1, 95+rand() % 3 + 1, 98.5+rand() % 3 + 1);
        PatientData p8("Muhammad Ali", 35, 4213, heart_rate,bp_high,bp_low,oxygen,temperature);
        PatientData p9("Sher Khan", 45, 6321, 70+rand() % 3 + 1, 130+rand() % 3 + 1, 75+rand() % 3 + 1, 97+rand() % 3 + 1, 99.2+rand() % 3 + 1);
        PatientData p10("Bandook Khan", 28, 2789, 75+rand() % 3 + 1, 125+rand() % 3 + 1, 70+rand() % 3 + 1, 91+rand() % 3 + 1, 98.8+rand() % 3 + 1);

        ofstream file("patientdata.dat", ios::out | ios::binary);
    
        // close the file
        file.close();
        cout << "File emptied successfully." << endl;
        cout<<endl;

        p.randomdata(p);
        p2.randomdata(p2);
        p3.randomdata(p3);
        p4.randomdata(p4);
        p5.randomdata(p5);
        p6.randomdata(p6);
        p7.randomdata(p7);
        p8.randomdata(p8);
        p9.randomdata(p9);
        p10.randomdata(p10);
    }
    else if(MR_number==6321)
    {
        PatientData p("Arham Ahmed",18,2191,60+rand() % 3 + 1,120+rand() % 3 + 1,80+rand() % 3 + 1,70+rand() % 3 + 1,98.6+rand() % 3 + 1);
        PatientData p2("John Smith",50,9012,78+rand() % 3 + 1, 140+rand() % 3 + 1, 75+rand() % 3 + 1, 94+rand() % 3 + 1, 99.4+rand() % 3 + 1);
        PatientData p3("Sarah Williams", 35, 1010, 80+rand() % 3 + 1, 120+rand() % 3 + 1, 80+rand() % 3 + 1, 96+rand() % 3 + 1, 98.5+rand() % 2 + 1);
        PatientData p4("James Lee", 42, 2145, 85+rand() % 3 + 1, 125+rand() % 3 + 1, 80+rand() % 3 + 1, 97+rand() % 3 + 1, 99.2+rand() % 3 + 1);
        PatientData p5("Jacob Rodriguez", 44, 1002, 87+rand() % 3 + 1, 128+rand() % 3 + 1, 82+rand() % 3 + 1, 96+rand() % 3 + 1, 99.6+rand() % 3 + 1);
        PatientData p6("Noman Ali", 38, 5742, 85+rand() % 3 + 1, 135+rand() % 3 + 1, 80+rand() % 3 + 1, 93+rand() % 3 + 1, 99.8+rand() % 3 + 1);
        PatientData p7("Farhan Ahmed", 41, 7123,80+rand() % 3 + 1, 120+rand() % 3 + 1, 70+rand() % 3 + 1, 95+rand() % 3 + 1, 98.5+rand() % 3 + 1);
        PatientData p8("Muhammad Ali", 35, 4213, 70+rand() % 3 + 1, 130+rand() % 3 + 1, 75+rand() % 3 + 1, 97+rand() % 3 + 1, 99.2+rand() % 3 + 1);
        PatientData p9("Sher Khan", 45, 6321, heart_rate,bp_high,bp_low,oxygen,temperature);
        PatientData p10("Bandook Khan", 28, 2789, 75+rand() % 3 + 1, 125+rand() % 3 + 1, 70+rand() % 3 + 1, 91+rand() % 3 + 1, 98.8+rand() % 3 + 1);

        ofstream file("patientdata.dat", ios::out | ios::binary);
    
        // close the file
        file.close();
        cout << "File emptied successfully." << endl;
        cout<<endl;

        p.randomdata(p);
        p2.randomdata(p2);
        p3.randomdata(p3);
        p4.randomdata(p4);
        p5.randomdata(p5);
        p6.randomdata(p6);
        p7.randomdata(p7);
        p8.randomdata(p8);
        p9.randomdata(p9);
        p10.randomdata(p10);
    }
    else if(MR_number==2789)
    {
        PatientData p("Arham Ahmed",18,2191,60+rand() % 3 + 1,120+rand() % 3 + 1,80+rand() % 3 + 1,70+rand() % 3 + 1,98.6+rand() % 3 + 1);
        PatientData p2("John Smith",50,9012,78+rand() % 3 + 1, 140+rand() % 3 + 1, 75+rand() % 3 + 1, 94+rand() % 3 + 1, 99.4+rand() % 3 + 1);
        PatientData p3("Sarah Williams", 35, 1010, 80+rand() % 3 + 1, 120+rand() % 3 + 1, 80+rand() % 3 + 1, 96+rand() % 3 + 1, 98.5+rand() % 2 + 1);
        PatientData p4("James Lee", 42, 2145, 85+rand() % 3 + 1, 125+rand() % 3 + 1, 80+rand() % 3 + 1, 97+rand() % 3 + 1, 99.2+rand() % 3 + 1);
        PatientData p5("Jacob Rodriguez", 44, 1002, 87+rand() % 3 + 1, 128+rand() % 3 + 1, 82+rand() % 3 + 1, 96+rand() % 3 + 1, 99.6+rand() % 3 + 1);
        PatientData p6("Noman Ali", 38, 5742, 85+rand() % 3 + 1, 135+rand() % 3 + 1, 80+rand() % 3 + 1, 93+rand() % 3 + 1, 99.8+rand() % 3 + 1);
        PatientData p7("Farhan Ahmed", 41, 7123,80+rand() % 3 + 1, 120+rand() % 3 + 1, 70+rand() % 3 + 1, 95+rand() % 3 + 1, 98.5+rand() % 3 + 1);
        PatientData p8("Muhammad Ali", 35, 4213, 70+rand() % 3 + 1, 130+rand() % 3 + 1, 75+rand() % 3 + 1, 97+rand() % 3 + 1, 99.2+rand() % 3 + 1);
        PatientData p9("Sher Khan", 45, 6321, 75+rand() % 3 + 1, 125+rand() % 3 + 1, 70+rand() % 3 + 1, 91+rand() % 3 + 1, 98.8+rand() % 3 + 1);
        PatientData p10("Bandook Khan", 28, 2789, heart_rate,bp_high,bp_low,oxygen,temperature);

        ofstream file("patientdata.dat", ios::out | ios::binary);
    
        // close the file
        file.close();
        cout << "File emptied successfully." << endl;
        cout<<endl;

        p.randomdata(p);
        p2.randomdata(p2);
        p3.randomdata(p3);
        p4.randomdata(p4);
        p5.randomdata(p5);
        p6.randomdata(p6);
        p7.randomdata(p7);
        p8.randomdata(p8);
        p9.randomdata(p9);
        p10.randomdata(p10);
    }
}

void PatientData::infoendo()
{
    cout<<"Name           = "<<name<<endl;
    cout<<"Age            = "<<age<<endl;
    cout<<"MR number      = "<<MR_number<<endl;
    cout<<"Heart Rate     = "<<heart_rate<<endl;
    cout<<"Blood pressure = "<<bp_high<<"/"<<bp_low<<endl;

    set_heart_rate();
    heart_rate = get_heart_rate();
    //cout<<"New heart rate = "<<heart_rate<<endl;
    setbp_low();
    bp_low = getbp_low();
    setbp_high();
    bp_high = getbp_high();
    set_oxygen();
    oxygen = get_oxygen();
    set_temperature();
    temperature = get_temperature();

    if(MR_number==2191)
    {
        PatientData p("Arham Ahmed",18,2191,heart_rate,bp_high,bp_low,oxygen,temperature);
        PatientData p2("John Smith",50,9012,70,159,60,90,100.1);
        PatientData p3("Sarah Williams", 35, 1010, 80, 120, 80, 96, 98.5);
        PatientData p4("James Lee", 42, 2145, 85, 125, 80, 97, 99.2);
        PatientData p5("Jacob Rodriguez", 44, 1002, 87, 128, 82, 96, 100.6);
        PatientData p6("Noman Ali", 38, 5742, 85, 135, 80, 93, 99.8);
        PatientData p7("Farhan Ahmed", 41, 7123, 78, 140, 75, 94, 99.4);
        PatientData p8("Muhammad Ali", 35, 4213, 80, 120, 70, 95, 98.5);
        PatientData p9("Sher Khan", 45, 6321, 70, 130, 75, 97, 99.2);
        PatientData p10("Bandook Khan", 28, 2789, 75, 125, 70, 91, 98.8);

        ofstream file("patientdata.dat", ios::out | ios::binary);
    
        // close the file
        file.close();
        cout << "File emptied successfully." << endl;
        cout<<endl;

        p.randomdata(p);
        p2.randomdata(p2);
        p3.randomdata(p3);
        p4.randomdata(p4);
        p5.randomdata(p5);
        p6.randomdata(p6);
        p7.randomdata(p7);
        p8.randomdata(p8);
        p9.randomdata(p9);
        p10.randomdata(p10);
    }
    else if(MR_number==9012)
    {

        PatientData p("Arham Ahmed",18,2191,60+rand() % 3 + 1,120+rand() % 3 + 1,80+rand() % 3 + 1,70+rand() % 3 + 1,98.6+rand() % 3 + 1);
        PatientData p2("John Smith",50,9012,heart_rate,bp_high,bp_low,oxygen,temperature);
        PatientData p3("Sarah Williams", 35, 1010, 80+rand() % 3 + 1, 120+rand() % 3 + 1, 80+rand() % 3 + 1, 96+rand() % 3 + 1, 98.5+rand() % 2 + 1);
        PatientData p4("James Lee", 42, 2145, 85+rand() % 3 + 1, 125+rand() % 3 + 1, 80+rand() % 3 + 1, 97+rand() % 3 + 1, 99.2+rand() % 3 + 1);
        PatientData p5("Jacob Rodriguez", 44, 1002, 87+rand() % 3 + 1, 128+rand() % 3 + 1, 82+rand() % 3 + 1, 96+rand() % 3 + 1, 99.6+rand() % 3 + 1);
        PatientData p6("Noman Ali", 38, 5742, 85+rand() % 3 + 1, 135+rand() % 3 + 1, 80+rand() % 3 + 1, 93+rand() % 3 + 1, 99.8+rand() % 3 + 1);
        PatientData p7("Farhan Ahmed", 41, 7123, 78+rand() % 3 + 1, 140+rand() % 3 + 1, 75+rand() % 3 + 1, 94+rand() % 3 + 1, 99.4+rand() % 3 + 1);
        PatientData p8("Muhammad Ali", 35, 4213, 80+rand() % 3 + 1, 120+rand() % 3 + 1, 70+rand() % 3 + 1, 95+rand() % 3 + 1, 98.5+rand() % 3 + 1);
        PatientData p9("Sher Khan", 45, 6321, 70+rand() % 3 + 1, 130+rand() % 3 + 1, 75+rand() % 3 + 1, 97+rand() % 3 + 1, 99.2+rand() % 3 + 1);
        PatientData p10("Bandook Khan", 28, 2789, 75+rand() % 3 + 1, 125+rand() % 3 + 1, 70+rand() % 3 + 1, 91+rand() % 3 + 1, 98.8+rand() % 3 + 1);

        ofstream file("patientdata.dat", ios::out | ios::binary);
    
        // close the file
        file.close();
        cout << "File emptied successfully." << endl;
        cout<<endl;

        p.randomdata(p);
        p2.randomdata(p2);
        p3.randomdata(p3);
        p4.randomdata(p4);
        p5.randomdata(p5);
        p6.randomdata(p6);
        p7.randomdata(p7);
        p8.randomdata(p8);
        p9.randomdata(p9);
        p10.randomdata(p10);
    }
    else if(MR_number==1010)
    {
        PatientData p("Arham Ahmed",18,2191,60+rand() % 3 + 1,120+rand() % 3 + 1,80+rand() % 3 + 1,70+rand() % 3 + 1,98.6+rand() % 3 + 1);
        PatientData p2("John Smith",50,9012,80+rand() % 3 + 1, 120+rand() % 3 + 1, 80+rand() % 3 + 1, 96+rand() % 3 + 1, 98.5+rand() % 2 + 1);
        PatientData p3("Sarah Williams", 35, 1010, heart_rate,bp_high,bp_low,oxygen,temperature);
        PatientData p4("James Lee", 42, 2145, 85+rand() % 3 + 1, 125+rand() % 3 + 1, 80+rand() % 3 + 1, 97+rand() % 3 + 1, 99.2+rand() % 3 + 1);
        PatientData p5("Jacob Rodriguez", 44, 1002, 87+rand() % 3 + 1, 128+rand() % 3 + 1, 82+rand() % 3 + 1, 96+rand() % 3 + 1, 99.6+rand() % 3 + 1);
        PatientData p6("Noman Ali", 38, 5742, 85+rand() % 3 + 1, 135+rand() % 3 + 1, 80+rand() % 3 + 1, 93+rand() % 3 + 1, 99.8+rand() % 3 + 1);
        PatientData p7("Farhan Ahmed", 41, 7123, 78+rand() % 3 + 1, 140+rand() % 3 + 1, 75+rand() % 3 + 1, 94+rand() % 3 + 1, 99.4+rand() % 3 + 1);
        PatientData p8("Muhammad Ali", 35, 4213, 80+rand() % 3 + 1, 120+rand() % 3 + 1, 70+rand() % 3 + 1, 95+rand() % 3 + 1, 98.5+rand() % 3 + 1);
        PatientData p9("Sher Khan", 45, 6321, 70+rand() % 3 + 1, 130+rand() % 3 + 1, 75+rand() % 3 + 1, 97+rand() % 3 + 1, 99.2+rand() % 3 + 1);
        PatientData p10("Bandook Khan", 28, 2789, 75+rand() % 3 + 1, 125+rand() % 3 + 1, 70+rand() % 3 + 1, 91+rand() % 3 + 1, 98.8+rand() % 3 + 1);

        ofstream file("patientdata.dat", ios::out | ios::binary);
    
        // close the file
        file.close();
        cout << "File emptied successfully." << endl;
        cout<<endl;

        p.randomdata(p);
        p2.randomdata(p2);
        p3.randomdata(p3);
        p4.randomdata(p4);
        p5.randomdata(p5);
        p6.randomdata(p6);
        p7.randomdata(p7);
        p8.randomdata(p8);
        p9.randomdata(p9);
        p10.randomdata(p10);
    }
    else if(MR_number==2145)
    {
        PatientData p("Arham Ahmed",18,2191,60-rand() % 3 + 1,120-rand() % 3 + 1,80-rand() % 3 + 1,70-rand() % 3 + 1,98.6-rand() % 3 + 1);
        PatientData p2("John Smith",50,9012,85-rand() % 3 + 1, 125-rand() % 3 + 1, 80-rand() % 3 + 1, 97-rand() % 3 + 1, 99.2-rand() % 3 + 1);
        PatientData p3("Sarah Williams", 35, 1010, 80-rand() % 3 + 1, 120-rand() % 3 + 1, 80-rand() % 3 + 1, 96-rand() % 3 + 1, 98.5-rand() % 2 + 1);
        PatientData p4("James Lee", 42, 2145, heart_rate,bp_high,bp_low,oxygen,temperature);
        PatientData p5("Jacob Rodriguez", 44, 1002, 87-rand() % 3 + 1, 128-rand() % 3 + 1, 82-rand() % 3 + 1, 96-rand() % 3 + 1, 100.6-rand() % 3 + 1);
        PatientData p6("Noman Ali", 38, 5742, 85-rand() % 3 + 1, 135-rand() % 3 + 1, 80-rand() % 3 + 1, 93-rand() % 3 + 1, 99.8-rand() % 3 + 1);
        PatientData p7("Farhan Ahmed", 41, 7123, 78-rand() % 3 + 1, 140-rand() % 3 + 1, 75-rand() % 3 + 1, 94-rand() % 3 + 1, 99.4-rand() % 3 + 1);
        PatientData p8("Muhammad Ali", 35, 4213, 80-rand() % 3 + 1, 120-rand() % 3 + 1, 70-rand() % 3 + 1, 95-rand() % 3 + 1, 98.5-rand() % 3 + 1);
        PatientData p9("Sher Khan", 45, 6321, 70-rand() % 3 + 1, 130-rand() % 3 + 1, 75-rand() % 3 + 1, 97-rand() % 3 + 1, 99.2-rand() % 3 + 1);
        PatientData p10("Bandook Khan", 28, 2789, 75-rand() % 3 + 1, 125-rand() % 3 + 1, 70-rand() % 3 + 1, 91-rand() % 3 + 1, 98.8-rand() % 3 + 1);

        ofstream file("patientdata.dat", ios::out | ios::binary);
    
        // close the file
        file.close();
        cout << "File emptied successfully." << endl;
        cout<<endl;

        p.randomdata(p);
        p2.randomdata(p2);
        p3.randomdata(p3);
        p4.randomdata(p4);
        p5.randomdata(p5);
        p6.randomdata(p6);
        p7.randomdata(p7);
        p8.randomdata(p8);
        p9.randomdata(p9);
        p10.randomdata(p10);
    }
    else if(MR_number==1002)
    {
        PatientData p("Arham Ahmed",18,2191,60-rand() % 3 + 1,120-rand() % 3 + 1,80-rand() % 3 + 1,70-rand() % 3 + 1,98.6-rand() % 3 + 1);
        PatientData p2("John Smith",50,9012,85-rand() % 3 + 1, 125-rand() % 3 + 1, 80-rand() % 3 + 1, 97-rand() % 3 + 1, 99.2-rand() % 3 + 1);
        PatientData p3("Sarah Williams", 35, 1010, 80-rand() % 3 + 1, 120-rand() % 3 + 1, 80-rand() % 3 + 1, 96-rand() % 3 + 1, 98.5-rand() % 2 + 1);
        PatientData p4("James Lee", 42, 2145, 85-rand() % 3 + 1, 125-rand() % 3 + 1, 80-rand() % 3 + 1, 97-rand() % 3 + 1, 99.2-rand() % 3 + 1);
        PatientData p5("Jacob Rodriguez", 44, 1002, heart_rate,bp_high,bp_low,oxygen,temperature);
        PatientData p6("Noman Ali", 38, 5742, 85-rand() % 3 + 1, 135-rand() % 3 + 1, 80-rand() % 3 + 1, 93-rand() % 3 + 1, 99.8-rand() % 3 + 1);
        PatientData p7("Farhan Ahmed", 41, 7123, 78-rand() % 3 + 1, 140-rand() % 3 + 1, 75-rand() % 3 + 1, 94-rand() % 3 + 1, 99.4-rand() % 3 + 1);
        PatientData p8("Muhammad Ali", 35, 4213, 80-rand() % 3 + 1, 120-rand() % 3 + 1, 70-rand() % 3 + 1, 95-rand() % 3 + 1, 98.5-rand() % 3 + 1);
        PatientData p9("Sher Khan", 45, 6321, 70-rand() % 3 + 1, 130-rand() % 3 + 1, 75-rand() % 3 + 1, 97-rand() % 3 + 1, 99.2-rand() % 3 + 1);
        PatientData p10("Bandook Khan", 28, 2789, 75-rand() % 3 + 1, 125-rand() % 3 + 1, 70-rand() % 3 + 1, 91-rand() % 3 + 1, 98.8-rand() % 3 + 1);

        ofstream file("patientdata.dat", ios::out | ios::binary);
    
        // close the file
        file.close();
        cout << "File emptied successfully." << endl;
        cout<<endl;

        p.randomdata(p);
        p2.randomdata(p2);
        p3.randomdata(p3);
        p4.randomdata(p4);
        p5.randomdata(p5);
        p6.randomdata(p6);
        p7.randomdata(p7);
        p8.randomdata(p8);
        p9.randomdata(p9);
        p10.randomdata(p10);
    }
    else if(MR_number==5742)
    {
        PatientData p("Arham Ahmed",18,2191,60-rand() % 3 + 1,120-rand() % 3 + 1,80-rand() % 3 + 1,70-rand() % 3 + 1,98.6-rand() % 3 + 1);
        PatientData p2("John Smith",50,9012,85-rand() % 3 + 1, 125-rand() % 3 + 1, 80-rand() % 3 + 1, 97-rand() % 3 + 1, 99.2-rand() % 3 + 1);
        PatientData p3("Sarah Williams", 35, 1010, 80-rand() % 3 + 1, 120-rand() % 3 + 1, 80-rand() % 3 + 1, 96-rand() % 3 + 1, 98.5-rand() % 2 + 1);
        PatientData p4("James Lee", 42, 2145, 85-rand() % 3 + 1, 125-rand() % 3 + 1, 80-rand() % 3 + 1, 97-rand() % 3 + 1, 99.2-rand() % 3 + 1);
        PatientData p5("Jacob Rodriguez", 44, 1002, 87-rand() % 3 + 1, 128-rand() % 3 + 1, 82-rand() % 3 + 1, 96-rand() % 3 + 1, 100.6-rand() % 3 + 1);
        PatientData p6("Noman Ali", 38, 5742, heart_rate,bp_high,bp_low,oxygen,temperature);
        PatientData p7("Farhan Ahmed", 41, 7123, 78-rand() % 3 + 1, 140-rand() % 3 + 1, 75-rand() % 3 + 1, 94-rand() % 3 + 1, 99.4-rand() % 3 + 1);
        PatientData p8("Muhammad Ali", 35, 4213, 80-rand() % 3 + 1, 120-rand() % 3 + 1, 70-rand() % 3 + 1, 95-rand() % 3 + 1, 98.5-rand() % 3 + 1);
        PatientData p9("Sher Khan", 45, 6321, 70-rand() % 3 + 1, 130-rand() % 3 + 1, 75-rand() % 3 + 1, 97-rand() % 3 + 1, 99.2-rand() % 3 + 1);
        PatientData p10("Bandook Khan", 28, 2789, 75-rand() % 3 + 1, 125-rand() % 3 + 1, 70-rand() % 3 + 1, 91-rand() % 3 + 1, 98.8-rand() % 3 + 1);

        ofstream file("patientdata.dat", ios::out | ios::binary);
    
        // close the file
        file.close();
        cout << "File emptied successfully." << endl;
        cout<<endl;

        p.randomdata(p);
        p2.randomdata(p2);
        p3.randomdata(p3);
        p4.randomdata(p4);
        p5.randomdata(p5);
        p6.randomdata(p6);
        p7.randomdata(p7);
        p8.randomdata(p8);
        p9.randomdata(p9);
        p10.randomdata(p10);
    }
    else if(MR_number==7123)
    {
        PatientData p("Arham Ahmed",18,2191,60+rand() % 3 + 1,120+rand() % 3 + 1,80+rand() % 3 + 1,70+rand() % 3 + 1,98.6+rand() % 3 + 1);
        PatientData p2("John Smith",50,9012,78+rand() % 3 + 1, 140+rand() % 3 + 1, 75+rand() % 3 + 1, 94+rand() % 3 + 1, 99.4+rand() % 3 + 1);
        PatientData p3("Sarah Williams", 35, 1010, 80+rand() % 3 + 1, 120+rand() % 3 + 1, 80+rand() % 3 + 1, 96+rand() % 3 + 1, 98.5+rand() % 2 + 1);
        PatientData p4("James Lee", 42, 2145, 85+rand() % 3 + 1, 125+rand() % 3 + 1, 80+rand() % 3 + 1, 97+rand() % 3 + 1, 99.2+rand() % 3 + 1);
        PatientData p5("Jacob Rodriguez", 44, 1002, 87+rand() % 3 + 1, 128+rand() % 3 + 1, 82+rand() % 3 + 1, 96+rand() % 3 + 1, 99.6+rand() % 3 + 1);
        PatientData p6("Noman Ali", 38, 5742, 85+rand() % 3 + 1, 135+rand() % 3 + 1, 80+rand() % 3 + 1, 93+rand() % 3 + 1, 99.8+rand() % 3 + 1);
        PatientData p7("Farhan Ahmed", 41, 7123, heart_rate,bp_high,bp_low,oxygen,temperature);
        PatientData p8("Muhammad Ali", 35, 4213, 80+rand() % 3 + 1, 120+rand() % 3 + 1, 70+rand() % 3 + 1, 95+rand() % 3 + 1, 98.5+rand() % 3 + 1);
        PatientData p9("Sher Khan", 45, 6321, 70+rand() % 3 + 1, 130+rand() % 3 + 1, 75+rand() % 3 + 1, 97+rand() % 3 + 1, 99.2+rand() % 3 + 1);
        PatientData p10("Bandook Khan", 28, 2789, 75+rand() % 3 + 1, 125+rand() % 3 + 1, 70+rand() % 3 + 1, 91+rand() % 3 + 1, 98.8+rand() % 3 + 1);

        ofstream file("patientdata.dat", ios::out | ios::binary);
    
        // close the file
        file.close();
        cout << "File emptied successfully." << endl;
        cout<<endl;

        p.randomdata(p);
        p2.randomdata(p2);
        p3.randomdata(p3);
        p4.randomdata(p4);
        p5.randomdata(p5);
        p6.randomdata(p6);
        p7.randomdata(p7);
        p8.randomdata(p8);
        p9.randomdata(p9);
        p10.randomdata(p10);
    }
    else if(MR_number==4213)
    {
        PatientData p("Arham Ahmed",18,2191,60+rand() % 3 + 1,120+rand() % 3 + 1,80+rand() % 3 + 1,70+rand() % 3 + 1,98.6+rand() % 3 + 1);
        PatientData p2("John Smith",50,9012,78+rand() % 3 + 1, 140+rand() % 3 + 1, 75+rand() % 3 + 1, 94+rand() % 3 + 1, 99.4+rand() % 3 + 1);
        PatientData p3("Sarah Williams", 35, 1010, 80+rand() % 3 + 1, 120+rand() % 3 + 1, 80+rand() % 3 + 1, 96+rand() % 3 + 1, 98.5+rand() % 2 + 1);
        PatientData p4("James Lee", 42, 2145, 85+rand() % 3 + 1, 125+rand() % 3 + 1, 80+rand() % 3 + 1, 97+rand() % 3 + 1, 99.2+rand() % 3 + 1);
        PatientData p5("Jacob Rodriguez", 44, 1002, 87+rand() % 3 + 1, 128+rand() % 3 + 1, 82+rand() % 3 + 1, 96+rand() % 3 + 1, 99.6+rand() % 3 + 1);
        PatientData p6("Noman Ali", 38, 5742, 85+rand() % 3 + 1, 135+rand() % 3 + 1, 80+rand() % 3 + 1, 93+rand() % 3 + 1, 99.8+rand() % 3 + 1);
        PatientData p7("Farhan Ahmed", 41, 7123,80+rand() % 3 + 1, 120+rand() % 3 + 1, 70+rand() % 3 + 1, 95+rand() % 3 + 1, 98.5+rand() % 3 + 1);
        PatientData p8("Muhammad Ali", 35, 4213, heart_rate,bp_high,bp_low,oxygen,temperature);
        PatientData p9("Sher Khan", 45, 6321, 70+rand() % 3 + 1, 130+rand() % 3 + 1, 75+rand() % 3 + 1, 97+rand() % 3 + 1, 99.2+rand() % 3 + 1);
        PatientData p10("Bandook Khan", 28, 2789, 75+rand() % 3 + 1, 125+rand() % 3 + 1, 70+rand() % 3 + 1, 91+rand() % 3 + 1, 98.8+rand() % 3 + 1);

        ofstream file("patientdata.dat", ios::out | ios::binary);
    
        // close the file
        file.close();
        cout << "File emptied successfully." << endl;
        cout<<endl;

        p.randomdata(p);
        p2.randomdata(p2);
        p3.randomdata(p3);
        p4.randomdata(p4);
        p5.randomdata(p5);
        p6.randomdata(p6);
        p7.randomdata(p7);
        p8.randomdata(p8);
        p9.randomdata(p9);
        p10.randomdata(p10);
    }
    else if(MR_number==6321)
    {
        PatientData p("Arham Ahmed",18,2191,60+rand() % 3 + 1,120+rand() % 3 + 1,80+rand() % 3 + 1,70+rand() % 3 + 1,98.6+rand() % 3 + 1);
        PatientData p2("John Smith",50,9012,78+rand() % 3 + 1, 140+rand() % 3 + 1, 75+rand() % 3 + 1, 94+rand() % 3 + 1, 99.4+rand() % 3 + 1);
        PatientData p3("Sarah Williams", 35, 1010, 80+rand() % 3 + 1, 120+rand() % 3 + 1, 80+rand() % 3 + 1, 96+rand() % 3 + 1, 98.5+rand() % 2 + 1);
        PatientData p4("James Lee", 42, 2145, 85+rand() % 3 + 1, 125+rand() % 3 + 1, 80+rand() % 3 + 1, 97+rand() % 3 + 1, 99.2+rand() % 3 + 1);
        PatientData p5("Jacob Rodriguez", 44, 1002, 87+rand() % 3 + 1, 128+rand() % 3 + 1, 82+rand() % 3 + 1, 96+rand() % 3 + 1, 99.6+rand() % 3 + 1);
        PatientData p6("Noman Ali", 38, 5742, 85+rand() % 3 + 1, 135+rand() % 3 + 1, 80+rand() % 3 + 1, 93+rand() % 3 + 1, 99.8+rand() % 3 + 1);
        PatientData p7("Farhan Ahmed", 41, 7123,80+rand() % 3 + 1, 120+rand() % 3 + 1, 70+rand() % 3 + 1, 95+rand() % 3 + 1, 98.5+rand() % 3 + 1);
        PatientData p8("Muhammad Ali", 35, 4213, 70+rand() % 3 + 1, 130+rand() % 3 + 1, 75+rand() % 3 + 1, 97+rand() % 3 + 1, 99.2+rand() % 3 + 1);
        PatientData p9("Sher Khan", 45, 6321, heart_rate,bp_high,bp_low,oxygen,temperature);
        PatientData p10("Bandook Khan", 28, 2789, 75+rand() % 3 + 1, 125+rand() % 3 + 1, 70+rand() % 3 + 1, 91+rand() % 3 + 1, 98.8+rand() % 3 + 1);

        ofstream file("patientdata.dat", ios::out | ios::binary);
    
        // close the file
        file.close();
        cout << "File emptied successfully." << endl;
        cout<<endl;

        p.randomdata(p);
        p2.randomdata(p2);
        p3.randomdata(p3);
        p4.randomdata(p4);
        p5.randomdata(p5);
        p6.randomdata(p6);
        p7.randomdata(p7);
        p8.randomdata(p8);
        p9.randomdata(p9);
        p10.randomdata(p10);
    }
    else if(MR_number==2789)
    {
        PatientData p("Arham Ahmed",18,2191,60+rand() % 3 + 1,120+rand() % 3 + 1,80+rand() % 3 + 1,70+rand() % 3 + 1,98.6+rand() % 3 + 1);
        PatientData p2("John Smith",50,9012,78+rand() % 3 + 1, 140+rand() % 3 + 1, 75+rand() % 3 + 1, 94+rand() % 3 + 1, 99.4+rand() % 3 + 1);
        PatientData p3("Sarah Williams", 35, 1010, 80+rand() % 3 + 1, 120+rand() % 3 + 1, 80+rand() % 3 + 1, 96+rand() % 3 + 1, 98.5+rand() % 2 + 1);
        PatientData p4("James Lee", 42, 2145, 85+rand() % 3 + 1, 125+rand() % 3 + 1, 80+rand() % 3 + 1, 97+rand() % 3 + 1, 99.2+rand() % 3 + 1);
        PatientData p5("Jacob Rodriguez", 44, 1002, 87+rand() % 3 + 1, 128+rand() % 3 + 1, 82+rand() % 3 + 1, 96+rand() % 3 + 1, 99.6+rand() % 3 + 1);
        PatientData p6("Noman Ali", 38, 5742, 85+rand() % 3 + 1, 135+rand() % 3 + 1, 80+rand() % 3 + 1, 93+rand() % 3 + 1, 99.8+rand() % 3 + 1);
        PatientData p7("Farhan Ahmed", 41, 7123,80+rand() % 3 + 1, 120+rand() % 3 + 1, 70+rand() % 3 + 1, 95+rand() % 3 + 1, 98.5+rand() % 3 + 1);
        PatientData p8("Muhammad Ali", 35, 4213, 70+rand() % 3 + 1, 130+rand() % 3 + 1, 75+rand() % 3 + 1, 97+rand() % 3 + 1, 99.2+rand() % 3 + 1);
        PatientData p9("Sher Khan", 45, 6321, 75+rand() % 3 + 1, 125+rand() % 3 + 1, 70+rand() % 3 + 1, 91+rand() % 3 + 1, 98.8+rand() % 3 + 1);
        PatientData p10("Bandook Khan", 28, 2789, heart_rate,bp_high,bp_low,oxygen,temperature);

        ofstream file("patientdata.dat", ios::out | ios::binary);
    
        // close the file
        file.close();
        cout << "File emptied successfully." << endl;
        cout<<endl;

        p.randomdata(p);
        p2.randomdata(p2);
        p3.randomdata(p3);
        p4.randomdata(p4);
        p5.randomdata(p5);
        p6.randomdata(p6);
        p7.randomdata(p7);
        p8.randomdata(p8);
        p9.randomdata(p9);
        p10.randomdata(p10);
    }
}

void PatientData::infokidney()
{
    cout<<"Name           = "<<name<<endl;
    cout<<"Age            = "<<age<<endl;
    cout<<"MR number      = "<<MR_number<<endl;
    cout<<"Heart Rate     = "<<heart_rate<<endl;
    cout<<"Blood pressure = "<<bp_high<<"/"<<bp_low<<endl;
    cout<<"Oxygen Rate    = "<<oxygen<<endl;

    set_heart_rate();
    heart_rate = get_heart_rate();
    //cout<<"New heart rate = "<<heart_rate<<endl;
    setbp_low();
    bp_low = getbp_low();
    setbp_high();
    bp_high = getbp_high();
    set_oxygen();
    oxygen = get_oxygen();
    set_temperature();
    temperature = get_temperature();

    if(MR_number==2191)
    {
        PatientData p("Arham Ahmed",18,2191,heart_rate,bp_high,bp_low,oxygen,temperature);
        PatientData p2("John Smith",50,9012,70,159,60,90,100.1);
        PatientData p3("Sarah Williams", 35, 1010, 80, 120, 80, 96, 98.5);
        PatientData p4("James Lee", 42, 2145, 85, 125, 80, 97, 99.2);
        PatientData p5("Jacob Rodriguez", 44, 1002, 87, 128, 82, 96, 100.6);
        PatientData p6("Noman Ali", 38, 5742, 85, 135, 80, 93, 99.8);
        PatientData p7("Farhan Ahmed", 41, 7123, 78, 140, 75, 94, 99.4);
        PatientData p8("Muhammad Ali", 35, 4213, 80, 120, 70, 95, 98.5);
        PatientData p9("Sher Khan", 45, 6321, 70, 130, 75, 97, 99.2);
        PatientData p10("Bandook Khan", 28, 2789, 75, 125, 70, 91, 98.8);

        ofstream file("patientdata.dat", ios::out | ios::binary);
    
        // close the file
        file.close();
        cout << "File emptied successfully." << endl;
        cout<<endl;

        p.randomdata(p);
        p2.randomdata(p2);
        p3.randomdata(p3);
        p4.randomdata(p4);
        p5.randomdata(p5);
        p6.randomdata(p6);
        p7.randomdata(p7);
        p8.randomdata(p8);
        p9.randomdata(p9);
        p10.randomdata(p10);
    }
    else if(MR_number==9012)
    {

        PatientData p("Arham Ahmed",18,2191,60+rand() % 3 + 1,120+rand() % 3 + 1,80+rand() % 3 + 1,70+rand() % 3 + 1,98.6+rand() % 3 + 1);
        PatientData p2("John Smith",50,9012,heart_rate,bp_high,bp_low,oxygen,temperature);
        PatientData p3("Sarah Williams", 35, 1010, 80+rand() % 3 + 1, 120+rand() % 3 + 1, 80+rand() % 3 + 1, 96+rand() % 3 + 1, 98.5+rand() % 2 + 1);
        PatientData p4("James Lee", 42, 2145, 85+rand() % 3 + 1, 125+rand() % 3 + 1, 80+rand() % 3 + 1, 97+rand() % 3 + 1, 99.2+rand() % 3 + 1);
        PatientData p5("Jacob Rodriguez", 44, 1002, 87+rand() % 3 + 1, 128+rand() % 3 + 1, 82+rand() % 3 + 1, 96+rand() % 3 + 1, 99.6+rand() % 3 + 1);
        PatientData p6("Noman Ali", 38, 5742, 85+rand() % 3 + 1, 135+rand() % 3 + 1, 80+rand() % 3 + 1, 93+rand() % 3 + 1, 99.8+rand() % 3 + 1);
        PatientData p7("Farhan Ahmed", 41, 7123, 78+rand() % 3 + 1, 140+rand() % 3 + 1, 75+rand() % 3 + 1, 94+rand() % 3 + 1, 99.4+rand() % 3 + 1);
        PatientData p8("Muhammad Ali", 35, 4213, 80+rand() % 3 + 1, 120+rand() % 3 + 1, 70+rand() % 3 + 1, 95+rand() % 3 + 1, 98.5+rand() % 3 + 1);
        PatientData p9("Sher Khan", 45, 6321, 70+rand() % 3 + 1, 130+rand() % 3 + 1, 75+rand() % 3 + 1, 97+rand() % 3 + 1, 99.2+rand() % 3 + 1);
        PatientData p10("Bandook Khan", 28, 2789, 75+rand() % 3 + 1, 125+rand() % 3 + 1, 70+rand() % 3 + 1, 91+rand() % 3 + 1, 98.8+rand() % 3 + 1);

        ofstream file("patientdata.dat", ios::out | ios::binary);
    
        // close the file
        file.close();
        cout << "File emptied successfully." << endl;
        cout<<endl;

        p.randomdata(p);
        p2.randomdata(p2);
        p3.randomdata(p3);
        p4.randomdata(p4);
        p5.randomdata(p5);
        p6.randomdata(p6);
        p7.randomdata(p7);
        p8.randomdata(p8);
        p9.randomdata(p9);
        p10.randomdata(p10);
    }
    else if(MR_number==1010)
    {
        PatientData p("Arham Ahmed",18,2191,60+rand() % 3 + 1,120+rand() % 3 + 1,80+rand() % 3 + 1,70+rand() % 3 + 1,98.6+rand() % 3 + 1);
        PatientData p2("John Smith",50,9012,80+rand() % 3 + 1, 120+rand() % 3 + 1, 80+rand() % 3 + 1, 96+rand() % 3 + 1, 98.5+rand() % 2 + 1);
        PatientData p3("Sarah Williams", 35, 1010, heart_rate,bp_high,bp_low,oxygen,temperature);
        PatientData p4("James Lee", 42, 2145, 85+rand() % 3 + 1, 125+rand() % 3 + 1, 80+rand() % 3 + 1, 97+rand() % 3 + 1, 99.2+rand() % 3 + 1);
        PatientData p5("Jacob Rodriguez", 44, 1002, 87+rand() % 3 + 1, 128+rand() % 3 + 1, 82+rand() % 3 + 1, 96+rand() % 3 + 1, 99.6+rand() % 3 + 1);
        PatientData p6("Noman Ali", 38, 5742, 85+rand() % 3 + 1, 135+rand() % 3 + 1, 80+rand() % 3 + 1, 93+rand() % 3 + 1, 99.8+rand() % 3 + 1);
        PatientData p7("Farhan Ahmed", 41, 7123, 78+rand() % 3 + 1, 140+rand() % 3 + 1, 75+rand() % 3 + 1, 94+rand() % 3 + 1, 99.4+rand() % 3 + 1);
        PatientData p8("Muhammad Ali", 35, 4213, 80+rand() % 3 + 1, 120+rand() % 3 + 1, 70+rand() % 3 + 1, 95+rand() % 3 + 1, 98.5+rand() % 3 + 1);
        PatientData p9("Sher Khan", 45, 6321, 70+rand() % 3 + 1, 130+rand() % 3 + 1, 75+rand() % 3 + 1, 97+rand() % 3 + 1, 99.2+rand() % 3 + 1);
        PatientData p10("Bandook Khan", 28, 2789, 75+rand() % 3 + 1, 125+rand() % 3 + 1, 70+rand() % 3 + 1, 91+rand() % 3 + 1, 98.8+rand() % 3 + 1);

        ofstream file("patientdata.dat", ios::out | ios::binary);
    
        // close the file
        file.close();
        cout << "File emptied successfully." << endl;
        cout<<endl;

        p.randomdata(p);
        p2.randomdata(p2);
        p3.randomdata(p3);
        p4.randomdata(p4);
        p5.randomdata(p5);
        p6.randomdata(p6);
        p7.randomdata(p7);
        p8.randomdata(p8);
        p9.randomdata(p9);
        p10.randomdata(p10);
    }
    else if(MR_number==2145)
    {
        PatientData p("Arham Ahmed",18,2191,60-rand() % 3 + 1,120-rand() % 3 + 1,80-rand() % 3 + 1,70-rand() % 3 + 1,98.6-rand() % 3 + 1);
        PatientData p2("John Smith",50,9012,85-rand() % 3 + 1, 125-rand() % 3 + 1, 80-rand() % 3 + 1, 97-rand() % 3 + 1, 99.2-rand() % 3 + 1);
        PatientData p3("Sarah Williams", 35, 1010, 80-rand() % 3 + 1, 120-rand() % 3 + 1, 80-rand() % 3 + 1, 96-rand() % 3 + 1, 98.5-rand() % 2 + 1);
        PatientData p4("James Lee", 42, 2145, heart_rate,bp_high,bp_low,oxygen,temperature);
        PatientData p5("Jacob Rodriguez", 44, 1002, 87-rand() % 3 + 1, 128-rand() % 3 + 1, 82-rand() % 3 + 1, 96-rand() % 3 + 1, 100.6-rand() % 3 + 1);
        PatientData p6("Noman Ali", 38, 5742, 85-rand() % 3 + 1, 135-rand() % 3 + 1, 80-rand() % 3 + 1, 93-rand() % 3 + 1, 99.8-rand() % 3 + 1);
        PatientData p7("Farhan Ahmed", 41, 7123, 78-rand() % 3 + 1, 140-rand() % 3 + 1, 75-rand() % 3 + 1, 94-rand() % 3 + 1, 99.4-rand() % 3 + 1);
        PatientData p8("Muhammad Ali", 35, 4213, 80-rand() % 3 + 1, 120-rand() % 3 + 1, 70-rand() % 3 + 1, 95-rand() % 3 + 1, 98.5-rand() % 3 + 1);
        PatientData p9("Sher Khan", 45, 6321, 70-rand() % 3 + 1, 130-rand() % 3 + 1, 75-rand() % 3 + 1, 97-rand() % 3 + 1, 99.2-rand() % 3 + 1);
        PatientData p10("Bandook Khan", 28, 2789, 75-rand() % 3 + 1, 125-rand() % 3 + 1, 70-rand() % 3 + 1, 91-rand() % 3 + 1, 98.8-rand() % 3 + 1);

        ofstream file("patientdata.dat", ios::out | ios::binary);
    
        // close the file
        file.close();
        cout << "File emptied successfully." << endl;
        cout<<endl;

        p.randomdata(p);
        p2.randomdata(p2);
        p3.randomdata(p3);
        p4.randomdata(p4);
        p5.randomdata(p5);
        p6.randomdata(p6);
        p7.randomdata(p7);
        p8.randomdata(p8);
        p9.randomdata(p9);
        p10.randomdata(p10);
    }
    else if(MR_number==1002)
    {
        PatientData p("Arham Ahmed",18,2191,60-rand() % 3 + 1,120-rand() % 3 + 1,80-rand() % 3 + 1,70-rand() % 3 + 1,98.6-rand() % 3 + 1);
        PatientData p2("John Smith",50,9012,85-rand() % 3 + 1, 125-rand() % 3 + 1, 80-rand() % 3 + 1, 97-rand() % 3 + 1, 99.2-rand() % 3 + 1);
        PatientData p3("Sarah Williams", 35, 1010, 80-rand() % 3 + 1, 120-rand() % 3 + 1, 80-rand() % 3 + 1, 96-rand() % 3 + 1, 98.5-rand() % 2 + 1);
        PatientData p4("James Lee", 42, 2145, 85-rand() % 3 + 1, 125-rand() % 3 + 1, 80-rand() % 3 + 1, 97-rand() % 3 + 1, 99.2-rand() % 3 + 1);
        PatientData p5("Jacob Rodriguez", 44, 1002, heart_rate,bp_high,bp_low,oxygen,temperature);
        PatientData p6("Noman Ali", 38, 5742, 85-rand() % 3 + 1, 135-rand() % 3 + 1, 80-rand() % 3 + 1, 93-rand() % 3 + 1, 99.8-rand() % 3 + 1);
        PatientData p7("Farhan Ahmed", 41, 7123, 78-rand() % 3 + 1, 140-rand() % 3 + 1, 75-rand() % 3 + 1, 94-rand() % 3 + 1, 99.4-rand() % 3 + 1);
        PatientData p8("Muhammad Ali", 35, 4213, 80-rand() % 3 + 1, 120-rand() % 3 + 1, 70-rand() % 3 + 1, 95-rand() % 3 + 1, 98.5-rand() % 3 + 1);
        PatientData p9("Sher Khan", 45, 6321, 70-rand() % 3 + 1, 130-rand() % 3 + 1, 75-rand() % 3 + 1, 97-rand() % 3 + 1, 99.2-rand() % 3 + 1);
        PatientData p10("Bandook Khan", 28, 2789, 75-rand() % 3 + 1, 125-rand() % 3 + 1, 70-rand() % 3 + 1, 91-rand() % 3 + 1, 98.8-rand() % 3 + 1);

        ofstream file("patientdata.dat", ios::out | ios::binary);
    
        // close the file
        file.close();
        cout << "File emptied successfully." << endl;
        cout<<endl;

        p.randomdata(p);
        p2.randomdata(p2);
        p3.randomdata(p3);
        p4.randomdata(p4);
        p5.randomdata(p5);
        p6.randomdata(p6);
        p7.randomdata(p7);
        p8.randomdata(p8);
        p9.randomdata(p9);
        p10.randomdata(p10);
    }
    else if(MR_number==5742)
    {
        PatientData p("Arham Ahmed",18,2191,60-rand() % 3 + 1,120-rand() % 3 + 1,80-rand() % 3 + 1,70-rand() % 3 + 1,98.6-rand() % 3 + 1);
        PatientData p2("John Smith",50,9012,85-rand() % 3 + 1, 125-rand() % 3 + 1, 80-rand() % 3 + 1, 97-rand() % 3 + 1, 99.2-rand() % 3 + 1);
        PatientData p3("Sarah Williams", 35, 1010, 80-rand() % 3 + 1, 120-rand() % 3 + 1, 80-rand() % 3 + 1, 96-rand() % 3 + 1, 98.5-rand() % 2 + 1);
        PatientData p4("James Lee", 42, 2145, 85-rand() % 3 + 1, 125-rand() % 3 + 1, 80-rand() % 3 + 1, 97-rand() % 3 + 1, 99.2-rand() % 3 + 1);
        PatientData p5("Jacob Rodriguez", 44, 1002, 87-rand() % 3 + 1, 128-rand() % 3 + 1, 82-rand() % 3 + 1, 96-rand() % 3 + 1, 100.6-rand() % 3 + 1);
        PatientData p6("Noman Ali", 38, 5742, heart_rate,bp_high,bp_low,oxygen,temperature);
        PatientData p7("Farhan Ahmed", 41, 7123, 78-rand() % 3 + 1, 140-rand() % 3 + 1, 75-rand() % 3 + 1, 94-rand() % 3 + 1, 99.4-rand() % 3 + 1);
        PatientData p8("Muhammad Ali", 35, 4213, 80-rand() % 3 + 1, 120-rand() % 3 + 1, 70-rand() % 3 + 1, 95-rand() % 3 + 1, 98.5-rand() % 3 + 1);
        PatientData p9("Sher Khan", 45, 6321, 70-rand() % 3 + 1, 130-rand() % 3 + 1, 75-rand() % 3 + 1, 97-rand() % 3 + 1, 99.2-rand() % 3 + 1);
        PatientData p10("Bandook Khan", 28, 2789, 75-rand() % 3 + 1, 125-rand() % 3 + 1, 70-rand() % 3 + 1, 91-rand() % 3 + 1, 98.8-rand() % 3 + 1);

        ofstream file("patientdata.dat", ios::out | ios::binary);
    
        // close the file
        file.close();
        cout << "File emptied successfully." << endl;
        cout<<endl;

        p.randomdata(p);
        p2.randomdata(p2);
        p3.randomdata(p3);
        p4.randomdata(p4);
        p5.randomdata(p5);
        p6.randomdata(p6);
        p7.randomdata(p7);
        p8.randomdata(p8);
        p9.randomdata(p9);
        p10.randomdata(p10);
    }
    else if(MR_number==7123)
    {
        PatientData p("Arham Ahmed",18,2191,60+rand() % 3 + 1,120+rand() % 3 + 1,80+rand() % 3 + 1,70+rand() % 3 + 1,98.6+rand() % 3 + 1);
        PatientData p2("John Smith",50,9012,78+rand() % 3 + 1, 140+rand() % 3 + 1, 75+rand() % 3 + 1, 94+rand() % 3 + 1, 99.4+rand() % 3 + 1);
        PatientData p3("Sarah Williams", 35, 1010, 80+rand() % 3 + 1, 120+rand() % 3 + 1, 80+rand() % 3 + 1, 96+rand() % 3 + 1, 98.5+rand() % 2 + 1);
        PatientData p4("James Lee", 42, 2145, 85+rand() % 3 + 1, 125+rand() % 3 + 1, 80+rand() % 3 + 1, 97+rand() % 3 + 1, 99.2+rand() % 3 + 1);
        PatientData p5("Jacob Rodriguez", 44, 1002, 87+rand() % 3 + 1, 128+rand() % 3 + 1, 82+rand() % 3 + 1, 96+rand() % 3 + 1, 99.6+rand() % 3 + 1);
        PatientData p6("Noman Ali", 38, 5742, 85+rand() % 3 + 1, 135+rand() % 3 + 1, 80+rand() % 3 + 1, 93+rand() % 3 + 1, 99.8+rand() % 3 + 1);
        PatientData p7("Farhan Ahmed", 41, 7123, heart_rate,bp_high,bp_low,oxygen,temperature);
        PatientData p8("Muhammad Ali", 35, 4213, 80+rand() % 3 + 1, 120+rand() % 3 + 1, 70+rand() % 3 + 1, 95+rand() % 3 + 1, 98.5+rand() % 3 + 1);
        PatientData p9("Sher Khan", 45, 6321, 70+rand() % 3 + 1, 130+rand() % 3 + 1, 75+rand() % 3 + 1, 97+rand() % 3 + 1, 99.2+rand() % 3 + 1);
        PatientData p10("Bandook Khan", 28, 2789, 75+rand() % 3 + 1, 125+rand() % 3 + 1, 70+rand() % 3 + 1, 91+rand() % 3 + 1, 98.8+rand() % 3 + 1);

        ofstream file("patientdata.dat", ios::out | ios::binary);
    
        // close the file
        file.close();
        cout << "File emptied successfully." << endl;
        cout<<endl;

        p.randomdata(p);
        p2.randomdata(p2);
        p3.randomdata(p3);
        p4.randomdata(p4);
        p5.randomdata(p5);
        p6.randomdata(p6);
        p7.randomdata(p7);
        p8.randomdata(p8);
        p9.randomdata(p9);
        p10.randomdata(p10);
    }
    else if(MR_number==4213)
    {
        PatientData p("Arham Ahmed",18,2191,60+rand() % 3 + 1,120+rand() % 3 + 1,80+rand() % 3 + 1,70+rand() % 3 + 1,98.6+rand() % 3 + 1);
        PatientData p2("John Smith",50,9012,78+rand() % 3 + 1, 140+rand() % 3 + 1, 75+rand() % 3 + 1, 94+rand() % 3 + 1, 99.4+rand() % 3 + 1);
        PatientData p3("Sarah Williams", 35, 1010, 80+rand() % 3 + 1, 120+rand() % 3 + 1, 80+rand() % 3 + 1, 96+rand() % 3 + 1, 98.5+rand() % 2 + 1);
        PatientData p4("James Lee", 42, 2145, 85+rand() % 3 + 1, 125+rand() % 3 + 1, 80+rand() % 3 + 1, 97+rand() % 3 + 1, 99.2+rand() % 3 + 1);
        PatientData p5("Jacob Rodriguez", 44, 1002, 87+rand() % 3 + 1, 128+rand() % 3 + 1, 82+rand() % 3 + 1, 96+rand() % 3 + 1, 99.6+rand() % 3 + 1);
        PatientData p6("Noman Ali", 38, 5742, 85+rand() % 3 + 1, 135+rand() % 3 + 1, 80+rand() % 3 + 1, 93+rand() % 3 + 1, 99.8+rand() % 3 + 1);
        PatientData p7("Farhan Ahmed", 41, 7123,80+rand() % 3 + 1, 120+rand() % 3 + 1, 70+rand() % 3 + 1, 95+rand() % 3 + 1, 98.5+rand() % 3 + 1);
        PatientData p8("Muhammad Ali", 35, 4213, heart_rate,bp_high,bp_low,oxygen,temperature);
        PatientData p9("Sher Khan", 45, 6321, 70+rand() % 3 + 1, 130+rand() % 3 + 1, 75+rand() % 3 + 1, 97+rand() % 3 + 1, 99.2+rand() % 3 + 1);
        PatientData p10("Bandook Khan", 28, 2789, 75+rand() % 3 + 1, 125+rand() % 3 + 1, 70+rand() % 3 + 1, 91+rand() % 3 + 1, 98.8+rand() % 3 + 1);

        ofstream file("patientdata.dat", ios::out | ios::binary);
    
        // close the file
        file.close();
        cout << "File emptied successfully." << endl;
        cout<<endl;

        p.randomdata(p);
        p2.randomdata(p2);
        p3.randomdata(p3);
        p4.randomdata(p4);
        p5.randomdata(p5);
        p6.randomdata(p6);
        p7.randomdata(p7);
        p8.randomdata(p8);
        p9.randomdata(p9);
        p10.randomdata(p10);
    }
    else if(MR_number==6321)
    {
        PatientData p("Arham Ahmed",18,2191,60+rand() % 3 + 1,120+rand() % 3 + 1,80+rand() % 3 + 1,70+rand() % 3 + 1,98.6+rand() % 3 + 1);
        PatientData p2("John Smith",50,9012,78+rand() % 3 + 1, 140+rand() % 3 + 1, 75+rand() % 3 + 1, 94+rand() % 3 + 1, 99.4+rand() % 3 + 1);
        PatientData p3("Sarah Williams", 35, 1010, 80+rand() % 3 + 1, 120+rand() % 3 + 1, 80+rand() % 3 + 1, 96+rand() % 3 + 1, 98.5+rand() % 2 + 1);
        PatientData p4("James Lee", 42, 2145, 85+rand() % 3 + 1, 125+rand() % 3 + 1, 80+rand() % 3 + 1, 97+rand() % 3 + 1, 99.2+rand() % 3 + 1);
        PatientData p5("Jacob Rodriguez", 44, 1002, 87+rand() % 3 + 1, 128+rand() % 3 + 1, 82+rand() % 3 + 1, 96+rand() % 3 + 1, 99.6+rand() % 3 + 1);
        PatientData p6("Noman Ali", 38, 5742, 85+rand() % 3 + 1, 135+rand() % 3 + 1, 80+rand() % 3 + 1, 93+rand() % 3 + 1, 99.8+rand() % 3 + 1);
        PatientData p7("Farhan Ahmed", 41, 7123,80+rand() % 3 + 1, 120+rand() % 3 + 1, 70+rand() % 3 + 1, 95+rand() % 3 + 1, 98.5+rand() % 3 + 1);
        PatientData p8("Muhammad Ali", 35, 4213, 70+rand() % 3 + 1, 130+rand() % 3 + 1, 75+rand() % 3 + 1, 97+rand() % 3 + 1, 99.2+rand() % 3 + 1);
        PatientData p9("Sher Khan", 45, 6321, heart_rate,bp_high,bp_low,oxygen,temperature);
        PatientData p10("Bandook Khan", 28, 2789, 75+rand() % 3 + 1, 125+rand() % 3 + 1, 70+rand() % 3 + 1, 91+rand() % 3 + 1, 98.8+rand() % 3 + 1);

        ofstream file("patientdata.dat", ios::out | ios::binary);
    
        // close the file
        file.close();
        cout << "File emptied successfully." << endl;
        cout<<endl;

        p.randomdata(p);
        p2.randomdata(p2);
        p3.randomdata(p3);
        p4.randomdata(p4);
        p5.randomdata(p5);
        p6.randomdata(p6);
        p7.randomdata(p7);
        p8.randomdata(p8);
        p9.randomdata(p9);
        p10.randomdata(p10);
    }
    else if(MR_number==2789)
    {
        PatientData p("Arham Ahmed",18,2191,60+rand() % 3 + 1,120+rand() % 3 + 1,80+rand() % 3 + 1,70+rand() % 3 + 1,98.6+rand() % 3 + 1);
        PatientData p2("John Smith",50,9012,78+rand() % 3 + 1, 140+rand() % 3 + 1, 75+rand() % 3 + 1, 94+rand() % 3 + 1, 99.4+rand() % 3 + 1);
        PatientData p3("Sarah Williams", 35, 1010, 80+rand() % 3 + 1, 120+rand() % 3 + 1, 80+rand() % 3 + 1, 96+rand() % 3 + 1, 98.5+rand() % 2 + 1);
        PatientData p4("James Lee", 42, 2145, 85+rand() % 3 + 1, 125+rand() % 3 + 1, 80+rand() % 3 + 1, 97+rand() % 3 + 1, 99.2+rand() % 3 + 1);
        PatientData p5("Jacob Rodriguez", 44, 1002, 87+rand() % 3 + 1, 128+rand() % 3 + 1, 82+rand() % 3 + 1, 96+rand() % 3 + 1, 99.6+rand() % 3 + 1);
        PatientData p6("Noman Ali", 38, 5742, 85+rand() % 3 + 1, 135+rand() % 3 + 1, 80+rand() % 3 + 1, 93+rand() % 3 + 1, 99.8+rand() % 3 + 1);
        PatientData p7("Farhan Ahmed", 41, 7123,80+rand() % 3 + 1, 120+rand() % 3 + 1, 70+rand() % 3 + 1, 95+rand() % 3 + 1, 98.5+rand() % 3 + 1);
        PatientData p8("Muhammad Ali", 35, 4213, 70+rand() % 3 + 1, 130+rand() % 3 + 1, 75+rand() % 3 + 1, 97+rand() % 3 + 1, 99.2+rand() % 3 + 1);
        PatientData p9("Sher Khan", 45, 6321, 75+rand() % 3 + 1, 125+rand() % 3 + 1, 70+rand() % 3 + 1, 91+rand() % 3 + 1, 98.8+rand() % 3 + 1);
        PatientData p10("Bandook Khan", 28, 2789, heart_rate,bp_high,bp_low,oxygen,temperature);

        ofstream file("patientdata.dat", ios::out | ios::binary);
    
        // close the file
        file.close();
        cout << "File emptied successfully." << endl;
        cout<<endl;

        p.randomdata(p);
        p2.randomdata(p2);
        p3.randomdata(p3);
        p4.randomdata(p4);
        p5.randomdata(p5);
        p6.randomdata(p6);
        p7.randomdata(p7);
        p8.randomdata(p8);
        p9.randomdata(p9);
        p10.randomdata(p10);
    }
}

void PatientData::skininfo()
{
    cout<<"Name           = "<<name<<endl;
    cout<<"Age            = "<<age<<endl;
    cout<<"MR number      = "<<MR_number<<endl;

    set_heart_rate();
    heart_rate = get_heart_rate();
    //cout<<"New heart rate = "<<heart_rate<<endl;
    setbp_low();
    bp_low = getbp_low();
    setbp_high();
    bp_high = getbp_high();
    set_oxygen();
    oxygen = get_oxygen();
    set_temperature();
    temperature = get_temperature();

    if(MR_number==2191)
    {
        PatientData p("Arham Ahmed",18,2191,heart_rate,bp_high,bp_low,oxygen,temperature);
        PatientData p2("John Smith",50,9012,70,159,60,90,100.1);
        PatientData p3("Sarah Williams", 35, 1010, 80, 120, 80, 96, 98.5);
        PatientData p4("James Lee", 42, 2145, 85, 125, 80, 97, 99.2);
        PatientData p5("Jacob Rodriguez", 44, 1002, 87, 128, 82, 96, 100.6);
        PatientData p6("Noman Ali", 38, 5742, 85, 135, 80, 93, 99.8);
        PatientData p7("Farhan Ahmed", 41, 7123, 78, 140, 75, 94, 99.4);
        PatientData p8("Muhammad Ali", 35, 4213, 80, 120, 70, 95, 98.5);
        PatientData p9("Sher Khan", 45, 6321, 70, 130, 75, 97, 99.2);
        PatientData p10("Bandook Khan", 28, 2789, 75, 125, 70, 91, 98.8);

        ofstream file("patientdata.dat", ios::out | ios::binary);
    
        // close the file
        file.close();
        cout << "File emptied successfully." << endl;
        cout<<endl;

        p.randomdata(p);
        p2.randomdata(p2);
        p3.randomdata(p3);
        p4.randomdata(p4);
        p5.randomdata(p5);
        p6.randomdata(p6);
        p7.randomdata(p7);
        p8.randomdata(p8);
        p9.randomdata(p9);
        p10.randomdata(p10);
    }
    else if(MR_number==9012)
    {

        PatientData p("Arham Ahmed",18,2191,60+rand() % 3 + 1,120+rand() % 3 + 1,80+rand() % 3 + 1,70+rand() % 3 + 1,98.6+rand() % 3 + 1);
        PatientData p2("John Smith",50,9012,heart_rate,bp_high,bp_low,oxygen,temperature);
        PatientData p3("Sarah Williams", 35, 1010, 80+rand() % 3 + 1, 120+rand() % 3 + 1, 80+rand() % 3 + 1, 96+rand() % 3 + 1, 98.5+rand() % 2 + 1);
        PatientData p4("James Lee", 42, 2145, 85+rand() % 3 + 1, 125+rand() % 3 + 1, 80+rand() % 3 + 1, 97+rand() % 3 + 1, 99.2+rand() % 3 + 1);
        PatientData p5("Jacob Rodriguez", 44, 1002, 87+rand() % 3 + 1, 128+rand() % 3 + 1, 82+rand() % 3 + 1, 96+rand() % 3 + 1, 99.6+rand() % 3 + 1);
        PatientData p6("Noman Ali", 38, 5742, 85+rand() % 3 + 1, 135+rand() % 3 + 1, 80+rand() % 3 + 1, 93+rand() % 3 + 1, 99.8+rand() % 3 + 1);
        PatientData p7("Farhan Ahmed", 41, 7123, 78+rand() % 3 + 1, 140+rand() % 3 + 1, 75+rand() % 3 + 1, 94+rand() % 3 + 1, 99.4+rand() % 3 + 1);
        PatientData p8("Muhammad Ali", 35, 4213, 80+rand() % 3 + 1, 120+rand() % 3 + 1, 70+rand() % 3 + 1, 95+rand() % 3 + 1, 98.5+rand() % 3 + 1);
        PatientData p9("Sher Khan", 45, 6321, 70+rand() % 3 + 1, 130+rand() % 3 + 1, 75+rand() % 3 + 1, 97+rand() % 3 + 1, 99.2+rand() % 3 + 1);
        PatientData p10("Bandook Khan", 28, 2789, 75+rand() % 3 + 1, 125+rand() % 3 + 1, 70+rand() % 3 + 1, 91+rand() % 3 + 1, 98.8+rand() % 3 + 1);

        ofstream file("patientdata.dat", ios::out | ios::binary);
    
        // close the file
        file.close();
        cout << "File emptied successfully." << endl;
        cout<<endl;

        p.randomdata(p);
        p2.randomdata(p2);
        p3.randomdata(p3);
        p4.randomdata(p4);
        p5.randomdata(p5);
        p6.randomdata(p6);
        p7.randomdata(p7);
        p8.randomdata(p8);
        p9.randomdata(p9);
        p10.randomdata(p10);
    }
    else if(MR_number==1010)
    {
        PatientData p("Arham Ahmed",18,2191,60+rand() % 3 + 1,120+rand() % 3 + 1,80+rand() % 3 + 1,70+rand() % 3 + 1,98.6+rand() % 3 + 1);
        PatientData p2("John Smith",50,9012,80+rand() % 3 + 1, 120+rand() % 3 + 1, 80+rand() % 3 + 1, 96+rand() % 3 + 1, 98.5+rand() % 2 + 1);
        PatientData p3("Sarah Williams", 35, 1010, heart_rate,bp_high,bp_low,oxygen,temperature);
        PatientData p4("James Lee", 42, 2145, 85+rand() % 3 + 1, 125+rand() % 3 + 1, 80+rand() % 3 + 1, 97+rand() % 3 + 1, 99.2+rand() % 3 + 1);
        PatientData p5("Jacob Rodriguez", 44, 1002, 87+rand() % 3 + 1, 128+rand() % 3 + 1, 82+rand() % 3 + 1, 96+rand() % 3 + 1, 99.6+rand() % 3 + 1);
        PatientData p6("Noman Ali", 38, 5742, 85+rand() % 3 + 1, 135+rand() % 3 + 1, 80+rand() % 3 + 1, 93+rand() % 3 + 1, 99.8+rand() % 3 + 1);
        PatientData p7("Farhan Ahmed", 41, 7123, 78+rand() % 3 + 1, 140+rand() % 3 + 1, 75+rand() % 3 + 1, 94+rand() % 3 + 1, 99.4+rand() % 3 + 1);
        PatientData p8("Muhammad Ali", 35, 4213, 80+rand() % 3 + 1, 120+rand() % 3 + 1, 70+rand() % 3 + 1, 95+rand() % 3 + 1, 98.5+rand() % 3 + 1);
        PatientData p9("Sher Khan", 45, 6321, 70+rand() % 3 + 1, 130+rand() % 3 + 1, 75+rand() % 3 + 1, 97+rand() % 3 + 1, 99.2+rand() % 3 + 1);
        PatientData p10("Bandook Khan", 28, 2789, 75+rand() % 3 + 1, 125+rand() % 3 + 1, 70+rand() % 3 + 1, 91+rand() % 3 + 1, 98.8+rand() % 3 + 1);

        ofstream file("patientdata.dat", ios::out | ios::binary);
    
        // close the file
        file.close();
        cout << "File emptied successfully." << endl;
        cout<<endl;

        p.randomdata(p);
        p2.randomdata(p2);
        p3.randomdata(p3);
        p4.randomdata(p4);
        p5.randomdata(p5);
        p6.randomdata(p6);
        p7.randomdata(p7);
        p8.randomdata(p8);
        p9.randomdata(p9);
        p10.randomdata(p10);
    }
    else if(MR_number==2145)
    {
        PatientData p("Arham Ahmed",18,2191,60-rand() % 3 + 1,120-rand() % 3 + 1,80-rand() % 3 + 1,70-rand() % 3 + 1,98.6-rand() % 3 + 1);
        PatientData p2("John Smith",50,9012,85-rand() % 3 + 1, 125-rand() % 3 + 1, 80-rand() % 3 + 1, 97-rand() % 3 + 1, 99.2-rand() % 3 + 1);
        PatientData p3("Sarah Williams", 35, 1010, 80-rand() % 3 + 1, 120-rand() % 3 + 1, 80-rand() % 3 + 1, 96-rand() % 3 + 1, 98.5-rand() % 2 + 1);
        PatientData p4("James Lee", 42, 2145, heart_rate,bp_high,bp_low,oxygen,temperature);
        PatientData p5("Jacob Rodriguez", 44, 1002, 87-rand() % 3 + 1, 128-rand() % 3 + 1, 82-rand() % 3 + 1, 96-rand() % 3 + 1, 100.6-rand() % 3 + 1);
        PatientData p6("Noman Ali", 38, 5742, 85-rand() % 3 + 1, 135-rand() % 3 + 1, 80-rand() % 3 + 1, 93-rand() % 3 + 1, 99.8-rand() % 3 + 1);
        PatientData p7("Farhan Ahmed", 41, 7123, 78-rand() % 3 + 1, 140-rand() % 3 + 1, 75-rand() % 3 + 1, 94-rand() % 3 + 1, 99.4-rand() % 3 + 1);
        PatientData p8("Muhammad Ali", 35, 4213, 80-rand() % 3 + 1, 120-rand() % 3 + 1, 70-rand() % 3 + 1, 95-rand() % 3 + 1, 98.5-rand() % 3 + 1);
        PatientData p9("Sher Khan", 45, 6321, 70-rand() % 3 + 1, 130-rand() % 3 + 1, 75-rand() % 3 + 1, 97-rand() % 3 + 1, 99.2-rand() % 3 + 1);
        PatientData p10("Bandook Khan", 28, 2789, 75-rand() % 3 + 1, 125-rand() % 3 + 1, 70-rand() % 3 + 1, 91-rand() % 3 + 1, 98.8-rand() % 3 + 1);

        ofstream file("patientdata.dat", ios::out | ios::binary);
    
        // close the file
        file.close();
        cout << "File emptied successfully." << endl;
        cout<<endl;

        p.randomdata(p);
        p2.randomdata(p2);
        p3.randomdata(p3);
        p4.randomdata(p4);
        p5.randomdata(p5);
        p6.randomdata(p6);
        p7.randomdata(p7);
        p8.randomdata(p8);
        p9.randomdata(p9);
        p10.randomdata(p10);
    }
    else if(MR_number==1002)
    {
        PatientData p("Arham Ahmed",18,2191,60-rand() % 3 + 1,120-rand() % 3 + 1,80-rand() % 3 + 1,70-rand() % 3 + 1,98.6-rand() % 3 + 1);
        PatientData p2("John Smith",50,9012,85-rand() % 3 + 1, 125-rand() % 3 + 1, 80-rand() % 3 + 1, 97-rand() % 3 + 1, 99.2-rand() % 3 + 1);
        PatientData p3("Sarah Williams", 35, 1010, 80-rand() % 3 + 1, 120-rand() % 3 + 1, 80-rand() % 3 + 1, 96-rand() % 3 + 1, 98.5-rand() % 2 + 1);
        PatientData p4("James Lee", 42, 2145, 85-rand() % 3 + 1, 125-rand() % 3 + 1, 80-rand() % 3 + 1, 97-rand() % 3 + 1, 99.2-rand() % 3 + 1);
        PatientData p5("Jacob Rodriguez", 44, 1002, heart_rate,bp_high,bp_low,oxygen,temperature);
        PatientData p6("Noman Ali", 38, 5742, 85-rand() % 3 + 1, 135-rand() % 3 + 1, 80-rand() % 3 + 1, 93-rand() % 3 + 1, 99.8-rand() % 3 + 1);
        PatientData p7("Farhan Ahmed", 41, 7123, 78-rand() % 3 + 1, 140-rand() % 3 + 1, 75-rand() % 3 + 1, 94-rand() % 3 + 1, 99.4-rand() % 3 + 1);
        PatientData p8("Muhammad Ali", 35, 4213, 80-rand() % 3 + 1, 120-rand() % 3 + 1, 70-rand() % 3 + 1, 95-rand() % 3 + 1, 98.5-rand() % 3 + 1);
        PatientData p9("Sher Khan", 45, 6321, 70-rand() % 3 + 1, 130-rand() % 3 + 1, 75-rand() % 3 + 1, 97-rand() % 3 + 1, 99.2-rand() % 3 + 1);
        PatientData p10("Bandook Khan", 28, 2789, 75-rand() % 3 + 1, 125-rand() % 3 + 1, 70-rand() % 3 + 1, 91-rand() % 3 + 1, 98.8-rand() % 3 + 1);

        ofstream file("patientdata.dat", ios::out | ios::binary);
    
        // close the file
        file.close();
        cout << "File emptied successfully." << endl;
        cout<<endl;

        p.randomdata(p);
        p2.randomdata(p2);
        p3.randomdata(p3);
        p4.randomdata(p4);
        p5.randomdata(p5);
        p6.randomdata(p6);
        p7.randomdata(p7);
        p8.randomdata(p8);
        p9.randomdata(p9);
        p10.randomdata(p10);
    }
    else if(MR_number==5742)
    {
        PatientData p("Arham Ahmed",18,2191,60-rand() % 3 + 1,120-rand() % 3 + 1,80-rand() % 3 + 1,70-rand() % 3 + 1,98.6-rand() % 3 + 1);
        PatientData p2("John Smith",50,9012,85-rand() % 3 + 1, 125-rand() % 3 + 1, 80-rand() % 3 + 1, 97-rand() % 3 + 1, 99.2-rand() % 3 + 1);
        PatientData p3("Sarah Williams", 35, 1010, 80-rand() % 3 + 1, 120-rand() % 3 + 1, 80-rand() % 3 + 1, 96-rand() % 3 + 1, 98.5-rand() % 2 + 1);
        PatientData p4("James Lee", 42, 2145, 85-rand() % 3 + 1, 125-rand() % 3 + 1, 80-rand() % 3 + 1, 97-rand() % 3 + 1, 99.2-rand() % 3 + 1);
        PatientData p5("Jacob Rodriguez", 44, 1002, 87-rand() % 3 + 1, 128-rand() % 3 + 1, 82-rand() % 3 + 1, 96-rand() % 3 + 1, 100.6-rand() % 3 + 1);
        PatientData p6("Noman Ali", 38, 5742, heart_rate,bp_high,bp_low,oxygen,temperature);
        PatientData p7("Farhan Ahmed", 41, 7123, 78-rand() % 3 + 1, 140-rand() % 3 + 1, 75-rand() % 3 + 1, 94-rand() % 3 + 1, 99.4-rand() % 3 + 1);
        PatientData p8("Muhammad Ali", 35, 4213, 80-rand() % 3 + 1, 120-rand() % 3 + 1, 70-rand() % 3 + 1, 95-rand() % 3 + 1, 98.5-rand() % 3 + 1);
        PatientData p9("Sher Khan", 45, 6321, 70-rand() % 3 + 1, 130-rand() % 3 + 1, 75-rand() % 3 + 1, 97-rand() % 3 + 1, 99.2-rand() % 3 + 1);
        PatientData p10("Bandook Khan", 28, 2789, 75-rand() % 3 + 1, 125-rand() % 3 + 1, 70-rand() % 3 + 1, 91-rand() % 3 + 1, 98.8-rand() % 3 + 1);

        ofstream file("patientdata.dat", ios::out | ios::binary);
    
        // close the file
        file.close();
        cout << "File emptied successfully." << endl;
        cout<<endl;

        p.randomdata(p);
        p2.randomdata(p2);
        p3.randomdata(p3);
        p4.randomdata(p4);
        p5.randomdata(p5);
        p6.randomdata(p6);
        p7.randomdata(p7);
        p8.randomdata(p8);
        p9.randomdata(p9);
        p10.randomdata(p10);
    }
    else if(MR_number==7123)
    {
        PatientData p("Arham Ahmed",18,2191,60+rand() % 3 + 1,120+rand() % 3 + 1,80+rand() % 3 + 1,70+rand() % 3 + 1,98.6+rand() % 3 + 1);
        PatientData p2("John Smith",50,9012,78+rand() % 3 + 1, 140+rand() % 3 + 1, 75+rand() % 3 + 1, 94+rand() % 3 + 1, 99.4+rand() % 3 + 1);
        PatientData p3("Sarah Williams", 35, 1010, 80+rand() % 3 + 1, 120+rand() % 3 + 1, 80+rand() % 3 + 1, 96+rand() % 3 + 1, 98.5+rand() % 2 + 1);
        PatientData p4("James Lee", 42, 2145, 85+rand() % 3 + 1, 125+rand() % 3 + 1, 80+rand() % 3 + 1, 97+rand() % 3 + 1, 99.2+rand() % 3 + 1);
        PatientData p5("Jacob Rodriguez", 44, 1002, 87+rand() % 3 + 1, 128+rand() % 3 + 1, 82+rand() % 3 + 1, 96+rand() % 3 + 1, 99.6+rand() % 3 + 1);
        PatientData p6("Noman Ali", 38, 5742, 85+rand() % 3 + 1, 135+rand() % 3 + 1, 80+rand() % 3 + 1, 93+rand() % 3 + 1, 99.8+rand() % 3 + 1);
        PatientData p7("Farhan Ahmed", 41, 7123, heart_rate,bp_high,bp_low,oxygen,temperature);
        PatientData p8("Muhammad Ali", 35, 4213, 80+rand() % 3 + 1, 120+rand() % 3 + 1, 70+rand() % 3 + 1, 95+rand() % 3 + 1, 98.5+rand() % 3 + 1);
        PatientData p9("Sher Khan", 45, 6321, 70+rand() % 3 + 1, 130+rand() % 3 + 1, 75+rand() % 3 + 1, 97+rand() % 3 + 1, 99.2+rand() % 3 + 1);
        PatientData p10("Bandook Khan", 28, 2789, 75+rand() % 3 + 1, 125+rand() % 3 + 1, 70+rand() % 3 + 1, 91+rand() % 3 + 1, 98.8+rand() % 3 + 1);

        ofstream file("patientdata.dat", ios::out | ios::binary);
    
        // close the file
        file.close();
        cout << "File emptied successfully." << endl;
        cout<<endl;

        p.randomdata(p);
        p2.randomdata(p2);
        p3.randomdata(p3);
        p4.randomdata(p4);
        p5.randomdata(p5);
        p6.randomdata(p6);
        p7.randomdata(p7);
        p8.randomdata(p8);
        p9.randomdata(p9);
        p10.randomdata(p10);
    }
    else if(MR_number==4213)
    {
        PatientData p("Arham Ahmed",18,2191,60+rand() % 3 + 1,120+rand() % 3 + 1,80+rand() % 3 + 1,70+rand() % 3 + 1,98.6+rand() % 3 + 1);
        PatientData p2("John Smith",50,9012,78+rand() % 3 + 1, 140+rand() % 3 + 1, 75+rand() % 3 + 1, 94+rand() % 3 + 1, 99.4+rand() % 3 + 1);
        PatientData p3("Sarah Williams", 35, 1010, 80+rand() % 3 + 1, 120+rand() % 3 + 1, 80+rand() % 3 + 1, 96+rand() % 3 + 1, 98.5+rand() % 2 + 1);
        PatientData p4("James Lee", 42, 2145, 85+rand() % 3 + 1, 125+rand() % 3 + 1, 80+rand() % 3 + 1, 97+rand() % 3 + 1, 99.2+rand() % 3 + 1);
        PatientData p5("Jacob Rodriguez", 44, 1002, 87+rand() % 3 + 1, 128+rand() % 3 + 1, 82+rand() % 3 + 1, 96+rand() % 3 + 1, 99.6+rand() % 3 + 1);
        PatientData p6("Noman Ali", 38, 5742, 85+rand() % 3 + 1, 135+rand() % 3 + 1, 80+rand() % 3 + 1, 93+rand() % 3 + 1, 99.8+rand() % 3 + 1);
        PatientData p7("Farhan Ahmed", 41, 7123,80+rand() % 3 + 1, 120+rand() % 3 + 1, 70+rand() % 3 + 1, 95+rand() % 3 + 1, 98.5+rand() % 3 + 1);
        PatientData p8("Muhammad Ali", 35, 4213, heart_rate,bp_high,bp_low,oxygen,temperature);
        PatientData p9("Sher Khan", 45, 6321, 70+rand() % 3 + 1, 130+rand() % 3 + 1, 75+rand() % 3 + 1, 97+rand() % 3 + 1, 99.2+rand() % 3 + 1);
        PatientData p10("Bandook Khan", 28, 2789, 75+rand() % 3 + 1, 125+rand() % 3 + 1, 70+rand() % 3 + 1, 91+rand() % 3 + 1, 98.8+rand() % 3 + 1);

        ofstream file("patientdata.dat", ios::out | ios::binary);
    
        // close the file
        file.close();
        cout << "File emptied successfully." << endl;
        cout<<endl;

        p.randomdata(p);
        p2.randomdata(p2);
        p3.randomdata(p3);
        p4.randomdata(p4);
        p5.randomdata(p5);
        p6.randomdata(p6);
        p7.randomdata(p7);
        p8.randomdata(p8);
        p9.randomdata(p9);
        p10.randomdata(p10);
    }
    else if(MR_number==6321)
    {
        PatientData p("Arham Ahmed",18,2191,60+rand() % 3 + 1,120+rand() % 3 + 1,80+rand() % 3 + 1,70+rand() % 3 + 1,98.6+rand() % 3 + 1);
        PatientData p2("John Smith",50,9012,78+rand() % 3 + 1, 140+rand() % 3 + 1, 75+rand() % 3 + 1, 94+rand() % 3 + 1, 99.4+rand() % 3 + 1);
        PatientData p3("Sarah Williams", 35, 1010, 80+rand() % 3 + 1, 120+rand() % 3 + 1, 80+rand() % 3 + 1, 96+rand() % 3 + 1, 98.5+rand() % 2 + 1);
        PatientData p4("James Lee", 42, 2145, 85+rand() % 3 + 1, 125+rand() % 3 + 1, 80+rand() % 3 + 1, 97+rand() % 3 + 1, 99.2+rand() % 3 + 1);
        PatientData p5("Jacob Rodriguez", 44, 1002, 87+rand() % 3 + 1, 128+rand() % 3 + 1, 82+rand() % 3 + 1, 96+rand() % 3 + 1, 99.6+rand() % 3 + 1);
        PatientData p6("Noman Ali", 38, 5742, 85+rand() % 3 + 1, 135+rand() % 3 + 1, 80+rand() % 3 + 1, 93+rand() % 3 + 1, 99.8+rand() % 3 + 1);
        PatientData p7("Farhan Ahmed", 41, 7123,80+rand() % 3 + 1, 120+rand() % 3 + 1, 70+rand() % 3 + 1, 95+rand() % 3 + 1, 98.5+rand() % 3 + 1);
        PatientData p8("Muhammad Ali", 35, 4213, 70+rand() % 3 + 1, 130+rand() % 3 + 1, 75+rand() % 3 + 1, 97+rand() % 3 + 1, 99.2+rand() % 3 + 1);
        PatientData p9("Sher Khan", 45, 6321, heart_rate,bp_high,bp_low,oxygen,temperature);
        PatientData p10("Bandook Khan", 28, 2789, 75+rand() % 3 + 1, 125+rand() % 3 + 1, 70+rand() % 3 + 1, 91+rand() % 3 + 1, 98.8+rand() % 3 + 1);

        ofstream file("patientdata.dat", ios::out | ios::binary);
    
        // close the file
        file.close();
        cout << "File emptied successfully." << endl;
        cout<<endl;

        p.randomdata(p);
        p2.randomdata(p2);
        p3.randomdata(p3);
        p4.randomdata(p4);
        p5.randomdata(p5);
        p6.randomdata(p6);
        p7.randomdata(p7);
        p8.randomdata(p8);
        p9.randomdata(p9);
        p10.randomdata(p10);
    }
    else if(MR_number==2789)
    {
        PatientData p("Arham Ahmed",18,2191,60+rand() % 3 + 1,120+rand() % 3 + 1,80+rand() % 3 + 1,70+rand() % 3 + 1,98.6+rand() % 3 + 1);
        PatientData p2("John Smith",50,9012,78+rand() % 3 + 1, 140+rand() % 3 + 1, 75+rand() % 3 + 1, 94+rand() % 3 + 1, 99.4+rand() % 3 + 1);
        PatientData p3("Sarah Williams", 35, 1010, 80+rand() % 3 + 1, 120+rand() % 3 + 1, 80+rand() % 3 + 1, 96+rand() % 3 + 1, 98.5+rand() % 2 + 1);
        PatientData p4("James Lee", 42, 2145, 85+rand() % 3 + 1, 125+rand() % 3 + 1, 80+rand() % 3 + 1, 97+rand() % 3 + 1, 99.2+rand() % 3 + 1);
        PatientData p5("Jacob Rodriguez", 44, 1002, 87+rand() % 3 + 1, 128+rand() % 3 + 1, 82+rand() % 3 + 1, 96+rand() % 3 + 1, 99.6+rand() % 3 + 1);
        PatientData p6("Noman Ali", 38, 5742, 85+rand() % 3 + 1, 135+rand() % 3 + 1, 80+rand() % 3 + 1, 93+rand() % 3 + 1, 99.8+rand() % 3 + 1);
        PatientData p7("Farhan Ahmed", 41, 7123,80+rand() % 3 + 1, 120+rand() % 3 + 1, 70+rand() % 3 + 1, 95+rand() % 3 + 1, 98.5+rand() % 3 + 1);
        PatientData p8("Muhammad Ali", 35, 4213, 70+rand() % 3 + 1, 130+rand() % 3 + 1, 75+rand() % 3 + 1, 97+rand() % 3 + 1, 99.2+rand() % 3 + 1);
        PatientData p9("Sher Khan", 45, 6321, 75+rand() % 3 + 1, 125+rand() % 3 + 1, 70+rand() % 3 + 1, 91+rand() % 3 + 1, 98.8+rand() % 3 + 1);
        PatientData p10("Bandook Khan", 28, 2789, heart_rate,bp_high,bp_low,oxygen,temperature);

        ofstream file("patientdata.dat", ios::out | ios::binary);
    
        // close the file
        file.close();
        cout << "File emptied successfully." << endl;
        cout<<endl;

        p.randomdata(p);
        p2.randomdata(p2);
        p3.randomdata(p3);
        p4.randomdata(p4);
        p5.randomdata(p5);
        p6.randomdata(p6);
        p7.randomdata(p7);
        p8.randomdata(p8);
        p9.randomdata(p9);
        p10.randomdata(p10);
    }
}

void PatientData::infogeneral()
{
    cout<<"Name           = "<<name<<endl;
    cout<<"Age            = "<<age<<endl;
    cout<<"MR number      = "<<MR_number<<endl;
    cout<<"Heart Rate     = "<<heart_rate<<endl;
    cout<<"Blood pressure = "<<bp_high<<"/"<<bp_low<<endl;
    cout<<"Oxygen Rate    = "<<oxygen<<endl;
    cout<<"Temperature    = "<<temperature<<endl;

    set_heart_rate();
    heart_rate = get_heart_rate();
    //cout<<"New heart rate = "<<heart_rate<<endl;
    setbp_low();
    bp_low = getbp_low();
    setbp_high();
    bp_high = getbp_high();
    set_oxygen();
    oxygen = get_oxygen();
    set_temperature();
    temperature = get_temperature();

    if(MR_number==2191)
    {
        PatientData p("Arham Ahmed",18,2191,heart_rate,bp_high,bp_low,oxygen,temperature);
        PatientData p2("John Smith",50,9012,70,159,60,90,100.1);
        PatientData p3("Sarah Williams", 35, 1010, 80, 120, 80, 96, 98.5);
        PatientData p4("James Lee", 42, 2145, 85, 125, 80, 97, 99.2);
        PatientData p5("Jacob Rodriguez", 44, 1002, 87, 128, 82, 96, 100.6);
        PatientData p6("Noman Ali", 38, 5742, 85, 135, 80, 93, 99.8);
        PatientData p7("Farhan Ahmed", 41, 7123, 78, 140, 75, 94, 99.4);
        PatientData p8("Muhammad Ali", 35, 4213, 80, 120, 70, 95, 98.5);
        PatientData p9("Sher Khan", 45, 6321, 70, 130, 75, 97, 99.2);
        PatientData p10("Bandook Khan", 28, 2789, 75, 125, 70, 91, 98.8);

        ofstream file("patientdata.dat", ios::out | ios::binary);
    
        // close the file
        file.close();
        cout << "File emptied successfully." << endl;
        cout<<endl;

        p.randomdata(p);
        p2.randomdata(p2);
        p3.randomdata(p3);
        p4.randomdata(p4);
        p5.randomdata(p5);
        p6.randomdata(p6);
        p7.randomdata(p7);
        p8.randomdata(p8);
        p9.randomdata(p9);
        p10.randomdata(p10);
    }
    else if(MR_number==9012)
    {

        PatientData p("Arham Ahmed",18,2191,60+rand() % 3 + 1,120+rand() % 3 + 1,80+rand() % 3 + 1,70+rand() % 3 + 1,98.6+rand() % 3 + 1);
        PatientData p2("John Smith",50,9012,heart_rate,bp_high,bp_low,oxygen,temperature);
        PatientData p3("Sarah Williams", 35, 1010, 80+rand() % 3 + 1, 120+rand() % 3 + 1, 80+rand() % 3 + 1, 96+rand() % 3 + 1, 98.5+rand() % 2 + 1);
        PatientData p4("James Lee", 42, 2145, 85+rand() % 3 + 1, 125+rand() % 3 + 1, 80+rand() % 3 + 1, 97+rand() % 3 + 1, 99.2+rand() % 3 + 1);
        PatientData p5("Jacob Rodriguez", 44, 1002, 87+rand() % 3 + 1, 128+rand() % 3 + 1, 82+rand() % 3 + 1, 96+rand() % 3 + 1, 99.6+rand() % 3 + 1);
        PatientData p6("Noman Ali", 38, 5742, 85+rand() % 3 + 1, 135+rand() % 3 + 1, 80+rand() % 3 + 1, 93+rand() % 3 + 1, 99.8+rand() % 3 + 1);
        PatientData p7("Farhan Ahmed", 41, 7123, 78+rand() % 3 + 1, 140+rand() % 3 + 1, 75+rand() % 3 + 1, 94+rand() % 3 + 1, 99.4+rand() % 3 + 1);
        PatientData p8("Muhammad Ali", 35, 4213, 80+rand() % 3 + 1, 120+rand() % 3 + 1, 70+rand() % 3 + 1, 95+rand() % 3 + 1, 98.5+rand() % 3 + 1);
        PatientData p9("Sher Khan", 45, 6321, 70+rand() % 3 + 1, 130+rand() % 3 + 1, 75+rand() % 3 + 1, 97+rand() % 3 + 1, 99.2+rand() % 3 + 1);
        PatientData p10("Bandook Khan", 28, 2789, 75+rand() % 3 + 1, 125+rand() % 3 + 1, 70+rand() % 3 + 1, 91+rand() % 3 + 1, 98.8+rand() % 3 + 1);

        ofstream file("patientdata.dat", ios::out | ios::binary);
    
        // close the file
        file.close();
        cout << "File emptied successfully." << endl;
        cout<<endl;

        p.randomdata(p);
        p2.randomdata(p2);
        p3.randomdata(p3);
        p4.randomdata(p4);
        p5.randomdata(p5);
        p6.randomdata(p6);
        p7.randomdata(p7);
        p8.randomdata(p8);
        p9.randomdata(p9);
        p10.randomdata(p10);
    }
    else if(MR_number==1010)
    {
        PatientData p("Arham Ahmed",18,2191,60+rand() % 3 + 1,120+rand() % 3 + 1,80+rand() % 3 + 1,70+rand() % 3 + 1,98.6+rand() % 3 + 1);
        PatientData p2("John Smith",50,9012,80+rand() % 3 + 1, 120+rand() % 3 + 1, 80+rand() % 3 + 1, 96+rand() % 3 + 1, 98.5+rand() % 2 + 1);
        PatientData p3("Sarah Williams", 35, 1010, heart_rate,bp_high,bp_low,oxygen,temperature);
        PatientData p4("James Lee", 42, 2145, 85+rand() % 3 + 1, 125+rand() % 3 + 1, 80+rand() % 3 + 1, 97+rand() % 3 + 1, 99.2+rand() % 3 + 1);
        PatientData p5("Jacob Rodriguez", 44, 1002, 87+rand() % 3 + 1, 128+rand() % 3 + 1, 82+rand() % 3 + 1, 96+rand() % 3 + 1, 99.6+rand() % 3 + 1);
        PatientData p6("Noman Ali", 38, 5742, 85+rand() % 3 + 1, 135+rand() % 3 + 1, 80+rand() % 3 + 1, 93+rand() % 3 + 1, 99.8+rand() % 3 + 1);
        PatientData p7("Farhan Ahmed", 41, 7123, 78+rand() % 3 + 1, 140+rand() % 3 + 1, 75+rand() % 3 + 1, 94+rand() % 3 + 1, 99.4+rand() % 3 + 1);
        PatientData p8("Muhammad Ali", 35, 4213, 80+rand() % 3 + 1, 120+rand() % 3 + 1, 70+rand() % 3 + 1, 95+rand() % 3 + 1, 98.5+rand() % 3 + 1);
        PatientData p9("Sher Khan", 45, 6321, 70+rand() % 3 + 1, 130+rand() % 3 + 1, 75+rand() % 3 + 1, 97+rand() % 3 + 1, 99.2+rand() % 3 + 1);
        PatientData p10("Bandook Khan", 28, 2789, 75+rand() % 3 + 1, 125+rand() % 3 + 1, 70+rand() % 3 + 1, 91+rand() % 3 + 1, 98.8+rand() % 3 + 1);

        ofstream file("patientdata.dat", ios::out | ios::binary);
    
        // close the file
        file.close();
        cout << "File emptied successfully." << endl;
        cout<<endl;

        p.randomdata(p);
        p2.randomdata(p2);
        p3.randomdata(p3);
        p4.randomdata(p4);
        p5.randomdata(p5);
        p6.randomdata(p6);
        p7.randomdata(p7);
        p8.randomdata(p8);
        p9.randomdata(p9);
        p10.randomdata(p10);
    }
    else if(MR_number==2145)
    {
        PatientData p("Arham Ahmed",18,2191,60-rand() % 3 + 1,120-rand() % 3 + 1,80-rand() % 3 + 1,70-rand() % 3 + 1,98.6-rand() % 3 + 1);
        PatientData p2("John Smith",50,9012,85-rand() % 3 + 1, 125-rand() % 3 + 1, 80-rand() % 3 + 1, 97-rand() % 3 + 1, 99.2-rand() % 3 + 1);
        PatientData p3("Sarah Williams", 35, 1010, 80-rand() % 3 + 1, 120-rand() % 3 + 1, 80-rand() % 3 + 1, 96-rand() % 3 + 1, 98.5-rand() % 2 + 1);
        PatientData p4("James Lee", 42, 2145, heart_rate,bp_high,bp_low,oxygen,temperature);
        PatientData p5("Jacob Rodriguez", 44, 1002, 87-rand() % 3 + 1, 128-rand() % 3 + 1, 82-rand() % 3 + 1, 96-rand() % 3 + 1, 100.6-rand() % 3 + 1);
        PatientData p6("Noman Ali", 38, 5742, 85-rand() % 3 + 1, 135-rand() % 3 + 1, 80-rand() % 3 + 1, 93-rand() % 3 + 1, 99.8-rand() % 3 + 1);
        PatientData p7("Farhan Ahmed", 41, 7123, 78-rand() % 3 + 1, 140-rand() % 3 + 1, 75-rand() % 3 + 1, 94-rand() % 3 + 1, 99.4-rand() % 3 + 1);
        PatientData p8("Muhammad Ali", 35, 4213, 80-rand() % 3 + 1, 120-rand() % 3 + 1, 70-rand() % 3 + 1, 95-rand() % 3 + 1, 98.5-rand() % 3 + 1);
        PatientData p9("Sher Khan", 45, 6321, 70-rand() % 3 + 1, 130-rand() % 3 + 1, 75-rand() % 3 + 1, 97-rand() % 3 + 1, 99.2-rand() % 3 + 1);
        PatientData p10("Bandook Khan", 28, 2789, 75-rand() % 3 + 1, 125-rand() % 3 + 1, 70-rand() % 3 + 1, 91-rand() % 3 + 1, 98.8-rand() % 3 + 1);

        ofstream file("patientdata.dat", ios::out | ios::binary);
    
        // close the file
        file.close();
        cout << "File emptied successfully." << endl;
        cout<<endl;

        p.randomdata(p);
        p2.randomdata(p2);
        p3.randomdata(p3);
        p4.randomdata(p4);
        p5.randomdata(p5);
        p6.randomdata(p6);
        p7.randomdata(p7);
        p8.randomdata(p8);
        p9.randomdata(p9);
        p10.randomdata(p10);
    }
    else if(MR_number==1002)
    {
        PatientData p("Arham Ahmed",18,2191,60-rand() % 3 + 1,120-rand() % 3 + 1,80-rand() % 3 + 1,70-rand() % 3 + 1,98.6-rand() % 3 + 1);
        PatientData p2("John Smith",50,9012,85-rand() % 3 + 1, 125-rand() % 3 + 1, 80-rand() % 3 + 1, 97-rand() % 3 + 1, 99.2-rand() % 3 + 1);
        PatientData p3("Sarah Williams", 35, 1010, 80-rand() % 3 + 1, 120-rand() % 3 + 1, 80-rand() % 3 + 1, 96-rand() % 3 + 1, 98.5-rand() % 2 + 1);
        PatientData p4("James Lee", 42, 2145, 85-rand() % 3 + 1, 125-rand() % 3 + 1, 80-rand() % 3 + 1, 97-rand() % 3 + 1, 99.2-rand() % 3 + 1);
        PatientData p5("Jacob Rodriguez", 44, 1002, heart_rate,bp_high,bp_low,oxygen,temperature);
        PatientData p6("Noman Ali", 38, 5742, 85-rand() % 3 + 1, 135-rand() % 3 + 1, 80-rand() % 3 + 1, 93-rand() % 3 + 1, 99.8-rand() % 3 + 1);
        PatientData p7("Farhan Ahmed", 41, 7123, 78-rand() % 3 + 1, 140-rand() % 3 + 1, 75-rand() % 3 + 1, 94-rand() % 3 + 1, 99.4-rand() % 3 + 1);
        PatientData p8("Muhammad Ali", 35, 4213, 80-rand() % 3 + 1, 120-rand() % 3 + 1, 70-rand() % 3 + 1, 95-rand() % 3 + 1, 98.5-rand() % 3 + 1);
        PatientData p9("Sher Khan", 45, 6321, 70-rand() % 3 + 1, 130-rand() % 3 + 1, 75-rand() % 3 + 1, 97-rand() % 3 + 1, 99.2-rand() % 3 + 1);
        PatientData p10("Bandook Khan", 28, 2789, 75-rand() % 3 + 1, 125-rand() % 3 + 1, 70-rand() % 3 + 1, 91-rand() % 3 + 1, 98.8-rand() % 3 + 1);

        ofstream file("patientdata.dat", ios::out | ios::binary);
    
        // close the file
        file.close();
        cout << "File emptied successfully." << endl;
        cout<<endl;

        p.randomdata(p);
        p2.randomdata(p2);
        p3.randomdata(p3);
        p4.randomdata(p4);
        p5.randomdata(p5);
        p6.randomdata(p6);
        p7.randomdata(p7);
        p8.randomdata(p8);
        p9.randomdata(p9);
        p10.randomdata(p10);
    }
    else if(MR_number==5742)
    {
        PatientData p("Arham Ahmed",18,2191,60-rand() % 3 + 1,120-rand() % 3 + 1,80-rand() % 3 + 1,70-rand() % 3 + 1,98.6-rand() % 3 + 1);
        PatientData p2("John Smith",50,9012,85-rand() % 3 + 1, 125-rand() % 3 + 1, 80-rand() % 3 + 1, 97-rand() % 3 + 1, 99.2-rand() % 3 + 1);
        PatientData p3("Sarah Williams", 35, 1010, 80-rand() % 3 + 1, 120-rand() % 3 + 1, 80-rand() % 3 + 1, 96-rand() % 3 + 1, 98.5-rand() % 2 + 1);
        PatientData p4("James Lee", 42, 2145, 85-rand() % 3 + 1, 125-rand() % 3 + 1, 80-rand() % 3 + 1, 97-rand() % 3 + 1, 99.2-rand() % 3 + 1);
        PatientData p5("Jacob Rodriguez", 44, 1002, 87-rand() % 3 + 1, 128-rand() % 3 + 1, 82-rand() % 3 + 1, 96-rand() % 3 + 1, 100.6-rand() % 3 + 1);
        PatientData p6("Noman Ali", 38, 5742, heart_rate,bp_high,bp_low,oxygen,temperature);
        PatientData p7("Farhan Ahmed", 41, 7123, 78-rand() % 3 + 1, 140-rand() % 3 + 1, 75-rand() % 3 + 1, 94-rand() % 3 + 1, 99.4-rand() % 3 + 1);
        PatientData p8("Muhammad Ali", 35, 4213, 80-rand() % 3 + 1, 120-rand() % 3 + 1, 70-rand() % 3 + 1, 95-rand() % 3 + 1, 98.5-rand() % 3 + 1);
        PatientData p9("Sher Khan", 45, 6321, 70-rand() % 3 + 1, 130-rand() % 3 + 1, 75-rand() % 3 + 1, 97-rand() % 3 + 1, 99.2-rand() % 3 + 1);
        PatientData p10("Bandook Khan", 28, 2789, 75-rand() % 3 + 1, 125-rand() % 3 + 1, 70-rand() % 3 + 1, 91-rand() % 3 + 1, 98.8-rand() % 3 + 1);

        ofstream file("patientdata.dat", ios::out | ios::binary);
    
        // close the file
        file.close();
        cout << "File emptied successfully." << endl;
        cout<<endl;

        p.randomdata(p);
        p2.randomdata(p2);
        p3.randomdata(p3);
        p4.randomdata(p4);
        p5.randomdata(p5);
        p6.randomdata(p6);
        p7.randomdata(p7);
        p8.randomdata(p8);
        p9.randomdata(p9);
        p10.randomdata(p10);
    }
    else if(MR_number==7123)
    {
        PatientData p("Arham Ahmed",18,2191,60+rand() % 3 + 1,120+rand() % 3 + 1,80+rand() % 3 + 1,70+rand() % 3 + 1,98.6+rand() % 3 + 1);
        PatientData p2("John Smith",50,9012,78+rand() % 3 + 1, 140+rand() % 3 + 1, 75+rand() % 3 + 1, 94+rand() % 3 + 1, 99.4+rand() % 3 + 1);
        PatientData p3("Sarah Williams", 35, 1010, 80+rand() % 3 + 1, 120+rand() % 3 + 1, 80+rand() % 3 + 1, 96+rand() % 3 + 1, 98.5+rand() % 2 + 1);
        PatientData p4("James Lee", 42, 2145, 85+rand() % 3 + 1, 125+rand() % 3 + 1, 80+rand() % 3 + 1, 97+rand() % 3 + 1, 99.2+rand() % 3 + 1);
        PatientData p5("Jacob Rodriguez", 44, 1002, 87+rand() % 3 + 1, 128+rand() % 3 + 1, 82+rand() % 3 + 1, 96+rand() % 3 + 1, 99.6+rand() % 3 + 1);
        PatientData p6("Noman Ali", 38, 5742, 85+rand() % 3 + 1, 135+rand() % 3 + 1, 80+rand() % 3 + 1, 93+rand() % 3 + 1, 99.8+rand() % 3 + 1);
        PatientData p7("Farhan Ahmed", 41, 7123, heart_rate,bp_high,bp_low,oxygen,temperature);
        PatientData p8("Muhammad Ali", 35, 4213, 80+rand() % 3 + 1, 120+rand() % 3 + 1, 70+rand() % 3 + 1, 95+rand() % 3 + 1, 98.5+rand() % 3 + 1);
        PatientData p9("Sher Khan", 45, 6321, 70+rand() % 3 + 1, 130+rand() % 3 + 1, 75+rand() % 3 + 1, 97+rand() % 3 + 1, 99.2+rand() % 3 + 1);
        PatientData p10("Bandook Khan", 28, 2789, 75+rand() % 3 + 1, 125+rand() % 3 + 1, 70+rand() % 3 + 1, 91+rand() % 3 + 1, 98.8+rand() % 3 + 1);

        ofstream file("patientdata.dat", ios::out | ios::binary);
    
        // close the file
        file.close();
        cout << "File emptied successfully." << endl;
        cout<<endl;

        p.randomdata(p);
        p2.randomdata(p2);
        p3.randomdata(p3);
        p4.randomdata(p4);
        p5.randomdata(p5);
        p6.randomdata(p6);
        p7.randomdata(p7);
        p8.randomdata(p8);
        p9.randomdata(p9);
        p10.randomdata(p10);
    }
    else if(MR_number==4213)
    {
        PatientData p("Arham Ahmed",18,2191,60+rand() % 3 + 1,120+rand() % 3 + 1,80+rand() % 3 + 1,70+rand() % 3 + 1,98.6+rand() % 3 + 1);
        PatientData p2("John Smith",50,9012,78+rand() % 3 + 1, 140+rand() % 3 + 1, 75+rand() % 3 + 1, 94+rand() % 3 + 1, 99.4+rand() % 3 + 1);
        PatientData p3("Sarah Williams", 35, 1010, 80+rand() % 3 + 1, 120+rand() % 3 + 1, 80+rand() % 3 + 1, 96+rand() % 3 + 1, 98.5+rand() % 2 + 1);
        PatientData p4("James Lee", 42, 2145, 85+rand() % 3 + 1, 125+rand() % 3 + 1, 80+rand() % 3 + 1, 97+rand() % 3 + 1, 99.2+rand() % 3 + 1);
        PatientData p5("Jacob Rodriguez", 44, 1002, 87+rand() % 3 + 1, 128+rand() % 3 + 1, 82+rand() % 3 + 1, 96+rand() % 3 + 1, 99.6+rand() % 3 + 1);
        PatientData p6("Noman Ali", 38, 5742, 85+rand() % 3 + 1, 135+rand() % 3 + 1, 80+rand() % 3 + 1, 93+rand() % 3 + 1, 99.8+rand() % 3 + 1);
        PatientData p7("Farhan Ahmed", 41, 7123,80+rand() % 3 + 1, 120+rand() % 3 + 1, 70+rand() % 3 + 1, 95+rand() % 3 + 1, 98.5+rand() % 3 + 1);
        PatientData p8("Muhammad Ali", 35, 4213, heart_rate,bp_high,bp_low,oxygen,temperature);
        PatientData p9("Sher Khan", 45, 6321, 70+rand() % 3 + 1, 130+rand() % 3 + 1, 75+rand() % 3 + 1, 97+rand() % 3 + 1, 99.2+rand() % 3 + 1);
        PatientData p10("Bandook Khan", 28, 2789, 75+rand() % 3 + 1, 125+rand() % 3 + 1, 70+rand() % 3 + 1, 91+rand() % 3 + 1, 98.8+rand() % 3 + 1);

        ofstream file("patientdata.dat", ios::out | ios::binary);
    
        // close the file
        file.close();
        cout << "File emptied successfully." << endl;
        cout<<endl;

        p.randomdata(p);
        p2.randomdata(p2);
        p3.randomdata(p3);
        p4.randomdata(p4);
        p5.randomdata(p5);
        p6.randomdata(p6);
        p7.randomdata(p7);
        p8.randomdata(p8);
        p9.randomdata(p9);
        p10.randomdata(p10);
    }
    else if(MR_number==6321)
    {
        PatientData p("Arham Ahmed",18,2191,60+rand() % 3 + 1,120+rand() % 3 + 1,80+rand() % 3 + 1,70+rand() % 3 + 1,98.6+rand() % 3 + 1);
        PatientData p2("John Smith",50,9012,78+rand() % 3 + 1, 140+rand() % 3 + 1, 75+rand() % 3 + 1, 94+rand() % 3 + 1, 99.4+rand() % 3 + 1);
        PatientData p3("Sarah Williams", 35, 1010, 80+rand() % 3 + 1, 120+rand() % 3 + 1, 80+rand() % 3 + 1, 96+rand() % 3 + 1, 98.5+rand() % 2 + 1);
        PatientData p4("James Lee", 42, 2145, 85+rand() % 3 + 1, 125+rand() % 3 + 1, 80+rand() % 3 + 1, 97+rand() % 3 + 1, 99.2+rand() % 3 + 1);
        PatientData p5("Jacob Rodriguez", 44, 1002, 87+rand() % 3 + 1, 128+rand() % 3 + 1, 82+rand() % 3 + 1, 96+rand() % 3 + 1, 99.6+rand() % 3 + 1);
        PatientData p6("Noman Ali", 38, 5742, 85+rand() % 3 + 1, 135+rand() % 3 + 1, 80+rand() % 3 + 1, 93+rand() % 3 + 1, 99.8+rand() % 3 + 1);
        PatientData p7("Farhan Ahmed", 41, 7123,80+rand() % 3 + 1, 120+rand() % 3 + 1, 70+rand() % 3 + 1, 95+rand() % 3 + 1, 98.5+rand() % 3 + 1);
        PatientData p8("Muhammad Ali", 35, 4213, 70+rand() % 3 + 1, 130+rand() % 3 + 1, 75+rand() % 3 + 1, 97+rand() % 3 + 1, 99.2+rand() % 3 + 1);
        PatientData p9("Sher Khan", 45, 6321, heart_rate,bp_high,bp_low,oxygen,temperature);
        PatientData p10("Bandook Khan", 28, 2789, 75+rand() % 3 + 1, 125+rand() % 3 + 1, 70+rand() % 3 + 1, 91+rand() % 3 + 1, 98.8+rand() % 3 + 1);

        ofstream file("patientdata.dat", ios::out | ios::binary);
    
        // close the file
        file.close();
        cout << "File emptied successfully." << endl;
        cout<<endl;

        p.randomdata(p);
        p2.randomdata(p2);
        p3.randomdata(p3);
        p4.randomdata(p4);
        p5.randomdata(p5);
        p6.randomdata(p6);
        p7.randomdata(p7);
        p8.randomdata(p8);
        p9.randomdata(p9);
        p10.randomdata(p10);
    }
    else if(MR_number==2789)
    {
        PatientData p("Arham Ahmed",18,2191,60+rand() % 3 + 1,120+rand() % 3 + 1,80+rand() % 3 + 1,70+rand() % 3 + 1,98.6+rand() % 3 + 1);
        PatientData p2("John Smith",50,9012,78+rand() % 3 + 1, 140+rand() % 3 + 1, 75+rand() % 3 + 1, 94+rand() % 3 + 1, 99.4+rand() % 3 + 1);
        PatientData p3("Sarah Williams", 35, 1010, 80+rand() % 3 + 1, 120+rand() % 3 + 1, 80+rand() % 3 + 1, 96+rand() % 3 + 1, 98.5+rand() % 2 + 1);
        PatientData p4("James Lee", 42, 2145, 85+rand() % 3 + 1, 125+rand() % 3 + 1, 80+rand() % 3 + 1, 97+rand() % 3 + 1, 99.2+rand() % 3 + 1);
        PatientData p5("Jacob Rodriguez", 44, 1002, 87+rand() % 3 + 1, 128+rand() % 3 + 1, 82+rand() % 3 + 1, 96+rand() % 3 + 1, 99.6+rand() % 3 + 1);
        PatientData p6("Noman Ali", 38, 5742, 85+rand() % 3 + 1, 135+rand() % 3 + 1, 80+rand() % 3 + 1, 93+rand() % 3 + 1, 99.8+rand() % 3 + 1);
        PatientData p7("Farhan Ahmed", 41, 7123,80+rand() % 3 + 1, 120+rand() % 3 + 1, 70+rand() % 3 + 1, 95+rand() % 3 + 1, 98.5+rand() % 3 + 1);
        PatientData p8("Muhammad Ali", 35, 4213, 70+rand() % 3 + 1, 130+rand() % 3 + 1, 75+rand() % 3 + 1, 97+rand() % 3 + 1, 99.2+rand() % 3 + 1);
        PatientData p9("Sher Khan", 45, 6321, 75+rand() % 3 + 1, 125+rand() % 3 + 1, 70+rand() % 3 + 1, 91+rand() % 3 + 1, 98.8+rand() % 3 + 1);
        PatientData p10("Bandook Khan", 28, 2789, heart_rate,bp_high,bp_low,oxygen,temperature);

        ofstream file("patientdata.dat", ios::out | ios::binary);
    
        // close the file
        file.close();
        cout << "File emptied successfully." << endl;
        cout<<endl;

        p.randomdata(p);
        p2.randomdata(p2);
        p3.randomdata(p3);
        p4.randomdata(p4);
        p5.randomdata(p5);
        p6.randomdata(p6);
        p7.randomdata(p7);
        p8.randomdata(p8);
        p9.randomdata(p9);
        p10.randomdata(p10);
    }
}

void PatientData::info()
{
    cout<<"Name           = "<<name<<endl;
    cout<<"Age            = "<<age<<endl;
    cout<<"MR number      = "<<MR_number<<endl;
    cout<<"Heart Rate     = "<<heart_rate<<endl;
    cout<<"Blood pressure = "<<bp_high<<"/"<<bp_low<<endl;
    cout<<"Oxygen Rate    = "<<oxygen<<endl;
    cout<<"Temperature    = "<<temperature<<endl;

    set_heart_rate();
    heart_rate = get_heart_rate();
    //cout<<"New heart rate = "<<heart_rate<<endl;
    setbp_low();
    bp_low = getbp_low();
    setbp_high();
    bp_high = getbp_high();
    set_oxygen();
    oxygen = get_oxygen();
    set_temperature();
    temperature = get_temperature();

    if(MR_number==2191)
    {
        PatientData p("Arham Ahmed",18,2191,heart_rate,bp_high,bp_low,oxygen,temperature);
        PatientData p2("John Smith",50,9012,70,159,60,90,100.1);
        PatientData p3("Sarah Williams", 35, 1010, 80, 120, 80, 96, 98.5);
        PatientData p4("James Lee", 42, 2145, 85, 125, 80, 97, 99.2);
        PatientData p5("Jacob Rodriguez", 44, 1002, 87, 128, 82, 96, 100.6);
        PatientData p6("Noman Ali", 38, 5742, 85, 135, 80, 93, 99.8);
        PatientData p7("Farhan Ahmed", 41, 7123, 78, 140, 75, 94, 99.4);
        PatientData p8("Muhammad Ali", 35, 4213, 80, 120, 70, 95, 98.5);
        PatientData p9("Sher Khan", 45, 6321, 70, 130, 75, 97, 99.2);
        PatientData p10("Bandook Khan", 28, 2789, 75, 125, 70, 91, 98.8);

        ofstream file("patientdata.dat", ios::out | ios::binary);
    
        // close the file
        file.close();
        cout << "File emptied successfully." << endl;
        cout<<endl;

        p.randomdata(p);
        p2.randomdata(p2);
        p3.randomdata(p3);
        p4.randomdata(p4);
        p5.randomdata(p5);
        p6.randomdata(p6);
        p7.randomdata(p7);
        p8.randomdata(p8);
        p9.randomdata(p9);
        p10.randomdata(p10);
    }
    else if(MR_number==9012)
    {

        PatientData p("Arham Ahmed",18,2191,60+rand() % 3 + 1,120+rand() % 3 + 1,80+rand() % 3 + 1,70+rand() % 3 + 1,98.6+rand() % 3 + 1);
        PatientData p2("John Smith",50,9012,heart_rate,bp_high,bp_low,oxygen,temperature);
        PatientData p3("Sarah Williams", 35, 1010, 80+rand() % 3 + 1, 120+rand() % 3 + 1, 80+rand() % 3 + 1, 96+rand() % 3 + 1, 98.5+rand() % 2 + 1);
        PatientData p4("James Lee", 42, 2145, 85+rand() % 3 + 1, 125+rand() % 3 + 1, 80+rand() % 3 + 1, 97+rand() % 3 + 1, 99.2+rand() % 3 + 1);
        PatientData p5("Jacob Rodriguez", 44, 1002, 87+rand() % 3 + 1, 128+rand() % 3 + 1, 82+rand() % 3 + 1, 96+rand() % 3 + 1, 99.6+rand() % 3 + 1);
        PatientData p6("Noman Ali", 38, 5742, 85+rand() % 3 + 1, 135+rand() % 3 + 1, 80+rand() % 3 + 1, 93+rand() % 3 + 1, 99.8+rand() % 3 + 1);
        PatientData p7("Farhan Ahmed", 41, 7123, 78+rand() % 3 + 1, 140+rand() % 3 + 1, 75+rand() % 3 + 1, 94+rand() % 3 + 1, 99.4+rand() % 3 + 1);
        PatientData p8("Muhammad Ali", 35, 4213, 80+rand() % 3 + 1, 120+rand() % 3 + 1, 70+rand() % 3 + 1, 95+rand() % 3 + 1, 98.5+rand() % 3 + 1);
        PatientData p9("Sher Khan", 45, 6321, 70+rand() % 3 + 1, 130+rand() % 3 + 1, 75+rand() % 3 + 1, 97+rand() % 3 + 1, 99.2+rand() % 3 + 1);
        PatientData p10("Bandook Khan", 28, 2789, 75+rand() % 3 + 1, 125+rand() % 3 + 1, 70+rand() % 3 + 1, 91+rand() % 3 + 1, 98.8+rand() % 3 + 1);

        ofstream file("patientdata.dat", ios::out | ios::binary);
    
        // close the file
        file.close();
        cout << "File emptied successfully." << endl;
        cout<<endl;

        p.randomdata(p);
        p2.randomdata(p2);
        p3.randomdata(p3);
        p4.randomdata(p4);
        p5.randomdata(p5);
        p6.randomdata(p6);
        p7.randomdata(p7);
        p8.randomdata(p8);
        p9.randomdata(p9);
        p10.randomdata(p10);
    }
    else if(MR_number==1010)
    {
        PatientData p("Arham Ahmed",18,2191,60+rand() % 3 + 1,120+rand() % 3 + 1,80+rand() % 3 + 1,70+rand() % 3 + 1,98.6+rand() % 3 + 1);
        PatientData p2("John Smith",50,9012,80+rand() % 3 + 1, 120+rand() % 3 + 1, 80+rand() % 3 + 1, 96+rand() % 3 + 1, 98.5+rand() % 2 + 1);
        PatientData p3("Sarah Williams", 35, 1010, heart_rate,bp_high,bp_low,oxygen,temperature);
        PatientData p4("James Lee", 42, 2145, 85+rand() % 3 + 1, 125+rand() % 3 + 1, 80+rand() % 3 + 1, 97+rand() % 3 + 1, 99.2+rand() % 3 + 1);
        PatientData p5("Jacob Rodriguez", 44, 1002, 87+rand() % 3 + 1, 128+rand() % 3 + 1, 82+rand() % 3 + 1, 96+rand() % 3 + 1, 99.6+rand() % 3 + 1);
        PatientData p6("Noman Ali", 38, 5742, 85+rand() % 3 + 1, 135+rand() % 3 + 1, 80+rand() % 3 + 1, 93+rand() % 3 + 1, 99.8+rand() % 3 + 1);
        PatientData p7("Farhan Ahmed", 41, 7123, 78+rand() % 3 + 1, 140+rand() % 3 + 1, 75+rand() % 3 + 1, 94+rand() % 3 + 1, 99.4+rand() % 3 + 1);
        PatientData p8("Muhammad Ali", 35, 4213, 80+rand() % 3 + 1, 120+rand() % 3 + 1, 70+rand() % 3 + 1, 95+rand() % 3 + 1, 98.5+rand() % 3 + 1);
        PatientData p9("Sher Khan", 45, 6321, 70+rand() % 3 + 1, 130+rand() % 3 + 1, 75+rand() % 3 + 1, 97+rand() % 3 + 1, 99.2+rand() % 3 + 1);
        PatientData p10("Bandook Khan", 28, 2789, 75+rand() % 3 + 1, 125+rand() % 3 + 1, 70+rand() % 3 + 1, 91+rand() % 3 + 1, 98.8+rand() % 3 + 1);

        ofstream file("patientdata.dat", ios::out | ios::binary);
    
        // close the file
        file.close();
        cout << "File emptied successfully." << endl;
        cout<<endl;

        p.randomdata(p);
        p2.randomdata(p2);
        p3.randomdata(p3);
        p4.randomdata(p4);
        p5.randomdata(p5);
        p6.randomdata(p6);
        p7.randomdata(p7);
        p8.randomdata(p8);
        p9.randomdata(p9);
        p10.randomdata(p10);
    }
    else if(MR_number==2145)
    {
        PatientData p("Arham Ahmed",18,2191,60-rand() % 3 + 1,120-rand() % 3 + 1,80-rand() % 3 + 1,70-rand() % 3 + 1,98.6-rand() % 3 + 1);
        PatientData p2("John Smith",50,9012,85-rand() % 3 + 1, 125-rand() % 3 + 1, 80-rand() % 3 + 1, 97-rand() % 3 + 1, 99.2-rand() % 3 + 1);
        PatientData p3("Sarah Williams", 35, 1010, 80-rand() % 3 + 1, 120-rand() % 3 + 1, 80-rand() % 3 + 1, 96-rand() % 3 + 1, 98.5-rand() % 2 + 1);
        PatientData p4("James Lee", 42, 2145, heart_rate,bp_high,bp_low,oxygen,temperature);
        PatientData p5("Jacob Rodriguez", 44, 1002, 87-rand() % 3 + 1, 128-rand() % 3 + 1, 82-rand() % 3 + 1, 96-rand() % 3 + 1, 100.6-rand() % 3 + 1);
        PatientData p6("Noman Ali", 38, 5742, 85-rand() % 3 + 1, 135-rand() % 3 + 1, 80-rand() % 3 + 1, 93-rand() % 3 + 1, 99.8-rand() % 3 + 1);
        PatientData p7("Farhan Ahmed", 41, 7123, 78-rand() % 3 + 1, 140-rand() % 3 + 1, 75-rand() % 3 + 1, 94-rand() % 3 + 1, 99.4-rand() % 3 + 1);
        PatientData p8("Muhammad Ali", 35, 4213, 80-rand() % 3 + 1, 120-rand() % 3 + 1, 70-rand() % 3 + 1, 95-rand() % 3 + 1, 98.5-rand() % 3 + 1);
        PatientData p9("Sher Khan", 45, 6321, 70-rand() % 3 + 1, 130-rand() % 3 + 1, 75-rand() % 3 + 1, 97-rand() % 3 + 1, 99.2-rand() % 3 + 1);
        PatientData p10("Bandook Khan", 28, 2789, 75-rand() % 3 + 1, 125-rand() % 3 + 1, 70-rand() % 3 + 1, 91-rand() % 3 + 1, 98.8-rand() % 3 + 1);

        ofstream file("patientdata.dat", ios::out | ios::binary);
    
        // close the file
        file.close();
        cout << "File emptied successfully." << endl;
        cout<<endl;

        p.randomdata(p);
        p2.randomdata(p2);
        p3.randomdata(p3);
        p4.randomdata(p4);
        p5.randomdata(p5);
        p6.randomdata(p6);
        p7.randomdata(p7);
        p8.randomdata(p8);
        p9.randomdata(p9);
        p10.randomdata(p10);
    }
    else if(MR_number==1002)
    {
        PatientData p("Arham Ahmed",18,2191,60-rand() % 3 + 1,120-rand() % 3 + 1,80-rand() % 3 + 1,70-rand() % 3 + 1,98.6-rand() % 3 + 1);
        PatientData p2("John Smith",50,9012,85-rand() % 3 + 1, 125-rand() % 3 + 1, 80-rand() % 3 + 1, 97-rand() % 3 + 1, 99.2-rand() % 3 + 1);
        PatientData p3("Sarah Williams", 35, 1010, 80-rand() % 3 + 1, 120-rand() % 3 + 1, 80-rand() % 3 + 1, 96-rand() % 3 + 1, 98.5-rand() % 2 + 1);
        PatientData p4("James Lee", 42, 2145, 85-rand() % 3 + 1, 125-rand() % 3 + 1, 80-rand() % 3 + 1, 97-rand() % 3 + 1, 99.2-rand() % 3 + 1);
        PatientData p5("Jacob Rodriguez", 44, 1002, heart_rate,bp_high,bp_low,oxygen,temperature);
        PatientData p6("Noman Ali", 38, 5742, 85-rand() % 3 + 1, 135-rand() % 3 + 1, 80-rand() % 3 + 1, 93-rand() % 3 + 1, 99.8-rand() % 3 + 1);
        PatientData p7("Farhan Ahmed", 41, 7123, 78-rand() % 3 + 1, 140-rand() % 3 + 1, 75-rand() % 3 + 1, 94-rand() % 3 + 1, 99.4-rand() % 3 + 1);
        PatientData p8("Muhammad Ali", 35, 4213, 80-rand() % 3 + 1, 120-rand() % 3 + 1, 70-rand() % 3 + 1, 95-rand() % 3 + 1, 98.5-rand() % 3 + 1);
        PatientData p9("Sher Khan", 45, 6321, 70-rand() % 3 + 1, 130-rand() % 3 + 1, 75-rand() % 3 + 1, 97-rand() % 3 + 1, 99.2-rand() % 3 + 1);
        PatientData p10("Bandook Khan", 28, 2789, 75-rand() % 3 + 1, 125-rand() % 3 + 1, 70-rand() % 3 + 1, 91-rand() % 3 + 1, 98.8-rand() % 3 + 1);

        ofstream file("patientdata.dat", ios::out | ios::binary);
    
        // close the file
        file.close();
        cout << "File emptied successfully." << endl;
        cout<<endl;

        p.randomdata(p);
        p2.randomdata(p2);
        p3.randomdata(p3);
        p4.randomdata(p4);
        p5.randomdata(p5);
        p6.randomdata(p6);
        p7.randomdata(p7);
        p8.randomdata(p8);
        p9.randomdata(p9);
        p10.randomdata(p10);
    }
    else if(MR_number==5742)
    {
        PatientData p("Arham Ahmed",18,2191,60-rand() % 3 + 1,120-rand() % 3 + 1,80-rand() % 3 + 1,70-rand() % 3 + 1,98.6-rand() % 3 + 1);
        PatientData p2("John Smith",50,9012,85-rand() % 3 + 1, 125-rand() % 3 + 1, 80-rand() % 3 + 1, 97-rand() % 3 + 1, 99.2-rand() % 3 + 1);
        PatientData p3("Sarah Williams", 35, 1010, 80-rand() % 3 + 1, 120-rand() % 3 + 1, 80-rand() % 3 + 1, 96-rand() % 3 + 1, 98.5-rand() % 2 + 1);
        PatientData p4("James Lee", 42, 2145, 85-rand() % 3 + 1, 125-rand() % 3 + 1, 80-rand() % 3 + 1, 97-rand() % 3 + 1, 99.2-rand() % 3 + 1);
        PatientData p5("Jacob Rodriguez", 44, 1002, 87-rand() % 3 + 1, 128-rand() % 3 + 1, 82-rand() % 3 + 1, 96-rand() % 3 + 1, 100.6-rand() % 3 + 1);
        PatientData p6("Noman Ali", 38, 5742, heart_rate,bp_high,bp_low,oxygen,temperature);
        PatientData p7("Farhan Ahmed", 41, 7123, 78-rand() % 3 + 1, 140-rand() % 3 + 1, 75-rand() % 3 + 1, 94-rand() % 3 + 1, 99.4-rand() % 3 + 1);
        PatientData p8("Muhammad Ali", 35, 4213, 80-rand() % 3 + 1, 120-rand() % 3 + 1, 70-rand() % 3 + 1, 95-rand() % 3 + 1, 98.5-rand() % 3 + 1);
        PatientData p9("Sher Khan", 45, 6321, 70-rand() % 3 + 1, 130-rand() % 3 + 1, 75-rand() % 3 + 1, 97-rand() % 3 + 1, 99.2-rand() % 3 + 1);
        PatientData p10("Bandook Khan", 28, 2789, 75-rand() % 3 + 1, 125-rand() % 3 + 1, 70-rand() % 3 + 1, 91-rand() % 3 + 1, 98.8-rand() % 3 + 1);

        ofstream file("patientdata.dat", ios::out | ios::binary);
    
        // close the file
        file.close();
        cout << "File emptied successfully." << endl;
        cout<<endl;

        p.randomdata(p);
        p2.randomdata(p2);
        p3.randomdata(p3);
        p4.randomdata(p4);
        p5.randomdata(p5);
        p6.randomdata(p6);
        p7.randomdata(p7);
        p8.randomdata(p8);
        p9.randomdata(p9);
        p10.randomdata(p10);
    }
    else if(MR_number==7123)
    {
        PatientData p("Arham Ahmed",18,2191,60+rand() % 3 + 1,120+rand() % 3 + 1,80+rand() % 3 + 1,70+rand() % 3 + 1,98.6+rand() % 3 + 1);
        PatientData p2("John Smith",50,9012,78+rand() % 3 + 1, 140+rand() % 3 + 1, 75+rand() % 3 + 1, 94+rand() % 3 + 1, 99.4+rand() % 3 + 1);
        PatientData p3("Sarah Williams", 35, 1010, 80+rand() % 3 + 1, 120+rand() % 3 + 1, 80+rand() % 3 + 1, 96+rand() % 3 + 1, 98.5+rand() % 2 + 1);
        PatientData p4("James Lee", 42, 2145, 85+rand() % 3 + 1, 125+rand() % 3 + 1, 80+rand() % 3 + 1, 97+rand() % 3 + 1, 99.2+rand() % 3 + 1);
        PatientData p5("Jacob Rodriguez", 44, 1002, 87+rand() % 3 + 1, 128+rand() % 3 + 1, 82+rand() % 3 + 1, 96+rand() % 3 + 1, 99.6+rand() % 3 + 1);
        PatientData p6("Noman Ali", 38, 5742, 85+rand() % 3 + 1, 135+rand() % 3 + 1, 80+rand() % 3 + 1, 93+rand() % 3 + 1, 99.8+rand() % 3 + 1);
        PatientData p7("Farhan Ahmed", 41, 7123, heart_rate,bp_high,bp_low,oxygen,temperature);
        PatientData p8("Muhammad Ali", 35, 4213, 80+rand() % 3 + 1, 120+rand() % 3 + 1, 70+rand() % 3 + 1, 95+rand() % 3 + 1, 98.5+rand() % 3 + 1);
        PatientData p9("Sher Khan", 45, 6321, 70+rand() % 3 + 1, 130+rand() % 3 + 1, 75+rand() % 3 + 1, 97+rand() % 3 + 1, 99.2+rand() % 3 + 1);
        PatientData p10("Bandook Khan", 28, 2789, 75+rand() % 3 + 1, 125+rand() % 3 + 1, 70+rand() % 3 + 1, 91+rand() % 3 + 1, 98.8+rand() % 3 + 1);

        ofstream file("patientdata.dat", ios::out | ios::binary);
    
        // close the file
        file.close();
        cout << "File emptied successfully." << endl;
        cout<<endl;

        p.randomdata(p);
        p2.randomdata(p2);
        p3.randomdata(p3);
        p4.randomdata(p4);
        p5.randomdata(p5);
        p6.randomdata(p6);
        p7.randomdata(p7);
        p8.randomdata(p8);
        p9.randomdata(p9);
        p10.randomdata(p10);
    }
    else if(MR_number==4213)
    {
        PatientData p("Arham Ahmed",18,2191,60+rand() % 3 + 1,120+rand() % 3 + 1,80+rand() % 3 + 1,70+rand() % 3 + 1,98.6+rand() % 3 + 1);
        PatientData p2("John Smith",50,9012,78+rand() % 3 + 1, 140+rand() % 3 + 1, 75+rand() % 3 + 1, 94+rand() % 3 + 1, 99.4+rand() % 3 + 1);
        PatientData p3("Sarah Williams", 35, 1010, 80+rand() % 3 + 1, 120+rand() % 3 + 1, 80+rand() % 3 + 1, 96+rand() % 3 + 1, 98.5+rand() % 2 + 1);
        PatientData p4("James Lee", 42, 2145, 85+rand() % 3 + 1, 125+rand() % 3 + 1, 80+rand() % 3 + 1, 97+rand() % 3 + 1, 99.2+rand() % 3 + 1);
        PatientData p5("Jacob Rodriguez", 44, 1002, 87+rand() % 3 + 1, 128+rand() % 3 + 1, 82+rand() % 3 + 1, 96+rand() % 3 + 1, 99.6+rand() % 3 + 1);
        PatientData p6("Noman Ali", 38, 5742, 85+rand() % 3 + 1, 135+rand() % 3 + 1, 80+rand() % 3 + 1, 93+rand() % 3 + 1, 99.8+rand() % 3 + 1);
        PatientData p7("Farhan Ahmed", 41, 7123,80+rand() % 3 + 1, 120+rand() % 3 + 1, 70+rand() % 3 + 1, 95+rand() % 3 + 1, 98.5+rand() % 3 + 1);
        PatientData p8("Muhammad Ali", 35, 4213, heart_rate,bp_high,bp_low,oxygen,temperature);
        PatientData p9("Sher Khan", 45, 6321, 70+rand() % 3 + 1, 130+rand() % 3 + 1, 75+rand() % 3 + 1, 97+rand() % 3 + 1, 99.2+rand() % 3 + 1);
        PatientData p10("Bandook Khan", 28, 2789, 75+rand() % 3 + 1, 125+rand() % 3 + 1, 70+rand() % 3 + 1, 91+rand() % 3 + 1, 98.8+rand() % 3 + 1);

        ofstream file("patientdata.dat", ios::out | ios::binary);
    
        // close the file
        file.close();
        cout << "File emptied successfully." << endl;
        cout<<endl;

        p.randomdata(p);
        p2.randomdata(p2);
        p3.randomdata(p3);
        p4.randomdata(p4);
        p5.randomdata(p5);
        p6.randomdata(p6);
        p7.randomdata(p7);
        p8.randomdata(p8);
        p9.randomdata(p9);
        p10.randomdata(p10);
    }
    else if(MR_number==6321)
    {
        PatientData p("Arham Ahmed",18,2191,60+rand() % 3 + 1,120+rand() % 3 + 1,80+rand() % 3 + 1,70+rand() % 3 + 1,98.6+rand() % 3 + 1);
        PatientData p2("John Smith",50,9012,78+rand() % 3 + 1, 140+rand() % 3 + 1, 75+rand() % 3 + 1, 94+rand() % 3 + 1, 99.4+rand() % 3 + 1);
        PatientData p3("Sarah Williams", 35, 1010, 80+rand() % 3 + 1, 120+rand() % 3 + 1, 80+rand() % 3 + 1, 96+rand() % 3 + 1, 98.5+rand() % 2 + 1);
        PatientData p4("James Lee", 42, 2145, 85+rand() % 3 + 1, 125+rand() % 3 + 1, 80+rand() % 3 + 1, 97+rand() % 3 + 1, 99.2+rand() % 3 + 1);
        PatientData p5("Jacob Rodriguez", 44, 1002, 87+rand() % 3 + 1, 128+rand() % 3 + 1, 82+rand() % 3 + 1, 96+rand() % 3 + 1, 99.6+rand() % 3 + 1);
        PatientData p6("Noman Ali", 38, 5742, 85+rand() % 3 + 1, 135+rand() % 3 + 1, 80+rand() % 3 + 1, 93+rand() % 3 + 1, 99.8+rand() % 3 + 1);
        PatientData p7("Farhan Ahmed", 41, 7123,80+rand() % 3 + 1, 120+rand() % 3 + 1, 70+rand() % 3 + 1, 95+rand() % 3 + 1, 98.5+rand() % 3 + 1);
        PatientData p8("Muhammad Ali", 35, 4213, 70+rand() % 3 + 1, 130+rand() % 3 + 1, 75+rand() % 3 + 1, 97+rand() % 3 + 1, 99.2+rand() % 3 + 1);
        PatientData p9("Sher Khan", 45, 6321, heart_rate,bp_high,bp_low,oxygen,temperature);
        PatientData p10("Bandook Khan", 28, 2789, 75+rand() % 3 + 1, 125+rand() % 3 + 1, 70+rand() % 3 + 1, 91+rand() % 3 + 1, 98.8+rand() % 3 + 1);

        ofstream file("patientdata.dat", ios::out | ios::binary);
    
        // close the file
        file.close();
        cout << "File emptied successfully." << endl;
        cout<<endl;

        p.randomdata(p);
        p2.randomdata(p2);
        p3.randomdata(p3);
        p4.randomdata(p4);
        p5.randomdata(p5);
        p6.randomdata(p6);
        p7.randomdata(p7);
        p8.randomdata(p8);
        p9.randomdata(p9);
        p10.randomdata(p10);
    }
    else if(MR_number==2789)
    {
        PatientData p("Arham Ahmed",18,2191,60+rand() % 3 + 1,120+rand() % 3 + 1,80+rand() % 3 + 1,70+rand() % 3 + 1,98.6+rand() % 3 + 1);
        PatientData p2("John Smith",50,9012,78+rand() % 3 + 1, 140+rand() % 3 + 1, 75+rand() % 3 + 1, 94+rand() % 3 + 1, 99.4+rand() % 3 + 1);
        PatientData p3("Sarah Williams", 35, 1010, 80+rand() % 3 + 1, 120+rand() % 3 + 1, 80+rand() % 3 + 1, 96+rand() % 3 + 1, 98.5+rand() % 2 + 1);
        PatientData p4("James Lee", 42, 2145, 85+rand() % 3 + 1, 125+rand() % 3 + 1, 80+rand() % 3 + 1, 97+rand() % 3 + 1, 99.2+rand() % 3 + 1);
        PatientData p5("Jacob Rodriguez", 44, 1002, 87+rand() % 3 + 1, 128+rand() % 3 + 1, 82+rand() % 3 + 1, 96+rand() % 3 + 1, 99.6+rand() % 3 + 1);
        PatientData p6("Noman Ali", 38, 5742, 85+rand() % 3 + 1, 135+rand() % 3 + 1, 80+rand() % 3 + 1, 93+rand() % 3 + 1, 99.8+rand() % 3 + 1);
        PatientData p7("Farhan Ahmed", 41, 7123,80+rand() % 3 + 1, 120+rand() % 3 + 1, 70+rand() % 3 + 1, 95+rand() % 3 + 1, 98.5+rand() % 3 + 1);
        PatientData p8("Muhammad Ali", 35, 4213, 70+rand() % 3 + 1, 130+rand() % 3 + 1, 75+rand() % 3 + 1, 97+rand() % 3 + 1, 99.2+rand() % 3 + 1);
        PatientData p9("Sher Khan", 45, 6321, 75+rand() % 3 + 1, 125+rand() % 3 + 1, 70+rand() % 3 + 1, 91+rand() % 3 + 1, 98.8+rand() % 3 + 1);
        PatientData p10("Bandook Khan", 28, 2789, heart_rate,bp_high,bp_low,oxygen,temperature);

        ofstream file("patientdata.dat", ios::out | ios::binary);
    
        // close the file
        file.close();
        cout << "File emptied successfully." << endl;
        cout<<endl;

        p.randomdata(p);
        p2.randomdata(p2);
        p3.randomdata(p3);
        p4.randomdata(p4);
        p5.randomdata(p5);
        p6.randomdata(p6);
        p7.randomdata(p7);
        p8.randomdata(p8);
        p9.randomdata(p9);
        p10.randomdata(p10);
    }
}

void PatientData::randomdata(PatientData obj)
{
    ofstream f("patientdata.dat",ios::binary | ios::app);
    f.write((char*)&obj, sizeof(obj));
    f.close();

    //cout<<"Updated data stored in file "<<endl;
}

void PatientData::request_appointment()
{
     cout<<"Which doctor appointment do you want to get ? "<<endl;
    cout<<"Press 1 for endocronologist"<<endl;
    cout<<"Press 2 for kidney"<<endl;
    cout<<"Press 3 for general surgeoun"<<endl;
    cout<<"Press 4 for dentist"<<endl;
    cout<<"Press 5 for skin"<<endl;
    int choice=0;
    cin>>choice;

    if(choice==1)
    {
        cout<<"Enter time in 24 hour , only hour for eg:(13:00 to be as 13) = ";
        int time;
        cin>>time;
        
        int doctor_id = 2345;
        

        ofstream file("appointmentrequests.dat", ios::binary|ios::app);

        if (file.is_open()) 
        {
            file.write(reinterpret_cast<const char*>(&doctor_id), sizeof(doctor_id));
            file.write(reinterpret_cast<const char*>(&time), sizeof(time));
            file.write(reinterpret_cast<const char*>(&MR_number), sizeof(MR_number));
            file.close();
            cout << "Appointment sent succesfully (AWAITING APPROVAL)" << endl;
        } 
        else 
        {
            cout << "Failed to open file" << endl;
        }
    }
    else if(choice==2)
    {
        cout<<"Enter time in 24 hour , only hour for eg:(13:00 to be as 13) = ";
        int time;
        cin>>time;
        
        int doctor_id = 1234;
        

        ofstream file("appointmentrequests.dat", ios::binary | ios::app);


        if (file.is_open()) 
        {
            file.write(reinterpret_cast<const char*>(&doctor_id), sizeof(doctor_id));
            file.write(reinterpret_cast<const char*>(&time), sizeof(time));
            file.write(reinterpret_cast<const char*>(&MR_number), sizeof(MR_number));
            file.close();
            cout << "Appointment sent succesfully (AWAITING APPROVAL)" << endl;
        } 
        else 
        {
            cout << "Failed to open file" << endl;
        }
    }
    else if(choice==3)
    {
        cout<<"Enter time in 24 hour , only hour for eg:(13:00 to be as 13) = ";
        int time;
        cin>>time;
        
        int doctor_id = 3456;
        

        ofstream file("appointmentrequests.dat", ios::binary | ios::app);


        if (file.is_open()) 
        {
            file.write(reinterpret_cast<const char*>(&doctor_id), sizeof(doctor_id));
            file.write(reinterpret_cast<const char*>(&time), sizeof(time));
            file.write(reinterpret_cast<const char*>(&MR_number), sizeof(MR_number));
            file.close();
            cout << "Appointment sent succesfully (AWAITING APPROVAL)" << endl;
        } 
        else 
        {
            cout << "Failed to open file" << endl;
        }
    }
    else if(choice==4)
    {
        cout<<"Enter time in 24 hour , only hour for eg:(13:00 to be as 13) = ";
        int time;
        cin>>time;
        
        int doctor_id = 4567;
        

        ofstream file("appointmentrequests.dat", ios::binary | ios::app);


        if (file.is_open()) 
        {
            file.write(reinterpret_cast<const char*>(&doctor_id), sizeof(doctor_id));
            file.write(reinterpret_cast<const char*>(&time), sizeof(time));
            file.write(reinterpret_cast<const char*>(&MR_number), sizeof(MR_number));
            file.close();
            cout << "Appointment sent succesfully (AWAITING APPROVAL)" << endl;
        } 
        else 
        {
            cout << "Failed to open file" << endl;
        }
    }
    else if(choice==5)
    {
        cout<<"Enter time in 24 hour , only hour for eg:(13:00 to be as 13) = ";
        int time;
        cin>>time;
        
        int doctor_id = 5678;
        

        ofstream file("appointmentrequests.dat", ios::binary | ios::app);


        if (file.is_open()) 
        {
            file.write(reinterpret_cast<const char*>(&doctor_id), sizeof(doctor_id));
            file.write(reinterpret_cast<const char*>(&time), sizeof(time));
            file.write(reinterpret_cast<const char*>(&MR_number), sizeof(MR_number));
            file.close();
            cout << "Appointment sent succesfully (AWAITING APPROVAL)" << endl;
        } 
        else 
        {
            cout << "Failed to open file" << endl;
        }
    }
    


}

