#ifndef ENDOCRONOLOGIST_H
#define ENDOCRONOLOGIST_H
#include"allfiles.h"


#include<string.h>

using namespace std;

class Endocronologist : public Doctor
{
    public:
        Endocronologist();
        Endocronologist(string n);
        void show_patient_data_endo(/*PatientData obj*/); // doctor can access patient data now and see it 
        void setAppointment_endo();
};

#endif