#ifndef DENTIST_H
#define DENTIST_H

#include"allfiles.h"

#include<string.h>

using namespace std;


class Dentist : public Doctor
{
    public:
        Dentist();
        Dentist(string n);
        void show_patient_data_dentist();// Doctor(n, "Dentistry")// doctor can access patient data now and see it 
        void setAppointment_dentist();
};
#endif