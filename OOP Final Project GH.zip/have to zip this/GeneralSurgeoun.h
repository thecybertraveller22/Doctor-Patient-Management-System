#ifndef GENERALSURGEOUN_H
#define GENERALSURGEOUN_H

#include"allfiles.h"

#include<string.h>

using namespace std;

class GeneralSurgeoun : public Doctor
{
    public:
        GeneralSurgeoun();
        GeneralSurgeoun(string n);
        void show_patient_data_generalsurgeoun();// Doctor(n, "Dentistry")// doctor can access patient data now and see it 
        void setAppointment_generalsurgeoun();

};

#endif