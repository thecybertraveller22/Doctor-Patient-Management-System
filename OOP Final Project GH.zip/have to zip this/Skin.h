#ifndef SKIN_H
#define SKIN_H

#include"allfiles.h"
#include<string.h>

using namespace std;

class SkinDoctor : public Doctor
{
    public:
        SkinDoctor();
        SkinDoctor(string n);
        void show_patient_data_skin();// Doctor(n, "Dentistry")// doctor can access patient data now and see it 
        void setAppointment_skin();
};
#endif