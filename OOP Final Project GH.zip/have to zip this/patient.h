#ifndef PATIENT_H
#define PATIENT_H
#include<string>
#include"doctor.h"
//#include"allfiles.h"
using namespace std;

class PatientData
{
    private:
        char name[30];
        //string name;
        int age;
        int MR_number;
        int heart_rate;
        int bp_high;
        int bp_low;
        int oxygen;
        float temperature;
    public:
        PatientData();
        PatientData(string n,int ag,int MR,int h_rate,int high,int low,int oxy,float temp);
        // setter is for new patient and getter is to get what ever data we have from read_patient function
        void setname();
        string getname();
        void setage();
        int getage();
        void setMR();
        int getMR();
        void set_heart_rate();
        int get_heart_rate();
        void setbp_high();
        int getbp_high();
        void setbp_low();
        int getbp_low();
        void set_oxygen();
        int get_oxygen();
        void set_temperature();
        float get_temperature();
        //-----------------------------------------
        //int display_patient_data(); // reads and then displays
        //-----------------------------------
        void create(PatientData obj);
        void read(int mr);
        void info();
        void kidneyread(int number);
        void generalread(int number);
        void endoread(int number);
        void dentistread(int number);
        void skinread(int number);

        void randomdata(PatientData obj);

        void infodentist();
        void infokidney();
        void infogeneral();
        void infoendo();
        void skininfo();
        //-----------------------------------
        //void read_patient_data();
        int login();
        void call_doctor();
        void request_appointment();

        //-----
        

};




#endif
