#ifndef KIDNEY_H
#define KIDNEY_H
#include"allfiles.h"

#include<string.h>

using namespace std;


class KidneyDoctor : public Doctor
{
    public:
        KidneyDoctor();
        KidneyDoctor(string n);
        void show_patient_data_kidney(/*PatientData obj*/); // doctor can access patient data now and see it 
        void setAppointment_kidney();
};

#endif